import React, { Component } from 'react'
import { TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, Keyboard } from 'react-native';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import EmployerFooter from './EmployerFooter';

const data_arr = [
    { 'image': require('../../icons/4.jpg'), 'msg': 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'ques': 'Early is on time is late and late is unacceptable' },
    { 'image': require('../../icons/5.jpg'), 'msg': 'Keep your workplace clean and organize ', 'ques': 'Work clean and organize' },
    { 'image': require('../../icons/4.jpg'), 'msg': 'One huge perk of smiling in the workplace is improving the moods of others around you. ... The physical benefits of smiling are a bit hard to believe. Smiling can help reduce stress, lower blood pressure, and even make you look younger!', 'ques': 'Smile work envrmonet is importent' },
    { 'image': require('../../icons/7.jpg'), 'msg': 'Move to paperless workplace help saving control over spending,recycling.', 'ques': 'Save help the company saving even by turning off the light or the thermostat the end of the day' },
    { 'image': require('../../icons/8.jpg'), 'msg': 'Build trust dont make promises that you cant keep  Promises only what you can deliver remember the wrost truth is better then the best lie', 'ques': 'The wrost truth is better then the best lie' },

]
export default class TipSucsessScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data_arr: data_arr
        };
    }

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: Colors.whiteColor }} showsVerticalScrollIndicator={false} >
                <TouchableOpacity activeOpacity={1} style={{ flex: 1 }} onPress={() => { Keyboard.dismiss() }}>
                    <SafeAreaView style={{ backgroundColor: Colors.appColor, flex: 0 }} />
                    <StatusBar barStyle='light-content' backgroundColor={Colors.appColor} hidden={false} translucent={false}
                        networkActivityIndicatorVisible={true} />
                    <View style={{ alignSelf: 'center', width: mobileW * 100 / 100, justifyContent: 'center', backgroundColor: Colors.whiteColor }}>
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>5 Tips for Success</Text>
                            </View>
                        </View>
                        {this.state.data_arr == 'NA' &&
                            <Nodata_foundimage />
                        }
                        <FlatList
                            data={this.state.data_arr}
                            contentContainerStyle={{ paddingBottom: 60 }}
                            renderItem={({ item, index }) => {
                                if (this.state.data_arr != 'NA') {
                                    return (
                                        <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', marginBottom: 10 }}>
                                            <Image style={{ height: mobileH * 30 / 100, alignSelf: 'center', width: mobileW * 90 / 100 }} source={item.image}></Image>
                                            <View style={{ width: mobileW * 14 / 100, height: mobileH * 1 / 100, backgroundColor: '#60bb78', borderRadius: mobileW * 1 / 100, marginTop: mobileW * 4 / 100 }}></View>
                                            <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', padding: mobileW * 2 / 100 }}>
                                                <Text style={{ fontSize: mobileW * 4 / 100, fontFamily: Font.montserrat_Bold, textAlign: 'justify', color: Colors.textColor, lineHeight: 20, paddingTop: mobileW * 2 / 100, paddingBottom: mobileW * 2 / 100 }} numberOfLines={2}>
                                                    {item.ques}
                                                </Text>
                                                <Text style={{ fontSize: mobileW * 3 / 100, fontFamily: Font.montserrat_Medium, textAlign: 'justify', color: Colors.textColor, lineHeight: 20 }} numberOfLines={4}>
                                                    {item.msg}
                                                </Text>
                                            </View>
                                        </View>
                                    )
                                }
                            }} ></FlatList>
                    </View>
                </TouchableOpacity>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}

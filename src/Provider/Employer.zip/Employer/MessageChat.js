import React, { Component } from 'react'
import { TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Footer from '../../Provider/Footer';
import EmployerFooter from './EmployerFooter';
const tab_arr = [
  { 'name': 'All Contects', status: true },
  { 'name': 'Candidates', status: false },
  { 'name': 'Group', status: false },



]
const data_arr = [
  { 'image': require('../../icons/4.jpg'), 'name': 'Peter Hawkins' },
  { 'image': require('../../icons/5.jpg'), 'name': 'James willian ', },

]
export default class Message_chat extends Component {
  constructor(props) {
    super(props)
    this.state = {

      tab_arr: tab_arr,
      data_arr: data_arr,
      tabpage: 'pending',


    }
  }
  clicktabbtn = (item, index) => {
    let data = this.state.tab_arr
    for (let i = 0; i < data.length; i++) {
      data[i].status = false
    }
    data[index].status = true
    this.setState({ tab_arr: data, tabpage: item.name })
  }
  render() {
    return (
      <View style={commonStyle.container}>
        <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
          <KeyboardAwareScrollView>
            <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
            <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

            {/* App Bar Start  */}
            <View style={{
              flexDirection: 'row', width: '100%', paddingHorizontal: 10,
              alignItems: 'center', height: mobileH * 8 / 100
            }}>
              <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                <Image source={localImage.backArrowImage}
                  style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                </Image>
              </TouchableOpacity>
              <View style={{ width: '78%', alignSelf: 'center' }}>
                <Text style={{
                  width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                  fontFamily: Font.montserrat_Bold, textAlign: 'center'
                }}>Messages</Text>
              </View>
            </View>

            <View style={{ width: '100%', alignSelf: 'center', paddingTop: mobileW * 5 / 100 }}>
              <FlatList
                data={this.state.tab_arr}
                horizontal={true}
                showsHorizontalScrollIndicator={false}
                renderItem={({ item, index }) => {
                  return (
                    <TouchableOpacity onPress={() => { this.clicktabbtn(item, index) }} style={[{ width: 130, borderBottomColor: Colors.bordercolor, borderBottomWidth: 1, paddingVertical: 5 }, item.status == true ? { borderBottomColor: 'black' } : null]}>
                      <Text style={{ fontSize: mobileW * 3.5 / 100, fontFamily: Font.montserrat_Bold, color: Colors.greyColor, textAlign: 'center' }} numberOfLines={1}>{item.name}</Text>
                    </TouchableOpacity>
                  )
                }}
                keyExtractor={(item, index) => index.toString()}
              />
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: mobileW * 95 / 100, alignSelf: 'center', marginTop: mobileW * 4 / 100 }}>
              <View style={{
                justifyContent: 'center',

              }}>
                <TextInput
                  style={Styles.textInputEmail}
                  borderColor={Colors.borderColorCode}
                  keyboardType={'default'}
                  placeholder={'Search'}
                  placeholderTextColor={Colors.textColor}
                  maxLength={64}
                  onChangeText={(input) => this.setState({ title: input })}
                  onSubmitEditing={() => { Keyboard.dismiss() }}
                ></TextInput>
              </View>
              <View style={{ borderWidth: 0.7, paddingVertical: mobileW * 3 / 100, width: mobileW * 40 / 100, flexDirection: 'row', alignItems: 'center', backgroundColor: '#f5f7fc', borderColor: '#f5f7fc' }}>
                <Text style={{ color: Colors.textColor, fontSize: mobileW * 3 / 100, fontFamily: Font.montserrat_Medium, textAlign: 'center', width: '80%' }}>Sort Contacts</Text>
                <Image source={require('../../icons/down_arrow.png')}
                  style={{ alignSelf: 'center', width: mobileW * 3 / 100, height: mobileW * 3 / 100, resizeMode: 'contain' }}>
                </Image>
              </View>
            </View>

            {this.state.data_arr == 'NA' &&
              <Nodata_foundimage />
            }
            <FlatList
              data={this.state.data_arr}
              contentContainerStyle={{ paddingBottom: 60 }}
              renderItem={({ item, index }) => {
                if (this.state.data_arr != 'NA') {
                  return (
                    <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', marginBottom: 10, marginTop: mobileW * 4 / 100, flexDirection: 'row' }}>
                      <View style={{ width: '30%', alignSelf: 'center' }}>
                        <Image style={{ height: 90, alignSelf: 'center', width: 90, resizeMode: 'cover', borderRadius: 150 / 2 }} source={item.image}></Image>
                      </View>
                      <View style={{ width: '55%', justifyContent: 'center' }}>
                        <Text style={{ fontFamily: Font.montserrat_Bold, fontSize: mobileW * 4 / 100 }}>{item.name}</Text>
                      </View>
                      <View style={{ width: '15%', justifyContent: 'center' }}>
                        <TouchableOpacity onPress={() => { this.props.navigation.navigate('Chat') }}>
                          <Image style={{ height: mobileH * 5 / 100, alignSelf: 'center', width: '75%', resizeMode: 'contain' }} source={require('../../icons/53.png')}></Image>
                        </TouchableOpacity>
                      </View>
                    </View>


                  )
                }
              }} ></FlatList>

          </KeyboardAwareScrollView>
        </ScrollView>
        <EmployerFooter
          activepage='Employer' // active screen initially
          usertype={1} // types of user set
          footerpage={[
            { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
            { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
            { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
            { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
          ]} // number of menus in bottom navigation bar
          navigation={this.props.navigation} // send navigation object
          imagestyle1={{
            width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
            backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
          }}
        />
      </View>
    )
  }
}
const Styles = StyleSheet.create({


  inputLabelText: {
    color: Colors.greyColor,
    fontSize: mobileW * 3.5 / 100,
    fontFamily: Font.montserrat_Regular,
    margin: mobileW * 2.5 / 100
  },
  textInputEmail: {
    color: Colors.textColor,
    borderWidth: 0.7,
    paddingVertical: mobileW * 3 / 100,
    padding: mobileW * 3 / 100,
    fontSize: mobileW * 3.5 / 100,
    fontFamily: Font.montserrat_Medium,
    width: mobileW * 50 / 100,
    textAlign: 'center'
  },

})
import React, { Component } from 'react'
import { FlatList, Image, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Footer from '../../Provider/Footer';
import { mobileW, commonStyle, mobileH, Colors, localImage, localStorage, Font } from '../../Provider/utilslib/Utils';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Fontisto from 'react-native-vector-icons/Fontisto';
import EmployerFooter from './EmployerFooter';

const DATACANDIDATE = [
    {
        name: 'Accounting finance', color: "1", owner: 'Elijah', status: false, city: 'Zürich', days: '10', price: '19,000', jobType: 'Charted Accountant'
    },
    {
        name: 'Accounting', color: "2", owner: 'James', status: true, city: 'Geneva', days: '11', price: '18,000', jobType: 'Cashier'
    },
    {
        name: 'Compony', color: "1", owner: 'Benjamin', status: true, city: 'Basel', days: '12', price: '17,000', jobType: 'Manager'
    }, {
        name: 'Compony', color: "2", owner: 'Lucas', status: true, city: 'Sion', days: '13', price: '16,000', jobType: 'Developer'
    }, {
        name: 'School', color: "3", owner: 'Elijah', status: false, city: 'Schaffhausen', days: '14', price: '15,000', jobType: 'Master'
    }, {
        name: 'Hotel', color: "1", owner: 'Henry', status: false, city: 'Basel', days: '15', price: '14,000', jobType: 'Superwiser'
    }, {
        name: 'School', color: "2", owner: 'Alexander', status: false, city: 'Fribourg', days: '16', price: '13,000', jobType: 'Teacher'
    }, {
        name: 'College', color: "3", owner: 'Mason', status: false, city: 'Basel', days: '17', price: '12,000', jobType: 'Head'
    }
];



export default class CandidateScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data_arr: DATACANDIDATE,
            usertype: localStorage.getItemString('userType')
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={styles.appBarStyle}>
                            <TouchableOpacity style={styles.leadingContainerStyle} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={styles.leadingIcon}>
                                </Image>
                            </TouchableOpacity>
                            <View style={styles.centerContainerStyle}>
                                <Text style={styles.centerTitleText}>Candidate</Text>
                            </View>
                            <TouchableOpacity onPress={() => { this.props.navigation.navigate('CandidateFilter') }} style={styles.actionContainerStyle}>
                                <Image source={localImage.otpionImage}
                                    style={styles.actionButtons}>
                                </Image>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <FlatList
                            style={{
                                width: mobileW * 100 / 100,
                                alignSelf: 'center',
                            }}
                            data={this.state.data_arr}
                            showsHorizontalScrollIndicator={false}
                            renderItem={({ item, index }) => {
                                return (
                                    <View style={{
                                        marginTop: 10,
                                        width: mobileW * 90 / 100,
                                        alignSelf: 'center'
                                    }}>
                                        <View style={styles.cardShadowView}>
                                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                                <View style={{ width: mobileW * 25 / 100, }}>
                                                    <Image
                                                        resizeMode={'cover'}
                                                        style={{
                                                            width: mobileW * 20 / 100,
                                                            height: mobileW * 18 / 100,
                                                        }} source={localImage.placeHolderImage} />
                                                </View>
                                                <View style={{ width: mobileW * 60 / 100, }}>
                                                    <View style={{ flexDirection: 'row', paddingTop: mobileW * 1 / 100 }}>
                                                        <Text style={{
                                                            fontFamily: Font.montserrat_Bold,
                                                            fontSize: Font.fontSize4,
                                                            color: Colors.textColor
                                                        }}>{item.owner}</Text>
                                                        <View style={{
                                                            justifyContent: 'center',
                                                            paddingTop: mobileW * 1 / 100,
                                                            paddingLeft: mobileW * 2 / 100
                                                        }}>
                                                            <AntDesign name='checkcircle'
                                                                size={18} color={item.color == "2" ? 'rgb(252,46,46)' : (item.color == "1" ? 'rgb(64,209,132)' : 'rgb(255,187,0)')} />
                                                        </View>
                                                    </View>
                                                    {
                                                        item.status == true &&
                                                        <View>
                                                            <Text style={{
                                                                paddingTop: mobileW * 1.5 / 100,
                                                                fontSize: Font.fontSize3half,
                                                                color: Colors.textColor,
                                                                fontFamily: Font.montserrat_Medium
                                                            }}>
                                                                {item.jobType}
                                                            </Text>
                                                            <View style={{ flexDirection: 'row', paddingTop: mobileW * 1.5 / 100, }}>
                                                                <Image source={localImage.locationImage} resizeMode={'contain'} style={{ height: mobileW * 5 / 100, width: mobileW * 5 / 100 }} />
                                                                <Text style={{
                                                                    fontSize: Font.fontSize3,
                                                                    color: Colors.textColor,
                                                                    fontFamily: Font.montserrat_Regular
                                                                }}>
                                                                    {item.city}, Switzerland
                                                                </Text>
                                                            </View>
                                                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', spaddingTop: mobileW * 1.5 / 100, }}>
                                                                <View style={{ flexDirection: 'row', paddingTop: mobileW * 2 / 100 }}>
                                                                    <AntDesign name='filter'
                                                                        color={Colors.textColor}
                                                                        size={22} />
                                                                    <Text style={{
                                                                        fontSize: Font.fontSize3,
                                                                        color: Colors.textColor,
                                                                        fontFamily: Font.montserrat_Regular
                                                                    }}>
                                                                        {item.name}
                                                                    </Text>
                                                                </View>
                                                                <View style={{
                                                                    borderColor: Colors.darkGreenColor,
                                                                    borderWidth: 1,
                                                                    paddingVertical: mobileW * 1.5 / 100,
                                                                    width: mobileW * 15 / 100
                                                                }}>
                                                                    <Text style={{
                                                                        textAlign: 'center',
                                                                        color: Colors.darkGreenColor
                                                                    }}>Saved</Text>
                                                                </View>
                                                            </View>
                                                        </View>
                                                    }
                                                    {
                                                        item.status == false &&
                                                        <View>
                                                            <View style={{ flexDirection: 'row' }}>
                                                                <View style={{ width: mobileW * 18 / 100, }}>
                                                                    <Text style={{
                                                                        paddingTop: mobileW * 1.5 / 100,
                                                                        fontSize: Font.fontSize3half,
                                                                        color: Colors.textColor,
                                                                        fontFamily: Font.montserrat_Medium
                                                                    }}>
                                                                        {item.jobType}
                                                                    </Text>
                                                                </View>
                                                                <View style={{
                                                                    flexDirection: 'row',
                                                                    paddingTop: mobileW * 1.5 / 100, width: mobileW * 20 / 100,
                                                                }}>
                                                                    <Image source={localImage.locationImage} resizeMode={'contain'}
                                                                        style={{ height: mobileW * 5 / 100, width: mobileW * 5 / 100 }} />
                                                                    <Text style={{
                                                                        fontSize: Font.fontSize3,
                                                                        color: Colors.textColor,
                                                                        fontFamily: Font.montserrat_Regular
                                                                    }}>
                                                                        {item.city}, Switzerland
                                                                    </Text>
                                                                </View>
                                                                <View style={{ width: mobileW * 20 / 100, paddingTop: mobileW * 1.5 / 100, }}>
                                                                    <View style={{ flexDirection: 'row', }}>
                                                                        <AntDesign name='filter'
                                                                            color={Colors.textColor}
                                                                            size={22} />
                                                                        <Text style={{
                                                                            fontSize: Font.fontSize3,
                                                                            color: Colors.textColor,
                                                                            fontFamily: Font.montserrat_Regular
                                                                        }}>
                                                                            {item.name}
                                                                        </Text>
                                                                    </View>
                                                                </View>
                                                            </View>
                                                            <View style={{
                                                                marginTop: mobileW * 4 / 100,
                                                                alignSelf: 'flex-end',
                                                                borderColor: Colors.darkGreenColor,
                                                                borderWidth: 1,
                                                                paddingVertical: mobileW * 1.5 / 100,
                                                                width: mobileW * 28 / 100
                                                            }}>
                                                                <Text style={{
                                                                    fontSize: Font.fontSize3,
                                                                    textAlign: 'center',
                                                                    color: Colors.darkGreenColor
                                                                }}>Save Candidate</Text>
                                                            </View>
                                                        </View>
                                                    }
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                );
                            }
                            }
                            keyExtractor={(item, index) => index.toString()}
                        />
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    appBarStyle: {
        flexDirection: 'row',
        width: '100%',
        paddingHorizontal: 10,
        alignItems: 'center',
        backgroundColor: Colors.whiteColor,
        height: mobileH * 8 / 100,
    },
    leadingContainerStyle: {
        width: '15%',
    },
    leadingIcon: {
        marginLeft: mobileW * 3 / 100,
        width: mobileW * 7 / 100,
        height: mobileW * 7 / 100,
        resizeMode: 'contain'
    },
    centerContainerStyle: {
        width: '70%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    centerTitleText: {
        width: '100%',
        fontSize: Font.fontSize5,
        color: Colors.textColor,
        fontFamily: Font.montserrat_Bold,
        textAlign: 'center'
    },
    actionContainerStyle: {
        width: '15%'
    },
    actionButtons: {
        alignSelf: 'center',
        width: mobileW * 7.5 / 100,
        height: mobileW * 7.5 / 100,
        resizeMode: 'contain'
    },
    screenBody: {
        width: mobileW * 100 / 100,
        alignSelf: 'center',
    },
    cardShadowView: {
        width: mobileW * 90 / 100,
        alignSelf: 'center',
        backgroundColor: Colors.whiteColor,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.5,
        shadowRadius: 0.5,
        elevation: 2,
        padding: mobileW * 3 / 100
    }
});
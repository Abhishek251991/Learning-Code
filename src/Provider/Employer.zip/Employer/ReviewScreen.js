import React, { Component } from 'react'
import { Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import StarRating from 'react-native-star-rating';
import Footer from '../../Provider/Footer';
import { mobileW, commonStyle, mobileH, localStorage, Colors, Font } from '../../Provider/utilslib/Utils';
import EmployerFooter from './EmployerFooter';

const DATA = [
    {
        city: 'Geneva', image: require('../../icons/notification_2.png'), name: 'Michele Snyder', description: 'The last decade has brought a new customer voice to the forefront empowering users and demanding transparency from brands', days: '20', rating: 1, colorValue: Colors.statusbarcolor, navigate: 'CandidateDashboard', status: true, count: 18
    },
    {
        city: 'Basel', image: require('../../icons/4.jpg'), name: 'Charlotte Davies', description: 'Rants and review fraud aside, online reviews offer a glimpse inside what it is like to use a product, visit a store, or in the case of Glassdoor, work for an employer.', days: '17', rating: 2, colorValue: 'rgb(91,126,197)', status: false, count: 19
    },
    {
        city: 'Lausanne', image: require('../../icons/5.jpg'), name: 'William Doe', description: 'Glassdoor is an online job site where people go to get a feel for what it’s like to work at a company.', rating: 3, days: '28', colorValue: 'rgb(236,97,81)', status: false, count: 2
    },
    {
        city: 'Winterthur', image: require('../../icons/7.jpg'), name: 'Julian', description: 'Glassdoor offers candidates a chance to look for jobs and read authentic and transparent reviews from employees currently and formerly employed in an organization.” ', days: '30', rating: 4, colorValue: 'rgb(214,181,72)', status: false, count: 0
    },
    {
        city: 'Lucerne', image: require('../../icons/4.jpg'), name: 'Christopher', description: 'Massimo Dutti clothes', days: '25', rating: 5, colorValue: Colors.statusbarcolor, navigate: 'CandidateDashboard', status: true, count: 18
    },
    {
        city: 'Lugano', image: require('../../icons/8.jpg'), name: 'Maverick', description: 'Perficient is always seeking the best and brightest to join our team, making Glassdoor an important channel for us.', days: '18', rating: 2, colorValue: 'rgb(91,126,197)', status: false, count: 19
    },
    {
        city: 'Thun', image: require('../../icons/8.jpg'), name: 'Andrew', description: 'By taking the time to leave a rating and review, you are helping directly influence our potential employees', days: '12', rating: 1, colorValue: 'rgb(236,97,81)', status: false, count: 2
    },
    {
        city: 'Gallen', image: require('../../icons/7.jpg'), name: 'Joshua', description: 'Great reviews help make people want to work here, making Glassdoor the perfect place to share what makes Perficient so unique and special.', days: '11', rating: 2, colorValue: 'rgb(214,181,72)', status: false, count: 0
    },
];

const DATASTART = [
    {
        city: 'Geneva', name: 'Michele Snyder',
        description: 'the last decade has brought a new customer voice to the forefront empowering users and demanding transparency from brands', days: '20', rating: '1', colorValue: Colors.statusbarcolor, navigate: 'CandidateDashboard', status: true, count: 18
    },
    {
        city: 'Basel', name: 'Charlotte Davies',
        description: 'Rants and review fraud aside, online reviews offer a glimpse inside what it is like to use a product, visit a store, or in the case of Glassdoor, work for an employer.',
        description: 'Media Networks,', days: '17', rating: '2', colorValue: 'rgb(91,126,197)', status: false, count: 19
    },
    {
        city: 'Lausanne', name: 'William Doe',
        description: 'Glassdoor is an online job site where people go to get a feel for what it’s like to work at a company.',
        rating: '3', days: '28', colorValue: 'rgb(236,97,81)', status: false, count: 2
    },
    {
        city: 'Winterthur', name: 'Julian',
        description: 'Glassdoor offers candidates a chance to look for jobs and read authentic and transparent reviews from employees currently and formerly employed in an organization.” ', days: '30', rating: '4', colorValue: 'rgb(214,181,72)', status: false, count: 0
    },
    {
        city: 'Lucerne', name: 'Christopher', description: 'Perficient is always seeking the best and brightest to join our team, making Glassdoor an important channel for us.', days: '25', rating: '3', colorValue: Colors.statusbarcolor, navigate: 'CandidateDashboard', status: true, count: 18
    },
    {
        city: 'Lugano', name: 'Maverick', description: 'By taking the time to leave a rating and review, you are helping directly influence our potential employees', days: '18', rating: '2', colorValue: 'rgb(91,126,197)', status: false, count: 19
    },
    {
        city: 'Thun', name: 'Andrew', description: 'By taking the time to leave a rating and review, you are helping directly influence our potential employees', days: '12', rating: '1', colorValue: 'rgb(236,97,81)', status: false, count: 2
    },
    {
        city: 'Gallen', name: 'Joshua', description: 'Great reviews help make people want to work here, making Glassdoor the perfect place to share what makes Perficient so unique and special.', days: '11', rating: '2', colorValue: 'rgb(214,181,72)', status: false, count: 0
    },
];

export default class EmployerReviewScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data_arr: DATA,
            data_start: DATASTART,
            usertype: localStorage.getItemString('userType')
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />
                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={require('../../icons/back_icon.png')}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Review</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={{ width: '78%' }}>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <View style={{
                            width: mobileW * 91 / 100,
                            alignSelf: 'center',
                            marginBottom: mobileW * 18 / 100
                        }}>
                            <FlatList
                                data={this.state.data_arr}
                                renderItem={({ item, index }) =>
                                    <View style={{
                                        width: mobileW * 90 / 100,
                                        marginBottom: 1,
                                        marginTop: mobileW * 4 / 100,
                                        alignSelf: 'center',
                                        backgroundColor: Colors.whiteColor,
                                        shadowColor: '#000',
                                        shadowOffset: {
                                            width: 2,
                                            height: 2,
                                        },
                                        shadowOpacity: 0.5,
                                        shadowRadius: 0.5,
                                        elevation: 2,
                                        paddingVertical: mobileW * 2 / 100
                                    }}>
                                        <View style={{ flexDirection: 'row', }}>

                                            <View style={{ width: mobileW * 30 / 100, height: 25 * mobileW / 100, justifyContent: 'center', alignItems: 'center' }}>
                                                <Image
                                                    resizeMode={'cover'}
                                                    style={{
                                                        width: mobileW * 22 / 100,
                                                        height: mobileW * 18 / 100,
                                                    }} source={item.image} />
                                            </View>
                                            <View style={{
                                                width: mobileW * 70 / 100,
                                                justifyContent: 'space-between'
                                            }}>
                                                <View>
                                                    <Text
                                                        numberOfLines={1}
                                                        style={{
                                                            color: Colors.textColorLightBlue,
                                                            fontFamily: Font.montserrat_Bold,
                                                            fontSize: Font.fontSize4,
                                                            width: mobileW * 60 / 100
                                                        }}>
                                                        {item.name}
                                                    </Text>
                                                </View>
                                                <View style={{ flexDirection: 'row', paddingVertical: mobileW * 3 / 100 }}>
                                                    <View style={{ width: mobileW * 30 / 100, }}>
                                                        <StarRating
                                                            containerStyle={{}}
                                                            // containerStyle={{ }}
                                                            emptyStar={require('../../icons/start_blank.png')}
                                                            fullStar={require('../../icons/start_fill.png')}
                                                            halfStar={require('../../icons/half_star.png')}
                                                            disabled={true}
                                                            maxStars={5}
                                                            rating={item.rating}
                                                            starSize={mobileW * 4 / 100}
                                                        // selectedStar={(rating) => this.onStarRatingPress(rating)}
                                                        />
                                                    </View>
                                                    <View>
                                                        <Text style={{ paddingLeft: mobileW * 2 / 100, fontSize: mobileW * 3.5 / 100, color: Colors.textColor, fontFamily: Font.montserrat_Bold }}>
                                                            {item.rating}.0
                                                        </Text>
                                                    </View>
                                                </View>
                                                <View>
                                                    <Text style={{
                                                        width: mobileW * 60 / 100,
                                                        color: Colors.greyColor,
                                                        fontFamily: Font.montserrat_Regular,
                                                        fontSize: mobileW * 3.5 / 100
                                                    }}>
                                                        {item.description}
                                                    </Text>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                }
                                keyExtractor={(item, index) => index.toString()}>
                            </FlatList>
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}
const styles = StyleSheet.create({
    seeAllButtonText: {
        color: Colors.whiteColor,
        fontFamily: Font.montserrat_Bold,
        fontSize: Font.fontSize3
    },
    seeAllButtonStyle: {
        justifyContent: 'center',
        alignItems: 'center',
        width: mobileW * 18 / 100,
        height: mobileW * 6 / 100,
        backgroundColor: Colors.darkGreenColor
    },
    totalVisits: {
        color: Colors.textColorLightBlue, fontFamily: Font.montserrat_Regular, fontSize: Font.fontSize3
    },
    totalVisitCount: {
        color: Colors.textColor, fontFamily: Font.montserrat_Medium, fontSize: Font.fontSize3
    },
    totalVisitRowColumnStyle: {
        width: '32.5%', backgroundColor: Colors.silverLightColor,
        paddingVertical: mobileW * 1.5 / 100, alignItems: 'center'
    }
});
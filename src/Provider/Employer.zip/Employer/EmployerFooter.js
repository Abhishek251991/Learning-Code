import React, { Component } from 'react'
import { View, Text, StyleSheet, Dimensions, TouchableOpacity, FlatList, Image } from 'react-native';
import { Colors, Font } from '../../Provider/utilslib/Utils';
const screenHeight = Math.round(Dimensions.get('window').height);
const screenWidth = Math.round(Dimensions.get('window').width);

export default class EmployerFooter extends Component {

    constructor(props) {
        super(props)
        this.state = {
            color: '',
            modalVisible1: false,
            loading: false,
            isConnected: true,
        }
    }

    usercheckbtn = async (page) => {
        const navigation = this.props.navigation;
        if (this.props.usertype == 1) {
            if (page != "NA") {
                navigation.navigate(page)
            }
        }
        else {
            this.setState({ modalVisible1: true })
        }
    }

    render() {
        let footerwidth = parseInt(100 / this.props.footerpage.length)
        console.log(footerwidth);
        console.log('padding value' + this.state.verticalPadding);
        return (
            <View style={[style1.footercontainer, { backgroundColor: this.props.imagestyle1.backgroundColor, height: screenWidth * 15.5 / 100 }]}>
                <FlatList
                    data={this.props.footerpage}
                    numColumns={this.props.footerpage.length}
                    renderItem={({ item, index }) => {
                        return (
                            <View style={{ width: screenWidth * footerwidth / 100 }}>
                                {item.name == this.props.activepage
                                    ?
                                    <View>
                                        <TouchableOpacity activeOpacity={0.8} onPress={() => {
                                            this.usercheckbtn(item.name);
                                        }} >
                                            <View style={{
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                paddingTop: screenHeight * 1.8 / 100
                                            }}>
                                                <Image resizeMode={'contain'} source={item.activeimage}
                                                    style={{
                                                        height: 22,
                                                        width: 22
                                                    }} />

                                                <View style={{ marginTop: 5 }}>
                                                    <Text
                                                        style={{
                                                            color: Colors.darkGreenColor,
                                                            fontFamily: Font.montserrat_Regular,
                                                            fontSize: screenWidth * 2.5 / 100
                                                        }}>
                                                        {item.label}
                                                    </Text>
                                                </View>
                                            </View>
                                        </TouchableOpacity>
                                    </View>
                                    :
                                    <View>
                                        <TouchableOpacity activeOpacity={0.8} onPress={() => {
                                            this.usercheckbtn(item.name);
                                        }} >
                                            <View style={{
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                alignSelf: 'center',
                                                paddingTop: screenHeight * 1.8 / 100
                                            }}>
                                                <Image resizeMode={'contain'} source={item.image}
                                                    style={{
                                                        height: 22,
                                                        width: 22
                                                    }} />
                                                <View style={{ marginTop: 3 }}>
                                                    <Text
                                                        style={{
                                                            color: Colors.textColor,
                                                            fontFamily: Font.montserrat_Regular,
                                                            fontSize: screenWidth * 2.5 / 100
                                                        }}>
                                                        {item.label}
                                                    </Text>
                                                </View>
                                            </View>
                                        </TouchableOpacity>
                                    </View>
                                }
                            </View>
                        );
                    }}
                    keyExtractor={(item, index) => index.toString()}
                />
            </View>
        );
    }
}
const style1 = StyleSheet.create({
    footercontainer: {
        flexDirection: 'row',
        width: screenWidth,
        position: 'absolute',
        elevation: 20,
        shadowOffset: { width: 1, height: 1 },
        shadowOpacity: 0.4,
        borderTopWidth: 1,
        borderTopColor: '#f7f7f7',
        shadowColor: 'white',
        bottom: 0
    },
    footericon: {
        width: screenWidth * 25 / 100,
        paddingTop: 8,
        paddingBottom: 6
    },
    footericonview: {
        alignSelf: 'center',
        paddingVertical: 7
    },
    footertext: {
        color: 'gray',
        fontSize: 13,
    },
    footerimage: {
        alignSelf: 'center',
        resizeMode: 'contain'
    }
});

import React, { Component } from 'react'
import { Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Footer from '../../Provider/Footer';
import EmployerFooter from './EmployerFooter';

const DATASAVEDCANDIDATE = [
    {
        name: 'Accounting finance', owner: 'Elijah', status: true, city: 'Zürich', days: '10', price: '19,000'
    },
    {
        name: 'Accounting', owner: 'James', status: false, city: 'Geneva', days: '11', price: '18,000'
    },
    {
        name: 'Agriculture', owner: 'Benjamin', status: false, city: 'Basel', days: '12', price: '17,000'
    }, {
        name: 'Accounting finance', owner: 'Lucas', status: false, city: 'Sion', days: '13', price: '16,000'
    }, {
        name: 'Art', owner: 'Elijah', status: false, city: 'Schaffhausen', days: '14', price: '15,000'
    }, {
        name: 'Education', owner: 'Henry', status: false, city: 'Basel', days: '15', price: '14,000'
    }, {
        name: 'Vernier', owner: 'Alexander', status: false, city: 'Fribourg', days: '16', price: '13,000'
    }, {
        name: 'Hospital', owner: 'Mason', status: false, city: 'Basel', days: '17', price: '12,000'
    }, {
        name: 'Medical', owner: 'Michael', status: false, city: 'Thun', days: '18', price: '11,000'
    }, {
        name: 'Freelance', owner: 'Ethan', status: false, city: 'Lucerne', days: '19', price: '10,000'
    },
];

export default class SavedCandidateScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            savedCandidateArray: DATASAVEDCANDIDATE,
            usertype: localStorage.getItemString('userType')
        }
    }

    render() {
        return (
            <View style={commonStyle.container}>

                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={styles.appBarStyle}>
                            <TouchableOpacity style={styles.leadingContainerStyle} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={styles.leadingIcon}>
                                </Image>
                            </TouchableOpacity>
                            <View style={styles.centerContainerStyle}>
                                <Text style={styles.centerTitleText}>Saved Candidates</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={styles.actionContainerStyle}>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <View style={styles.screenBody}>
                            <FlatList
                                style={{ width: mobileW * 95 / 100, alignSelf: 'center' }}
                                data={this.state.savedCandidateArray}
                                renderItem={({ item, index }) =>
                                    <TouchableOpacity activeOpacity={.7} onPress={() => { }}>
                                        <View style={styles.cardShadowView}>
                                            <View style={{ flexDirection: 'row', paddingTop: mobileW * 3 / 100 }}>
                                                <View style={{
                                                    width: mobileW * 30 / 100,
                                                    marginTop: mobileW * 1.3 / 100,
                                                    alignItems: 'center'
                                                }}>
                                                    <Image
                                                        resizeMode={'cover'}
                                                        style={{
                                                            width: mobileW * 20 / 100,
                                                            height: mobileW * 18 / 100,
                                                        }} source={localImage.placeHolderImage} />
                                                </View>
                                                <View style={{
                                                    width: mobileW * 45 / 100,
                                                    justifyContent: 'space-around',
                                                }}>
                                                    <View>
                                                        <Text style={{
                                                            fontFamily: Font.montserrat_Bold,
                                                            fontSize: Font.fontSize4,
                                                            color: Colors.textColor
                                                        }}>
                                                            {item.owner}
                                                        </Text>
                                                        <Text style={{
                                                            fontFamily: Font.montserrat_Medium,
                                                            fontSize: Font.fontSize3half,
                                                            color: Colors.darkGreenColor
                                                        }}>
                                                            Proerty Agent
                                                        </Text>
                                                    </View>
                                                    <View style={{
                                                        flexDirection: 'row',
                                                        marginTop: mobileW * 1 / 100,
                                                        paddingVertical: mobileW * 2.5 / 100,
                                                    }}>
                                                        <Image
                                                            style={{
                                                                width: 18,
                                                                height: 18,
                                                            }}
                                                            resizeMode={'contain'}
                                                            source={localImage.locationImage} />
                                                        <Text style={{
                                                            marginLeft: mobileW * 1 / 100,
                                                            color: Colors.textColorLight,
                                                            fontFamily: Font.montserrat_Regular,
                                                            fontSize: Font.fontSize3
                                                        }}>
                                                            {item.city} ,Switzerland
                                                        </Text>
                                                    </View>
                                                    <View style={{
                                                        flexDirection: 'row',
                                                        paddingVertical: mobileW * 1 / 100,
                                                    }}>
                                                        <Image
                                                            style={{
                                                                width: 18,
                                                                height: 18,
                                                            }}
                                                            resizeMode={'contain'}
                                                            source={localImage.currencyImage} />
                                                        <Text style={{
                                                            marginLeft: mobileW * 2 / 100,
                                                            color: Colors.textColorLight,
                                                            fontSize: Font.fontSize3,
                                                            fontFamily: Font.montserrat_Regular
                                                        }}>
                                                            ${item.price}.00 / Monthly
                                                        </Text>
                                                    </View>
                                                </View>
                                                <View style={{
                                                    width: mobileW * 10 / 100,
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                }}>
                                                    <Image source={localImage.eyeOpenImage}
                                                        style={{ width: mobileW * 7 / 100, height: mobileW * 7 / 100 }}
                                                    />
                                                    <Image source={localImage.deleteImage}
                                                        style={{
                                                            marginTop: mobileW * 0.04,
                                                            width: mobileW * 7 / 100,
                                                            height: mobileW * 7 / 100
                                                        }}
                                                    />
                                                </View>
                                            </View>
                                            <View style={{
                                                flexDirection: 'row', paddingTop: mobileW * 3 / 100,
                                                justifyContent: 'space-between'
                                            }}>
                                                <View style={{
                                                    backgroundColor: Colors.silverLightColor,
                                                    width: mobileW * 29.5 / 100, paddingHorizontal: mobileW * 3 / 100
                                                }}>
                                                    <View style={{
                                                        flexDirection: 'row', alignSelf: 'center',
                                                        paddingVertical: mobileW * 3 / 100
                                                    }}>
                                                        <Image source={localImage.messageChatImage}
                                                            style={{
                                                                width: mobileW * 5 / 100,
                                                                height: mobileW * 5 / 100
                                                            }}
                                                            resizeMode={'contain'}
                                                        />
                                                        <Text style={{
                                                            paddingLeft: mobileW * 2 / 100,
                                                            color: Colors.textColor,
                                                            fontFamily: Font.montserrat_Medium,
                                                            fontSize: Font.fontSize2half
                                                        }}>Message</Text>
                                                    </View>
                                                </View>
                                                <View style={{
                                                    backgroundColor: Colors.silverLightColor, width: mobileW * 29.5 / 100,
                                                    paddingVertical: mobileW * 3 / 100
                                                }}>
                                                    <View style={{ flexDirection: 'row', alignSelf: 'center' }}>
                                                        <Image source={localImage.placeHolderUserIcon}
                                                            style={{
                                                                width: mobileW * 5 / 100,
                                                                height: mobileW * 5 / 100
                                                            }}
                                                            resizeMode={'contain'}
                                                        />
                                                        <Text style={{
                                                            paddingLeft: mobileW * 2 / 100,
                                                            color: Colors.textColor,
                                                            fontFamily: Font.montserrat_Medium,
                                                            fontSize: Font.fontSize2half
                                                        }}>View Profile</Text>
                                                    </View>
                                                </View>
                                                <View style={{
                                                    backgroundColor: Colors.silverLightColor, width: mobileW * 29.5 / 100,
                                                    paddingVertical: mobileW * 3 / 100
                                                }}>
                                                    <View style={{ flexDirection: 'row', alignSelf: 'center' }}>
                                                        <Image source={localImage.linkedInImage}
                                                            style={{
                                                                width: mobileW * 5 / 100,
                                                                height: mobileW * 5 / 100
                                                            }}
                                                            resizeMode={'contain'}
                                                        />
                                                        <Text style={{
                                                            paddingLeft: mobileW * 2 / 100,
                                                            color: Colors.textColor,
                                                            fontFamily: Font.montserrat_Medium,
                                                            fontSize: Font.fontSize2half
                                                        }}>LinkedIn</Text>
                                                    </View>
                                                </View>
                                            </View>
                                        </View>
                                    </TouchableOpacity>
                                }
                                keyExtractor={(item, index) => index.toString()}
                            >
                            </FlatList>
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    appBarStyle: {
        flexDirection: 'row',
        width: '100%',
        paddingHorizontal: 10,
        alignItems: 'center',
        backgroundColor: Colors.whiteColor,
        height: mobileH * 8 / 100,
    },
    leadingContainerStyle: {
        width: '15%',
    },
    leadingIcon: {
        marginLeft: mobileW * 3 / 100,
        width: mobileW * 7 / 100,
        height: mobileW * 7 / 100,
        resizeMode: 'contain'
    },
    centerContainerStyle: {
        width: '70%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    centerTitleText: {
        width: '100%',
        fontSize: Font.fontSize5,
        color: Colors.textColor,
        fontFamily: Font.montserrat_Bold,
        textAlign: 'center'
    },
    actionContainerStyle: {
        width: '15%'
    },
    actionButtons: {
        alignSelf: 'center',
        width: mobileW * 7.5 / 100,
        height: mobileW * 7.5 / 100,
        resizeMode: 'contain'
    },
    screenBody: {
        width: mobileW * 100 / 100,
        alignSelf: 'center',
    },
    cardShadowView: {
        width: mobileW * 90 / 100,
        marginBottom: 1,
        marginTop: mobileW * 4 / 100,
        alignSelf: 'center',
        backgroundColor: Colors.whiteColor,
        shadowColor: '#000',
        shadowOffset: {
            width: 2,
            height: 2,
        },
        shadowOpacity: 0.5,
        shadowRadius: 0.5,
        elevation: 2,
    }
});
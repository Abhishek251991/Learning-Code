import React, { Component } from 'react'
import { Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Footer from '../../Provider/Footer';
import { mobileW, commonStyle, mobileH, localStorage, Colors, Font } from '../../Provider/utilslib/Utils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import OcticonsIcons from 'react-native-vector-icons/Octicons';
import IoniconsIcons from 'react-native-vector-icons/Ionicons';
import EmployerFooter from './EmployerFooter';



const DATA = [
    {
        name: 'applied jobs', description: 'to find a career', colorValue: Colors.statusbarcolor, navigate: 'CandidateDashboard', status: true, count: 18
    },
    {
        name: 'favorite jobs', description: 'against opportunities', colorValue: 'rgb(91,126,197)', status: false, count: 19
    },
    {
        name: 'jobs alerts', description: 'to get the latest updates', colorValue: 'rgb(236,97,81)', status: false, count: 2
    },
    {
        name: 'packages', description: 'to apply jobs', colorValue: 'rgb(214,181,72)', status: false, count: 0
    },
];

const DATAJOBSAPPLIED = [
    {

        name: 'Accounting finance', owner: 'Elijah', status: true, city: 'Zürich', days: '10'
    },
    {
        name: 'Accounting', owner: 'James', status: false, city: 'Geneva', days: '11'
    },
    {
        name: 'Agriculture', owner: 'Benjamin', status: false, city: 'Basel', days: '12'
    }, {
        name: 'Accounting finance', owner: 'Lucas', status: false, city: 'Sion', days: '13'
    }, {
        name: 'Art', owner: 'Elijah', status: false, city: 'Schaffhausen', days: '14'
    }, {
        name: 'Education', owner: 'Henry', status: false, city: 'Basel', days: '15'
    }, {
        name: 'Vernier', owner: 'Alexander', status: false, city: 'Fribourg', days: '16'
    }, {
        name: 'Hospital', owner: 'Mason', status: false, city: 'Basel', days: '17'
    }, {
        name: 'Medical', owner: 'Michael', status: false, city: 'Thun', days: '18'
    }, {
        name: 'Freelance', owner: 'Ethan', status: false, city: 'Lucerne', days: '19'
    },
];

export default class EmployerDashboardScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data_arr: DATA,
            applied_arr: DATAJOBSAPPLIED,
            checkboxCondition: false,
            usertype: localStorage.getItemString('userType')
        }
    }
    checkboxTermsAndCondition = () => {
        if (this.state.checkboxCondition) {
            this.setState({ checkboxCondition: false })
        } else {
            this.setState({ checkboxCondition: true })
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', backgroundColor: Colors.silverLightColor, height: mobileH * 8 / 100,
                        }}>
                            <TouchableOpacity style={{ width: '15%', }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={require('../../icons/back_icon.png')}
                                    style={{
                                        marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100,
                                        height: mobileW * 7 / 100, resizeMode: 'contain'
                                    }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '70%', justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Welcome!</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={{ width: '15%' }}>
                                <Image borderRadius={25} source={require('../../icons/employer_profile_icon.png')}
                                    style={{
                                        alignSelf: 'center', width: mobileW * 10 / 100,
                                        height: mobileW * 10 / 100, resizeMode: 'contain'
                                    }}>
                                </Image>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}

                        <View style={{
                            width: '100%',
                            backgroundColor: Colors.silverLightColor,
                            height: mobileH * 35 / 100
                        }}>

                            <View style={{
                                width: mobileW * 90 / 100,
                                alignSelf: 'center',
                            }}>
                                <FlatList
                                    data={this.state.data_arr}
                                    numColumns={2}
                                    renderItem={({ item, index }) => {
                                        return (
                                            <View style={{
                                                width: mobileW * 45 / 100
                                            }}>
                                                <View style={{
                                                    width: mobileW * 42.5 / 100,
                                                    alignSelf: 'center',
                                                    backgroundColor: item.colorValue,
                                                    paddingVertical: mobileW * 4.5 / 100,
                                                    marginTop: mobileW * 3.5 / 100
                                                }}>
                                                    <View style={{ marginLeft: mobileW * 3.5 / 100 }}>
                                                        <Text numberOfLines={1} style={{
                                                            color: Colors.whiteColor,
                                                            fontFamily: Font.montserrat_Bold, fontSize: Font.fontSize5
                                                        }}>
                                                            {item.count}
                                                        </Text>
                                                        <Text numberOfLines={1} style={{
                                                            marginTop: mobileW * 2.5 / 100,
                                                            color: Colors.whiteColor,
                                                            fontFamily: Font.montserrat_Bold,
                                                            textTransform: 'uppercase',
                                                            fontSize: Font.fontSize3
                                                        }}>
                                                            {item.name}
                                                        </Text>
                                                        <Text numberOfLines={1} style={{
                                                            color: Colors.whiteColor,
                                                            fontFamily: Font.montserrat_Medium,
                                                            fontSize: Font.fontSize3
                                                        }}>
                                                            {item.description}
                                                        </Text>

                                                    </View>
                                                </View>
                                            </View>
                                        );
                                    }}
                                    keyExtractor={(item, index) => index.toString()}
                                />
                            </View>
                        </View>
                        <View style={{ width: mobileW * 90 / 100, marginTop: mobileW * 6 / 100, alignSelf: 'center' }}>
                            <Text style={{
                                color: Colors.textColor,
                                fontFamily: Font.montserrat_Bold,
                                fontSize: Font.fontSize5
                            }}>
                                Notificaitons
                            </Text>
                            <View style={{
                                backgroundColor: Colors.silverLightColor, marginTop: mobileW * 2.5 / 100,
                                paddingVertical: mobileW * 2 / 100
                            }}>
                                <Text style={{ color: Colors.textColorLight, textAlign: 'center' }}>
                                    You have no notifications.
                                </Text>
                            </View>

                            <View style={{ height: mobileW * 20 / 100, justifyContent: 'center' }}>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <Text style={{
                                        fontSize: Font.fontSize4, color: Colors.textColor,
                                        fontFamily: Font.montserrat_Bold
                                    }}>
                                        Recent Applicants
                                    </Text>
                                    <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                        <View style={
                                            styles.seeAllButtonStyle
                                        }>
                                            <Text style={
                                                styles.seeAllButtonText
                                            }>
                                                See All
                                            </Text>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            </View>

                            <Text style={{
                                color: Colors.darkGreenColor,
                                fontFamily: Font.montserrat_Bold,
                                fontSize: mobileW * 3.8 / 100,
                            }}>
                                Financed Manager
                            </Text>

                            <View style={{
                                paddingVertical: mobileW * 3 / 100,
                                flexDirection: 'row',
                                justifyContent: 'space-between'
                            }}>
                                <View style={styles.totalVisitRowColumnStyle}>
                                    <Text style={styles.totalVisitCount}>3</Text>
                                    <Text style={styles.totalVisits}>Total Applicants</Text>
                                </View>
                                <View style={styles.totalVisitRowColumnStyle}>
                                    <Text style={styles.totalVisitCount}>1541</Text>
                                    <Text style={styles.totalVisits}>Total Visits</Text>
                                </View>
                                <View style={styles.totalVisitRowColumnStyle}>
                                    <Text style={styles.totalVisitCount}>Oct 31,2022</Text>
                                    <Text style={styles.totalVisits}>Expiry Date</Text>
                                </View>
                            </View>

                            <View style={{
                                width: mobileW * 91 / 100,
                                marginBottom: mobileW * 18 / 100
                            }}>
                                <FlatList
                                    data={this.state.applied_arr}
                                    renderItem={({ item, index }) =>
                                        <TouchableOpacity activeOpacity={.7} onPress={() => {
                                            // this.props.navigation.navigate('FindJobsDetail');
                                        }}>
                                            <View style={{
                                                width: mobileW * 90 / 100,
                                                marginBottom: 1,
                                                marginTop: mobileW * 4 / 100,
                                                alignSelf: 'center',
                                                backgroundColor: Colors.whiteColor,
                                                shadowColor: '#000',
                                                shadowOffset: {
                                                    width: 2,
                                                    height: 2,
                                                },
                                                shadowOpacity: 0.5,
                                                shadowRadius: 0.5,
                                                elevation: 2,
                                                paddingVertical: mobileW * 2 / 100
                                            }}>
                                                <View style={{ flexDirection: 'row', }}>

                                                    <View style={{ width: mobileW * 30 / 100, height: 25 * mobileW / 100, justifyContent: 'center', alignItems: 'center' }}>
                                                        <Image
                                                            resizeMode={'cover'}
                                                            style={{
                                                                width: mobileW * 22 / 100,
                                                                height: mobileW * 18 / 100,
                                                            }} source={require('../../icons/placeholder.png')} />
                                                    </View>
                                                    <View style={{
                                                        width: mobileW * 70 / 100,
                                                        justifyContent: 'space-around'
                                                    }}>
                                                        <View style={{ flexDirection: 'row', width: mobileW * 70 / 100 }}>
                                                            <Text
                                                                numberOfLines={1}
                                                                style={{
                                                                    color: Colors.textColorLightBlue,
                                                                    fontFamily: Font.montserrat_Bold,
                                                                    fontSize: Font.fontSize4,
                                                                    width: mobileW * 45 / 100
                                                                }}>
                                                                {item.owner}
                                                            </Text>
                                                            <TouchableOpacity
                                                                onPress={() => this.checkboxTermsAndCondition()}
                                                                style={{
                                                                    flexDirection: 'row', width: mobileW * 10 / 100,
                                                                    justifyContent: 'space-between',
                                                                }}>
                                                                {this.state.checkboxCondition ?
                                                                    <MaterialCommunityIcons name='check-box-outline' size={30} color={Colors.darkGreenColor} />
                                                                    : <MaterialCommunityIcons name='checkbox-blank-outline' size={30} color={Colors.darkGreenColor} />}
                                                            </TouchableOpacity>
                                                        </View>
                                                        <View>
                                                            <Text numberOfLines={1} style={{
                                                                width: mobileW * 60 / 100,
                                                                color: Colors.darkGreenColor,
                                                                fontFamily: Font.montserrat_Bold,
                                                                fontSize: Font.fontSize3,
                                                            }}>
                                                                {item.name}
                                                            </Text>
                                                        </View>
                                                        <View style={{
                                                            width: mobileW * 50 / 100,
                                                            justifyContent: 'flex-start',
                                                            flexDirection: 'row'
                                                        }}>
                                                            <IoniconsIcons name='location-outline' size={24} color={Colors.textColor} />
                                                            <Text
                                                                numberOfLines={1}
                                                                style={{
                                                                    width: mobileW * 60 / 100,
                                                                    paddingLeft: mobileW * 2 / 100,
                                                                    fontSize: Font.fontSize3half,
                                                                    fontFamily: Font.montserrat_Regular,
                                                                    color: Colors.textColorLight,
                                                                    paddingVertical: mobileW * 0.5 / 100
                                                                }}>
                                                                {item.city}
                                                            </Text>
                                                        </View>
                                                        <View style={{
                                                            width: mobileW * 50 / 100,
                                                            justifyContent: 'flex-start',
                                                            flexDirection: 'row'
                                                        }}>
                                                            <OcticonsIcons name='mail' size={24} color={Colors.textColor} />
                                                            <Text
                                                                numberOfLines={1}
                                                                style={{
                                                                    width: mobileW * 60 / 100,
                                                                    paddingLeft: mobileW * 2 / 100,
                                                                    fontSize: Font.fontSize3half,
                                                                    fontFamily: Font.montserrat_Regular,
                                                                    color: Colors.textColorLight,
                                                                    paddingVertical: mobileW * 0.5 / 100
                                                                }}>
                                                                {item.owner}@gmail.com
                                                            </Text>
                                                        </View>
                                                    </View>
                                                </View>
                                            </View>
                                        </TouchableOpacity>
                                    }
                                    keyExtractor={(item, index) => index.toString()}
                                >
                                </FlatList>
                            </View>
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    seeAllButtonText: {
        color: Colors.whiteColor,
        fontFamily: Font.montserrat_Bold,
        fontSize: Font.fontSize3
    },
    seeAllButtonStyle: {
        justifyContent: 'center',
        alignItems: 'center',
        width: mobileW * 18 / 100,
        height: mobileW * 6 / 100,
        backgroundColor: Colors.darkGreenColor
    },
    totalVisits: {
        color: Colors.textColorLightBlue, fontFamily: Font.montserrat_Regular, fontSize: Font.fontSize3
    },
    totalVisitCount: {
        color: Colors.textColor, fontFamily: Font.montserrat_Medium, fontSize: Font.fontSize3
    },
    totalVisitRowColumnStyle: {
        width: '32.5%', backgroundColor: Colors.silverLightColor,
        paddingVertical: mobileW * 1.5 / 100, alignItems: 'center'
    }

});
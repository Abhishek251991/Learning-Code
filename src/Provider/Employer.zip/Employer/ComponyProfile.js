import React, { Component } from 'react';
import { FlatList, Keyboard, Image, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View, Modal } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mediaprovider, msgProvider, Cameragallery, config, msgText, mobileH, localStorage, Colors, Font, localImage } from '../../Provider/utilslib/Utils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Footer from '../../Provider/Footer';
import HideWithKeyboard from 'react-native-hide-with-keyboard';
import { Slider } from 'react-native';
import EmployerFooter from './EmployerFooter';

const CheckBoxText = ({ title }) => (
    <Text style={{
        color: Colors.textColor,
        fontSize: Font.fontSize4,
        paddingVertical: mobileW * 1 / 100,
        fontFamily: Font.montserrat_Medium
    }}>{title}</Text>
);


export default class EmployerComponyProfileScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            firstName: '',
            lastName: '',
            componyName: '',
            email: '',
            profileUrl: '',
            profileForPublicView: '',
            phone: '',

            foundedSince: 0.2,

            facebook: 'https://www.facebook.com/envato',
            twitter: 'https://www.twitter%20.com/emvato',
            linkedIn: 'https://www.linkedin.com/envato',
            dribble: 'https://www.dribble.com/envoto',

            address: '',

            profile_image: 'NA',
            mediamodal: false,
            cameraon: false,

            usertype: localStorage.getItemString('userType'),
            accountMembersArray: ACCOUNTMEMBERS,
            componyProfileMenus: DATA,
            securePasswordText: true,
            secureConfirmPasswordText: true,
            isAddAccountMember: false,
            isBasicInformationBtnSelected: true,
            isOtherInformationBtnSelected: false,
            isSocialLinksBtnSelected: false,
            isAddressBtnSelected: false,
            isAccountMemberBtnSelected: false,
            isTeamMemberBtnSelected: false,
            discription: "Hello my name is Ariana Gande Connor and I'am a Financial Supervisor from Netherlands,Rotterdam.In pharetra orci dignissim,blandit mi semper, ultricies diam.Suspendisse malesuada suscipit nunc non volutpat.Sed porta nulla id orci laorweet temprot non consequant enim.Sed vitae aliquam velit.Aliquam ante accumsan acest",

            postNewJobCheckBox: true,
            manageJobsCheckBox: true,
            manageOwnJobsOnlyCheckBox: true,
            ownEmailOnlyCheckBox: true,
            savedCandidatesCheckBox: true,
            packagesCheckBox: true,
            transactionsCheckBox: true,
            meetingsCheckBox: true
        }
    }

    checkBoxCondition(value) {
        switch (value) {
            case 'postnewjob':
                this.state.postNewJobCheckBox ? this.setState({ postNewJobCheckBox: false }) : this.setState({ postNewJobCheckBox: true })
                break;
            case 'managejobs':
                this.state.manageJobsCheckBox ? this.setState({ manageJobsCheckBox: false }) : this.setState({ manageJobsCheckBox: true })
                break;
            case 'manageownjobsonly':
                this.state.manageOwnJobsOnlyCheckBox ? this.setState({ manageOwnJobsOnlyCheckBox: false }) : this.setState({ manageOwnJobsOnlyCheckBox: true })
                break;
            case 'ownemailsonly':
                (this.state.ownEmailOnlyCheckBox) ? this.setState({ ownEmailOnlyCheckBox: false }) : this.setState({ ownEmailOnlyCheckBox: true })
                break;
            case 'savedcandidate':
                (this.state.savedCandidatesCheckBox) ? this.setState({ savedCandidatesCheckBox: false }) : this.setState({ savedCandidatesCheckBox: true })
                break;
            case 'packages':
                (this.state.packagesCheckBox) ? this.setState({ packagesCheckBox: false }) : this.setState({ packagesCheckBox: true })
                break;
            case 'transactions':
                (this.state.transactionsCheckBox) ? this.setState({ transactionsCheckBox: false }) : this.setState({ transactionsCheckBox: true })
                break;
            case 'meetings':
                (this.state.meetingsCheckBox) ? this.setState({ meetingsCheckBox: false }) : this.setState({ meetingsCheckBox: true })
                break;
        }
    }

    callFunction = (index) => {
        let value = index.toString();
        switch (value) {
            case '0':
                this.setState({
                    isBasicInformationBtnSelected: true,
                    isOtherInformationBtnSelected: false,
                    isSocialLinksBtnSelected: false,
                    isAddressBtnSelected: false,
                    isAccountMemberBtnSelected: false,
                    isTeamMemberBtnSelected: false,
                });
                break;
            case '1':
                this.setState({
                    isBasicInformationBtnSelected: false,
                    isOtherInformationBtnSelected: true,
                    isSocialLinksBtnSelected: false,
                    isAddressBtnSelected: false,
                    isAccountMemberBtnSelected: false,
                    isTeamMemberBtnSelected: false,
                });
                break;
            case '2':
                this.setState({
                    isBasicInformationBtnSelected: false,
                    isOtherInformationBtnSelected: false,
                    isSocialLinksBtnSelected: true,
                    isAddressBtnSelected: false,
                    isAccountMemberBtnSelected: false,
                    isTeamMemberBtnSelected: false,
                });
                break;
            case '3':
                this.setState({
                    isBasicInformationBtnSelected: false,
                    isOtherInformationBtnSelected: false,
                    isSocialLinksBtnSelected: false,
                    isAddressBtnSelected: true,
                    isAccountMemberBtnSelected: false,
                    isTeamMemberBtnSelected: false,
                });
                break;
            case '4':
                this.setState({
                    isBasicInformationBtnSelected: false,
                    isOtherInformationBtnSelected: false,
                    isSocialLinksBtnSelected: false,
                    isAddressBtnSelected: false,
                    isAccountMemberBtnSelected: true,
                    isTeamMemberBtnSelected: false,
                });
                break;
            case '5':
                this.setState({
                    isBasicInformationBtnSelected: false,
                    isOtherInformationBtnSelected: false,
                    isSocialLinksBtnSelected: false,
                    isAddressBtnSelected: false,
                    isAccountMemberBtnSelected: false,
                    isTeamMemberBtnSelected: true,
                });
                break;
        }
        let data = this.state.componyProfileMenus;
        for (let i = 0; i < data.length; i++)
            data[i].status = false;
        data[index].status = true;
        this.setState({ componyProfileMenus: data });
    }
    eyeConfirmPasswordPress = () => {
        if (this.state.secureConfirmPasswordText) {
            this.setState({ secureConfirmPasswordText: false });
        } else {
            this.setState({ secureConfirmPasswordText: true });
        }
    }
    eyePasswordPress = () => {
        if (this.state.securePasswordText) {
            this.setState({ securePasswordText: false });
        } else {
            this.setState({ securePasswordText: true });
        }
    }
    basicInformationCallApi() {
        Keyboard.dismiss()
        // --------------- Get Values into variables -----------------------
        let firstName = this.state.firstName.trim();
        let lastName = this.state.lastName.trim();
        let componyName = this.state.componyName.trim();
        let email = this.state.email.trim();
        let profileUrl = this.state.profileUrl.trim();
        let profileForPublicView = this.state.profileForPublicView.trim();
        let phone = this.state.phone.trim();
        // -------------------Empty Validation Check------------------------  
        if (firstName.length <= 0) {
            msgProvider.toast(msgText.emptyFirstName[config.language], 'center')
            return false;
        }
        if (lastName.length <= 0) {
            msgProvider.toast(msgText.emptyLastName[config.language], 'center')
            return false;
        }
        if (componyName.length <= 0) {
            msgProvider.toast(msgText.emptyCompanyName[config.language], 'center')
            return false;
        }
        if (email.length <= 0) {
            msgProvider.toast(msgText.emptyEmail[config.language], 'center')
            return false;
        }
        if (config.regemail.test(email) != true) {
            msgProvider.toast(msgText.validEmailAddress[config.language], 'center')
            return false
        }
        if (profileUrl.length <= 0) {
            msgProvider.toast(msgText.emptyProfileUrl[config.language], 'center')
            return false;
        }
        // if (profileForPublicView.length <= 0) {
        //     msgProvider.toast(msgText.emptyProfileView[config.language], 'center')
        //     return false;
        // }
        if (phone.length <= 0) {
            msgProvider.toast(msgText.emptyPhoneNumber[config.language], 'center')
            return false;
        }
        if (phone.length < 10) {
            msgProvider.toast(msgText.phoneNumberIsTooShort[config.language], 'center')
            return false;
        }

        // this.props.navigation.navigate('Employer');
        // ----------------- Make Url For Particular API ----------------
        // let url = config.apiUrl + "login.php";
        // console.log(url);
        // -------------- Create Navigation Object/Instance -------------
        // const { navigate } = this.props.navigation;

        //--------- Create Form Data Object And Set Values into it ------- 
        // var data = new FormData();
        // data.append('email', email)
        // data.append('password', password)
        // data.append('device_type', config.deviceType)
        // data.append("player_id", player_id_me1)
        // data.append("action_type", 'normal_login')
        // data.append('language', config.language)

        // ---------- Print Data Object To Verify Your Data----------------
        // console.log('data', data);

        //----------- Call GetAPI OR POST To Send Your Request ------------- 
        // apifuntion.postApi(url, data).then((obj) => {
        //     if (obj.success == 'true') {
        //         console.log(obj);
        //         var userDetails = obj.user_details;
        //         const userValue = { email: email, password: password };

        //         //------------------ Set User Details and Auto Login Details Into LocalStorage ---------------
        //         localStorage.setItemObject('user_login', userValue);
        //         localStorage.setItemObject('user_arr', userDetails);

        //         // --------------- Send Welcome notification to user -------------------
        //         if (obj.notification_arr != 'NA') {
        //             notification.notification_arr(obj.notification_arr);
        //         }

        //         //-----------Show Success Message Toast---------
        //         msgProvider.toast(obj.msg[0], 'center')
        //         this.setState({ email: '', password: '' });
        //         this.props.navigation.navigate('Home')
        //     } else {
        //         //-----------Show Failed Message Toast-----------
        //         msgProvider.toast(obj.msg[0], 'center')
        //         return false;
        //     }
        // }).catch((error) => {
        //     console.log(error);
        // });
    }

    _openCamera = () => {
        mediaprovider.launchCamera().then((obj) => {
            console.log(obj.path);
            this.setState({
                profile_image: obj.path,
                mediamodal: false,
                cameraon: true,
            })
        })

    }
    _openGellery = () => {
        mediaprovider.launchGellery().then((obj) => {
            console.log(obj.path);
            this.setState({
                profile_image: obj.path,
                mediamodal: false,
                cameraon: true,
            })
        })
        // console.log(this.state.profile_image)
    }

    addressLocationApiCall() {
        Keyboard.dismiss()
        // --------------- Get Values into variables -----------------------
        let address = this.state.address.trim();
        // -------------------Empty Validation Check------------------------  
        if (address.length <= 0) {
            msgProvider.toast(msgText.addressEmptyMsg[config.language], 'center')
            return false;
        }
    }

    socialLinkCallApi() {
        Keyboard.dismiss()
        // --------------- Get Values into variables -----------------------
        let facebook = this.state.facebook.trim();
        let twitter = this.state.twitter.trim();
        let linkedIn = this.state.linkedIn.trim();
        let dribble = this.state.dribble.trim();
        // -------------------Empty Validation Check------------------------  
        if (facebook.length <= 0) {
            msgProvider.toast(msgText.facebookEmptyMsg[config.language], 'center')
            return false;
        }
        if (twitter.length <= 0) {
            msgProvider.toast(msgText.twitterEmptyMsg[config.language], 'center')
            return false;
        }
        if (linkedIn.length <= 0) {
            msgProvider.toast(msgText.linkedInEmptyMsg[config.language], 'center')
            return false;
        }
        if (dribble.length <= 0) {
            msgProvider.toast(msgText.dribbleEmptyMsg[config.language], 'center')
            return false;
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content'
                            backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />
                        <Cameragallery mediamodal={this.state.mediamodal} Camerapopen={() => { this._openCamera() }}
                            Galleryopen={() => { this._openGellery() }} Canclemedia={() => { this.setState({ mediamodal: false }) }}
                        />
                        {/* Add Account Member */}
                        <Modal
                            animationType={'slide'}
                            transparent={true}
                            backgroundColor={'red'}
                            visible={this.state.isAddAccountMember}
                            onRequestClose={() => { console.log("Modal Close") }}>
                            <View style={{
                                flex: 1,
                                backgroundColor: Colors.whiteColor,
                                shadowColor: '#000',
                                shadowOffset: {
                                    width: 0,
                                    height: 2,
                                },
                                shadowOpacity: 5,
                                shadowRadius: 5,
                                elevation: 22,
                            }}>
                                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                                    <TouchableOpacity activeOpacity={.7} onPress={() => {
                                        this.setState({ isAddAccountMember: false })
                                    }}>
                                        <View style={{ height: mobileW * 5 / 100, }} />
                                        <View style={{
                                            width: mobileW * 15 / 100,
                                            borderBottomColor: Colors.darkGreenColor,
                                            borderRadius: 6,
                                            alignSelf: 'center',
                                            borderBottomWidth: 6
                                        }}></View>
                                    </TouchableOpacity>
                                    <View style={{ width: mobileW * 90 / 100, alignSelf: 'center' }}>
                                        <View style={{ marginTop: mobileW * 5 / 100, }}>
                                            <Text style={{
                                                fontFamily: Font.montserrat_Bold,
                                                color: Colors.textColor,
                                                fontSize: Font.fontSize4
                                            }}>
                                                Add Account Member
                                            </Text>
                                        </View>
                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Member First Name
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'First Name'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ firstName: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Member Last Name
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Last Name'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ firstName: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Member Username
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Username'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ firstName: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Member Email
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Email'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    // value={'demouser33@eyecix.com'}
                                                    onChangeText={(input) => this.setState({ firstName: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>
                                        <View style={{
                                            width: '100%', marginTop: mobileW * 2 / 100,
                                            marginBottom: mobileW * 2 / 100,
                                        }}>
                                            <View style={{ width: mobileW * 82 / 100, alignSelf: 'center' }}>
                                                <Text style={{
                                                    marginBottom: mobileW * 2.5 / 100,
                                                    color: Colors.greyColor,
                                                    fontSize: Font.fontSize3half,
                                                    fontFamily: Font.montserrat_Regular
                                                }}>
                                                    Password
                                                </Text>
                                            </View>
                                            <View style={{
                                                alignSelf: 'center',
                                                borderColor: Colors.greyColor,
                                                borderWidth: 0.7,
                                                width: mobileW * 90 / 100,
                                                flexDirection: 'row',
                                                justifyContent: 'space-between'
                                            }}>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Password'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={16}
                                                    minLength={6}
                                                    secureTextEntry={this.state.securePasswordText}
                                                    onChangeText={(input) => this.setState({ password: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={{
                                                        color: Colors.textColor,
                                                        width: mobileW * 75 / 100,
                                                        paddingVertical: mobileW * 3.5 / 100,
                                                        paddingLeft: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular
                                                    }}
                                                ></TextInput>
                                                <TouchableOpacity onPress={() => { this.eyePasswordPress() }}
                                                    style={styles.eyeButton}>
                                                    <Text style={styles.showHideText}>{this.state.securePasswordText ? "Show" : "Hide"}</Text>
                                                </TouchableOpacity>
                                            </View>
                                        </View>
                                        <View style={{ width: '100%', marginTop: mobileW * 2 / 100, marginBottom: mobileW * 3 / 100, }}>
                                            <View style={{ width: mobileW * 82 / 100, alignSelf: 'center' }}>
                                                <Text style={{
                                                    marginBottom: mobileW * 2.5 / 100,
                                                    color: Colors.greyColor,
                                                    fontSize: Font.fontSize3half,
                                                    fontFamily: Font.montserrat_Regular
                                                }}>
                                                    Confirm Password
                                                </Text>
                                            </View>
                                            <View style={{
                                                alignSelf: 'center',
                                                borderColor: Colors.greyColor,
                                                borderWidth: 0.7,
                                                width: mobileW * 90 / 100,
                                                flexDirection: 'row',
                                                justifyContent: 'space-between'
                                            }}>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Confirm Password'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={16}
                                                    minLength={6}
                                                    secureTextEntry={this.state.secureConfirmPasswordText}
                                                    onChangeText={(input) => this.setState({ confirmPassword: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={{
                                                        color: Colors.textColor,
                                                        width: mobileW * 75 / 100,
                                                        paddingVertical: mobileW * 3.5 / 100,
                                                        paddingLeft: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular
                                                    }}
                                                ></TextInput>
                                                <TouchableOpacity onPress={() => { this.eyeConfirmPasswordPress() }}
                                                    style={styles.eyeButton}>
                                                    <Text style={styles.showHideText}>{this.state.secureConfirmPasswordText ? "Show" : "Hide"}</Text>
                                                </TouchableOpacity>
                                            </View>
                                        </View>

                                        <View style={{ marginTop: mobileW * 2 / 100, }}>
                                            <Text style={{
                                                fontFamily: Font.montserrat_Bold,
                                                color: Colors.textColor,
                                                fontSize: Font.fontSize4
                                            }}>
                                                Member Permissions
                                            </Text>
                                        </View>
                                        <View style={{ flexDirection: 'row', marginTop: mobileW * 4 / 100 }}>
                                            <TouchableOpacity
                                                onPress={() => { this.checkBoxCondition('postnewjob') }}
                                                style={{
                                                    flexDirection: 'row', width: mobileW * 10 / 100,
                                                    justifyContent: 'space-between',
                                                }}>
                                                {this.state.postNewJobCheckBox ? <MaterialCommunityIcons
                                                    name='check-box-outline' size={35}
                                                    color={Colors.darkGreenColor} />
                                                    : <MaterialCommunityIcons name='checkbox-blank-outline' size={35}
                                                        color={Colors.darkGreenColor} />}
                                            </TouchableOpacity>
                                            <CheckBoxText title="Post New Job" />
                                        </View>

                                        <View style={{ flexDirection: 'row', paddingVertical: mobileW * 2 / 100 }}>
                                            <TouchableOpacity
                                                onPress={() => { this.checkBoxCondition('managejobs') }}
                                                style={{
                                                    flexDirection: 'row', width: mobileW * 10 / 100,
                                                    justifyContent: 'space-between',
                                                }}>
                                                {this.state.manageJobsCheckBox ? <MaterialCommunityIcons
                                                    name='check-box-outline' size={35}
                                                    color={Colors.darkGreenColor} />
                                                    : <MaterialCommunityIcons name='checkbox-blank-outline' size={35}
                                                        color={Colors.darkGreenColor} />}
                                            </TouchableOpacity>
                                            <CheckBoxText title="Manage Jobs" />
                                        </View>

                                        <View style={{ width: mobileW * 70 / 100, alignSelf: 'center', }}>
                                            <View style={{ flexDirection: 'row', paddingVertical: mobileW * 2 / 100 }}>
                                                <TouchableOpacity
                                                    onPress={() => { this.checkBoxCondition('manageownjobsonly') }}
                                                    style={{
                                                        flexDirection: 'row', width: mobileW * 10 / 100,
                                                        justifyContent: 'space-between',
                                                    }}>
                                                    {this.state.manageOwnJobsOnlyCheckBox ? <MaterialCommunityIcons
                                                        name='check-box-outline' size={35}
                                                        color={Colors.darkGreenColor} />
                                                        : <MaterialCommunityIcons name='checkbox-blank-outline' size={35}
                                                            color={Colors.darkGreenColor} />}
                                                </TouchableOpacity>
                                                <CheckBoxText title="Manage Own Jobs Only" />
                                            </View>
                                            <View style={{ flexDirection: 'row', paddingVertical: mobileW * 2 / 100 }}>
                                                <TouchableOpacity
                                                    onPress={() => { this.checkBoxCondition('ownemailsonly') }}
                                                    style={{
                                                        flexDirection: 'row', width: mobileW * 10 / 100,
                                                        justifyContent: 'space-between',
                                                    }}>
                                                    {this.state.ownEmailOnlyCheckBox ? <MaterialCommunityIcons
                                                        name='check-box-outline' size={35}
                                                        color={Colors.darkGreenColor} />
                                                        : <MaterialCommunityIcons name='checkbox-blank-outline' size={35}
                                                            color={Colors.darkGreenColor} />}
                                                </TouchableOpacity>
                                                <CheckBoxText title="Own Emails Only" />
                                            </View>
                                        </View>
                                        <View style={{ flexDirection: 'row', paddingVertical: mobileW * 2 / 100 }}>
                                            <TouchableOpacity
                                                onPress={() => { this.checkBoxCondition('savedcandidate') }}
                                                style={{
                                                    flexDirection: 'row', width: mobileW * 10 / 100,
                                                    justifyContent: 'space-between',
                                                }}>
                                                {this.state.savedCandidatesCheckBox ? <MaterialCommunityIcons
                                                    name='check-box-outline' size={35}
                                                    color={Colors.darkGreenColor} />
                                                    : <MaterialCommunityIcons name='checkbox-blank-outline' size={35}
                                                        color={Colors.darkGreenColor} />}
                                            </TouchableOpacity>
                                            <CheckBoxText title="Saved Candidate" />
                                        </View>

                                        <View style={{ flexDirection: 'row', paddingVertical: mobileW * 2 / 100 }}>
                                            <TouchableOpacity
                                                onPress={() => { this.checkBoxCondition('packages') }}
                                                style={{
                                                    flexDirection: 'row', width: mobileW * 10 / 100,
                                                    justifyContent: 'space-between',
                                                }}>
                                                {this.state.packagesCheckBox ? <MaterialCommunityIcons
                                                    name='check-box-outline' size={35}
                                                    color={Colors.darkGreenColor} />
                                                    : <MaterialCommunityIcons name='checkbox-blank-outline' size={35}
                                                        color={Colors.darkGreenColor} />}
                                            </TouchableOpacity>
                                            <CheckBoxText title="Packages" />
                                        </View>

                                        <View style={{ flexDirection: 'row', paddingVertical: mobileW * 2 / 100 }}>
                                            <TouchableOpacity
                                                onPress={() => { this.checkBoxCondition('transactions') }}
                                                style={{
                                                    flexDirection: 'row', width: mobileW * 10 / 100,
                                                    justifyContent: 'space-between',
                                                }}>
                                                {this.state.transactionsCheckBox ? <MaterialCommunityIcons
                                                    name='check-box-outline' size={35}
                                                    color={Colors.darkGreenColor} />
                                                    : <MaterialCommunityIcons name='checkbox-blank-outline' size={35}
                                                        color={Colors.darkGreenColor} />}
                                            </TouchableOpacity>
                                            <CheckBoxText title="Transactions" />
                                        </View>

                                        <View style={{ flexDirection: 'row', paddingVertical: mobileW * 2 / 100 }}>
                                            <TouchableOpacity
                                                onPress={() => { this.checkBoxCondition('meetings') }}
                                                style={{
                                                    flexDirection: 'row', width: mobileW * 10 / 100,
                                                    justifyContent: 'space-between',
                                                }}>
                                                {this.state.meetingsCheckBox ? <MaterialCommunityIcons
                                                    name='check-box-outline' size={35}
                                                    color={Colors.darkGreenColor} />
                                                    : <MaterialCommunityIcons name='checkbox-blank-outline' size={35}
                                                        color={Colors.darkGreenColor} />}
                                            </TouchableOpacity>
                                            <CheckBoxText title="Meetings" />
                                        </View>
                                        <View style={{ marginBottom: mobileW * 2 / 100 }}>
                                            <AppButton
                                                onPress={() => { this.setState({ isAddAccountMember: false }) }}
                                                title="add member"
                                                color={Colors.whiteColor}
                                                backgroundColor={Colors.darkGreenColor}
                                            />
                                        </View>
                                    </View>
                                </ScrollView>
                            </View>
                        </Modal>
                        {/* Add Account Member */}

                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', backgroundColor: Colors.silverLightColor, height: mobileH * 8 / 100,
                        }}>
                            <TouchableOpacity style={{ width: '15%', }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={require('../../icons/back_icon.png')}
                                    style={{
                                        marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100,
                                        height: mobileW * 7 / 100, resizeMode: 'contain'
                                    }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '70%', justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Company Profile</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={{ width: '15%' }}>
                                <Image source={require('../../icons/save.png')}
                                    style={{
                                        alignSelf: 'center',
                                        width: mobileW * 10 / 100,
                                        height: mobileW * 10 / 100, resizeMode: 'contain'
                                    }}>
                                </Image>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}

                        <View style={{
                            width: '100%', height: mobileH * 17.7 / 100,
                        }}>
                            <View style={{
                                width: '100%', height: mobileH * 12 / 100, backgroundColor: Colors.silverLightColor
                            }}>
                                <TouchableOpacity
                                    activeOpacity={.7} onPress={() => { this.setState({ mediamodal: true }) }}
                                    style={{
                                        alignSelf: 'center',
                                        backgroundColor: Colors.darkGreenColor, padding: mobileW * 1.0 / 100
                                    }}>
                                    <Text style={{ color: Colors.whiteColor, fontSize: Font.fontSize3, fontFamily: Font.montserrat_Medium }}>Add Cover Photo</Text>
                                </TouchableOpacity>

                            </View>
                            <View style={{
                                alignSelf: 'center', position: 'absolute', bottom: 0,
                            }}>
                                <View style={{
                                    width: mobileW * 22 / 100, height: mobileW * 22 / 100, backgroundColor: Colors.whiteColor, borderRadius: mobileW * 50 / 100
                                }}>
                                    <Image
                                        style={{
                                            width: mobileW * 22 / 100, height: mobileW * 22 / 100,
                                        }}
                                        resizeMode={'contain'}
                                        borderRadius={mobileW * 50 / 100}
                                        source={require('../../icons/employer_profile_icon.png')}
                                    />
                                </View>
                                {/* */}
                            </View>
                        </View>
                        <View style={{ width: mobileW * 90 / 100, alignSelf: 'center' }}>
                            <View style={{ marginTop: mobileW * 3.5 / 100 }}>
                                <View style={{ alignSelf: 'center' }}>
                                    <Text style={{ fontSize: Font.fontSize5, fontFamily: Font.montserrat_Bold, color: Colors.textColor }}>
                                        Zeeva Hiring Co
                                    </Text>
                                </View>
                            </View>
                        </View>
                        {/* Company Profile Menus */}
                        <FlatList
                            style={{
                                width: mobileW * 100 / 100, alignSelf: 'center',
                                marginTop: mobileW * 2 / 100
                            }}
                            horizontal={true}
                            data={this.state.componyProfileMenus}
                            showsHorizontalScrollIndicator={false}
                            renderItem={({ item, index }) => {
                                return (
                                    <TouchableOpacity onPress={() => {
                                        this.callFunction(index);
                                    }} activeOpacity={.7}>
                                        <Text style={{
                                            padding: 20,
                                            borderBottomColor: item.status ? Colors.darkGreenColor : Colors.greyColor,
                                            borderBottomWidth: item.status ? 2 : 1,
                                            color: item.status ? Colors.textColor : Colors.greyColor,
                                            fontFamily: item.status ? Font.montserrat_Bold : Font.montserrat_Medium,
                                            fontSize: Font.fontSize3
                                        }}>
                                            {item.option}
                                        </Text>
                                    </TouchableOpacity>
                                );
                            }}
                        >
                        </FlatList>
                        {/* Company Profile Menus */}

                        <View style={styles.companyProfileBodyStyle}>
                            {
                                this.state.isBasicInformationBtnSelected == true &&
                                <View style={{
                                    marginTop: mobileW * 8 / 100,
                                    marginBottom: mobileW * 20 / 100
                                }}>
                                    <CompanyProfileHeading
                                        title={'Basic Information'}
                                        color={Colors.textColor}
                                    />

                                    <View style={{ marginTop: mobileW * 2.5 / 100 }}>


                                        <View style={styles.containerStyle}>
                                            <View style={{ width: mobileW * 90 / 100, alignSelf: 'center' }}>
                                                <Text style={styles.textFieldLabel}>
                                                    First Name
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'First Name'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ firstName: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Last Name
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Last Name'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ lastName: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Company Name
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Componay Name'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ componyName: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Email
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Email'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ email: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Profile URL
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Profile URL'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ profileUrl: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Profile for public view
                                                </Text>
                                            </View>

                                            <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                                <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                                    <View style={{
                                                        color: Colors.textColor,
                                                        alignSelf: 'center',
                                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                                        borderWidth: 0.7,
                                                        width: mobileW * 90 / 100,
                                                        paddingVertical: mobileW * 3.5 / 100,
                                                        paddingHorizontal: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular,
                                                        flexDirection: 'row',
                                                        justifyContent: 'space-between'
                                                    }}>
                                                        <View style={{ justifyContent: 'center' }}>
                                                            <Text style={{
                                                                color: Colors.textColor,
                                                                fontSize: Font.fontSize4,
                                                                fontFamily: Font.montserrat_Regular
                                                            }}>
                                                                Yes
                                                            </Text>
                                                        </View>
                                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                                        </View>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                        </View>



                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Phone
                                                </Text>
                                            </View>

                                            <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                                <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                                    <View style={{ width: mobileW * 90 / 100, flexDirection: 'row', justifyContent: 'space-around' }}>
                                                        <View style={{
                                                            color: Colors.textColor,
                                                            alignSelf: 'center',
                                                            borderColor: Colors.greyColor,
                                                            borderWidth: 0.7,
                                                            width: mobileW * 20 / 100,
                                                            paddingVertical: mobileW * 3.5 / 100,
                                                            paddingHorizontal: 18,
                                                            fontSize: Font.fontSize4,
                                                            fontFamily: Font.montserrat_Regular,
                                                            flexDirection: 'row',
                                                            justifyContent: 'space-between'
                                                        }}>
                                                            <View style={{ justifyContent: 'center' }}>
                                                                <Text style={{
                                                                    color: Colors.textColor,
                                                                    fontSize: Font.fontSize4,
                                                                    fontFamily: Font.montserrat_Regular
                                                                }}>+ 42</Text>
                                                            </View>
                                                            <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                                <MaterialCommunityIcons name='menu-down' size={27} color={Colors.textColor} />
                                                            </View>
                                                        </View>

                                                        <TextInput
                                                            keyboardType='number-pad'
                                                            placeholder={'Phone'}
                                                            placeholderTextColor={Colors.textColor}
                                                            maxLength={10}
                                                            onChangeText={(input) => this.setState({ password: input })}
                                                            onSubmitEditing={() => { Keyboard.dismiss() }}
                                                            style={{
                                                                color: Colors.textColor,
                                                                alignSelf: 'center',
                                                                borderColor: Colors.greyColor,
                                                                borderWidth: 0.7,
                                                                width: mobileW * 67 / 100,
                                                                paddingVertical: mobileW * 3.5 / 100,
                                                                paddingLeft: 18,
                                                                fontSize: Font.fontSize4,
                                                                fontFamily: Font.montserrat_Regular
                                                            }}
                                                        ></TextInput>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Website
                                                </Text>
                                            </View>

                                            <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                                <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                                    <View style={{
                                                        color: Colors.textColor,
                                                        alignSelf: 'center',
                                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                                        borderWidth: 0.7,
                                                        width: mobileW * 90 / 100,
                                                        paddingVertical: mobileW * 3.5 / 100,
                                                        paddingHorizontal: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular,
                                                        flexDirection: 'row',
                                                        justifyContent: 'space-between'
                                                    }}>
                                                        <View style={{ justifyContent: 'center' }}>
                                                            <Text style={{
                                                                color: Colors.textColor,
                                                                fontSize: Font.fontSize4,
                                                                fontFamily: Font.montserrat_Regular
                                                            }}>
                                                                Select
                                                            </Text>
                                                        </View>
                                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                                        </View>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Sector
                                                </Text>
                                            </View>

                                            <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                                <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                                    <View style={{
                                                        color: Colors.textColor,
                                                        alignSelf: 'center',
                                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                                        borderWidth: 0.7,
                                                        width: mobileW * 90 / 100,
                                                        paddingVertical: mobileW * 3.5 / 100,
                                                        paddingHorizontal: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular,
                                                        flexDirection: 'row',
                                                        justifyContent: 'space-between'
                                                    }}>
                                                        <View style={{ justifyContent: 'center' }}>
                                                            <Text style={{
                                                                color: Colors.textColor,
                                                                fontSize: Font.fontSize4,
                                                                fontFamily: Font.montserrat_Regular
                                                            }}>
                                                                Select
                                                            </Text>
                                                        </View>
                                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                                        </View>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Founded Date
                                                </Text>
                                            </View>

                                            <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                                <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                                    <View style={{
                                                        color: Colors.textColor,
                                                        alignSelf: 'center',
                                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                                        borderWidth: 0.7,
                                                        width: mobileW * 90 / 100,
                                                        paddingVertical: mobileW * 3.5 / 100,
                                                        paddingHorizontal: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular,
                                                        flexDirection: 'row',
                                                        justifyContent: 'space-between'
                                                    }}>
                                                        <View style={{ justifyContent: 'center' }}>
                                                            <Text style={{
                                                                color: Colors.textColor,
                                                                fontSize: Font.fontSize4,
                                                                fontFamily: Font.montserrat_Regular
                                                            }}>
                                                                DD/MM/YYYY
                                                            </Text>
                                                        </View>
                                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                            <Image source={require('../../icons/calender_blue_icon.png')} style={{ width: mobileW * 7 / 100, height: mobileW * 7 / 100 }} />
                                                        </View>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                        </View>
                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    About Company
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    value={this.state.discription}
                                                    placeholder={'About Company'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    multiline={true}
                                                    onChangeText={(input) => this.setState({ firstName: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={{
                                                        textAlignVertical: 'top',
                                                        color: Colors.textColor,
                                                        alignSelf: 'center',
                                                        borderColor: Colors.greyColor,
                                                        borderWidth: 0.7,
                                                        width: mobileW * 90 / 100,
                                                        height: mobileW * 30 / 100,
                                                        paddingLeft: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular
                                                    }}
                                                ></TextInput>
                                            </View>
                                        </View>
                                        <View style={{ marginTop: mobileW * 20 / 100 }}>
                                            <AppButton
                                                onPress={() => { this.basicInformationCallApi() }}
                                                title={"continue"}
                                                color={Colors.whiteColor}
                                                backgroundColor={Colors.darkGreenColor}
                                            />
                                        </View>
                                    </View>
                                </View>
                            }
                            {
                                this.state.isOtherInformationBtnSelected == true &&
                                <View style={{
                                    marginTop: mobileW * 8 / 100,
                                    marginBottom: mobileW * 20 / 100
                                }}>
                                    <CompanyProfileHeading
                                        title={'Other Information'}
                                        color={Colors.textColor}
                                    />

                                    <View style={{ marginTop: mobileW * 3 / 100 }}>
                                        <Text style={{
                                            color: Colors.greyColor,
                                            fontSize: Font.fontSize3half,
                                            fontFamily: Font.montserrat_Regular
                                        }}>Founded Since*</Text>
                                    </View>
                                    <View style={{ alignItems: 'stretch', marginTop: mobileW * 3 / 100 }}>
                                        <Text style={{ color: Colors.darkGreenColor }}>{this.state.foundedSince}</Text>
                                        <Slider
                                            style={{ color: Colors.darkGreenColor, width: "90%" }}
                                            value={this.state.foundedSince}
                                            onValueChange={(value) => this.setState({ foundedSince: value })} />
                                    </View>



                                    <View style={{ marginTop: mobileW * 20 / 100 }}>
                                        <AppButton
                                            onPress={() => { }}
                                            title={"continue"}
                                            color={Colors.whiteColor}
                                            backgroundColor={Colors.darkGreenColor}
                                        />
                                    </View>
                                </View>
                            }
                            {
                                this.state.isSocialLinksBtnSelected == true &&
                                <View style={{
                                    marginTop: mobileW * 8 / 100,
                                    marginBottom: mobileW * 20 / 100
                                }}>
                                    <CompanyProfileHeading
                                        title={'Social Links'}
                                        color={Colors.textColor}
                                    />
                                    <View style={{ marginTop: mobileW * 2.5 / 100 }}>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Facebook
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    value={this.state.facebook}
                                                    placeholder={'Facebook'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ facebook: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>
                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Twitter
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    value={this.state.twitter}
                                                    keyboardType='default'
                                                    placeholder={'Twitter'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ twitter: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>
                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    LinkedIn
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    value={this.state.linkedIn}
                                                    keyboardType='default'
                                                    placeholder={'LinkedIn'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ linkedIn: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>
                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Dribble
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Dribble'}
                                                    value={this.state.dribble}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ dribble: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>
                                        <View style={{ marginTop: mobileW * 10 / 100 }}>
                                            <AppButton
                                                onPress={() => { this.socialLinkCallApi() }}
                                                title={"continue"}
                                                color={Colors.whiteColor}
                                                backgroundColor={Colors.darkGreenColor}
                                            />
                                        </View>
                                    </View>
                                </View>
                            }
                            {
                                this.state.isAddressBtnSelected == true &&
                                <View style={{ marginTop: mobileW * 8 / 100, marginBottom: mobileW * 20 / 100 }}>
                                    <CompanyProfileHeading
                                        title={'Address / Location'}
                                        color={Colors.textColor}
                                    />
                                    <View style={{ marginTop: mobileW * 2.5 / 100 }}>


                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Country
                                                </Text>
                                            </View>

                                            <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                                <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                                    <View style={{
                                                        color: Colors.textColor,
                                                        alignSelf: 'center',
                                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                                        borderWidth: 0.7,
                                                        width: mobileW * 90 / 100,
                                                        paddingVertical: mobileW * 3.5 / 100,
                                                        paddingHorizontal: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular,
                                                        flexDirection: 'row',
                                                        justifyContent: 'space-between'
                                                    }}>
                                                        <View style={{ justifyContent: 'center' }}>
                                                            <Text style={{
                                                                color: Colors.textColor,
                                                                fontSize: Font.fontSize4,
                                                                fontFamily: Font.montserrat_Regular
                                                            }}>
                                                                Select Country
                                                            </Text>
                                                        </View>
                                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                                        </View>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    State
                                                </Text>
                                            </View>

                                            <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                                <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                                    <View style={{
                                                        color: Colors.textColor,
                                                        alignSelf: 'center',
                                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                                        borderWidth: 0.7,
                                                        width: mobileW * 90 / 100,
                                                        paddingVertical: mobileW * 3.5 / 100,
                                                        paddingHorizontal: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular,
                                                        flexDirection: 'row',
                                                        justifyContent: 'space-between'
                                                    }}>
                                                        <View style={{ justifyContent: 'center' }}>
                                                            <Text style={{
                                                                color: Colors.textColor,
                                                                fontSize: Font.fontSize4,
                                                                fontFamily: Font.montserrat_Regular
                                                            }}>
                                                                Select State
                                                            </Text>
                                                        </View>
                                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                                        </View>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    City
                                                </Text>
                                            </View>

                                            <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                                <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                                    <View style={{
                                                        color: Colors.textColor,
                                                        alignSelf: 'center',
                                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                                        borderWidth: 0.7,
                                                        width: mobileW * 90 / 100,
                                                        paddingVertical: mobileW * 3.5 / 100,
                                                        paddingHorizontal: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular,
                                                        flexDirection: 'row',
                                                        justifyContent: 'space-between'
                                                    }}>
                                                        <View style={{ justifyContent: 'center' }}>
                                                            <Text style={{
                                                                color: Colors.textColor,
                                                                fontSize: Font.fontSize4,
                                                                fontFamily: Font.montserrat_Regular
                                                            }}>
                                                                Select City
                                                            </Text>
                                                        </View>
                                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                                        </View>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Full Address
                                                </Text>
                                            </View>
                                            <View>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Address'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ address: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                        </View>

                                        <View style={styles.containerStyle}>
                                            <View style={styles.labelStyle}>
                                                <Text style={styles.textFieldLabel}>
                                                    Postal Code
                                                </Text>
                                            </View>

                                            <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                                <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                                    <View style={{
                                                        color: Colors.textColor,
                                                        alignSelf: 'center',
                                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                                        borderWidth: 0.7,
                                                        width: mobileW * 90 / 100,
                                                        paddingVertical: mobileW * 3.5 / 100,
                                                        paddingHorizontal: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular,
                                                        flexDirection: 'row',
                                                        justifyContent: 'space-between'
                                                    }}>
                                                        <View style={{ justifyContent: 'center' }}>
                                                            <Text style={{
                                                                color: Colors.textColor,
                                                                fontSize: Font.fontSize4,
                                                                fontFamily: Font.montserrat_Regular
                                                            }}>
                                                                Postal Code
                                                            </Text>
                                                        </View>
                                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                                        </View>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                        </View>
                                    </View>

                                    <View style={{ width: '100%', height: mobileH * 25 / 100, }}>
                                        <Image style={{ alignSelf: 'center' }}
                                            source={require('../../icons/google_new_image.png')}
                                            style={{ width: '100%', height: mobileH * 25 / 100, }}
                                            resizeMode={'contain'}
                                        />
                                    </View>

                                    <View style={{ marginTop: mobileW * 10 / 100 }}>
                                        <AppButton
                                            onPress={() => { this.addressLocationApiCall() }}
                                            title={"continue"}
                                            color={Colors.whiteColor}
                                            backgroundColor={Colors.darkGreenColor}
                                        />
                                    </View>
                                </View>
                            }
                            {
                                this.state.isAccountMemberBtnSelected == true &&
                                <View style={{ marginTop: mobileW * 8 / 100, marginBottom: mobileW * 20 / 100 }}>
                                    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                        <CompanyProfileHeading
                                            title={'Account Members'}
                                            color={Colors.textColor}
                                        />
                                        <AddButton
                                            title={'Add'}
                                            color={Colors.whiteColor}
                                            backgroundColor={Colors.darkGreenColor}
                                            onPress={() => { this.setState({ isAddAccountMember: !this.state.isAddAccountMember }) }}
                                        />
                                    </View>
                                    <View style={{ marginTop: mobileW * 2.5 / 100 }}>
                                        <View style={{ width: mobileW * 91 / 100 }}>
                                            <FlatList
                                                data={this.state.accountMembersArray}
                                                renderItem={({ item, index }) =>
                                                    <View style={{
                                                        width: mobileW * 90 / 100,
                                                        marginBottom: 1,
                                                        marginTop: mobileW * 4 / 100,
                                                        alignSelf: 'center',
                                                        backgroundColor: Colors.whiteColor,
                                                        shadowColor: '#000',
                                                        shadowOffset: {
                                                            width: 2,
                                                            height: 2,
                                                        },
                                                        shadowOpacity: 0.5,
                                                        shadowRadius: 0.5,
                                                        elevation: 2,
                                                        paddingHorizontal: mobileW * 2 / 100,
                                                        paddingVertical: mobileW * 5 / 100
                                                    }}>
                                                        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                                            <View style={{ width: mobileW * 60 / 100 }}>
                                                                <Text style={{
                                                                    fontSize: Font.fontSize4,
                                                                    fontFamily: Font.montserrat_Bold,
                                                                    color: Colors.textColor
                                                                }}>{item.name}</Text>
                                                            </View>
                                                            <View>
                                                                <View style={{ flexDirection: 'row' }}>
                                                                    <Image source={localImage.editImage}
                                                                        style={{
                                                                            width: mobileW * 6 / 100,
                                                                            height: mobileW * 6 / 100
                                                                        }} />
                                                                    <Image source={localImage.deleteImage}
                                                                        style={{
                                                                            marginLeft: mobileW * 2 / 100,
                                                                            width: mobileW * 6 / 100,
                                                                            height: mobileW * 6 / 100
                                                                        }} />
                                                                </View>
                                                            </View>
                                                        </View>
                                                    </View>
                                                }
                                                keyExtractor={(item, index) => index.toString()}
                                            >
                                            </FlatList>
                                        </View>

                                    </View>
                                </View>
                            }
                            {
                                this.state.isTeamMemberBtnSelected == true &&
                                <View style={{ marginTop: mobileW * 8 / 100, marginBottom: mobileW * 20 / 100 }}>
                                    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                        <CompanyProfileHeading
                                            title={'Team Members'}
                                            color={Colors.textColor}
                                        />
                                        <AddButton
                                            title={'Add'}
                                            color={Colors.whiteColor}
                                            backgroundColor={Colors.darkGreenColor}
                                            onPress={() => { this.props.navigation.navigate('AddComponyTeamMembers'); }}
                                        />
                                    </View>
                                    <View style={{ marginTop: mobileW * 2.5 / 100 }}>
                                        <View style={{ width: mobileW * 91 / 100 }}>
                                            <FlatList
                                                numColumns={2}
                                                data={this.state.accountMembersArray}
                                                renderItem={({ item, index }) =>
                                                    <View style={{
                                                        width: mobileW * 43.5 / 100,
                                                        alignSelf: 'center',
                                                        alignItems: 'center',
                                                        backgroundColor: Colors.whiteColor,
                                                        shadowColor: '#000',
                                                        shadowOffset: {
                                                            width: 2,
                                                            height: 2,
                                                        },
                                                        shadowOpacity: 0.5,
                                                        shadowRadius: 0.5,
                                                        elevation: 2,
                                                        margin: mobileW * 1 / 100,
                                                        paddingVertical: mobileW * 5 / 100
                                                    }}>

                                                        <Text style={{
                                                            fontSize: Font.fontSize,
                                                            fontFamily: Font.montserrat_Bold,
                                                            color: Colors.textColor
                                                        }}>{item.name}</Text>

                                                        <View style={{ flexDirection: 'row', marginTop: mobileW * 5 / 100 }}>
                                                            <TouchableOpacity onPress={() => { this.props.navigation.navigate('EditCompanyTeamMembers') }} activeOpacity={.7}>
                                                                <Image source={localImage.editImage}
                                                                    style={{
                                                                        width: mobileW * 6 / 100,
                                                                        height: mobileW * 6 / 100
                                                                    }} />
                                                            </TouchableOpacity>
                                                            <Image source={localImage.deleteImage}
                                                                style={{
                                                                    marginLeft: mobileW * 3 / 100,
                                                                    width: mobileW * 6 / 100,
                                                                    height: mobileW * 6 / 100
                                                                }} />
                                                        </View>
                                                    </View>
                                                }
                                                keyExtractor={(item, index) => index.toString()}
                                            >
                                            </FlatList>
                                        </View>

                                    </View>
                                </View>
                            }
                        </View>
                        {/* CompanyProfileHeading */}
                    </KeyboardAwareScrollView>
                </ScrollView>
                <HideWithKeyboard>
                    <EmployerFooter
                        activepage='EmployerComponyProfileScreen' // active screen initially
                        usertype={1} // types of user set
                        footerpage={[
                            { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                            { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                            { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                            { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                        ]} // number of menus in bottom navigation bar
                        navigation={this.props.navigation} // send navigation object
                        imagestyle1={{
                            width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                            backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                        }}
                    />
                </HideWithKeyboard>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    textFieldLabel: {
        marginBottom: mobileW * 2 / 100,
        color: Colors.greyColor,
        fontSize: Font.fontSize3half,
        fontFamily: Font.montserrat_Regular
    },
    inputStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        paddingVertical: mobileW * 3.5 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    containerStyle: {
        width: '100%',
        marginTop: mobileW * 3 / 100,
        marginBottom: mobileW * 1 / 100,
    },
    labelStyle: {
        width: mobileW * 82 / 100, alignSelf: 'center'
    },
    companyProfileBodyStyle: {
        width: mobileW * 90 / 100, alignSelf: 'center'
    },
    profileButton: {
        height: mobileW * 14 / 100,
        justifyContent: 'center',
        alignItems: 'center'
    },
    eyeButton: {
        width: mobileW * 15 / 100,
        height: mobileW * 8 / 100,
        alignItems: 'center',
        justifyContent: 'center',
        alignSelf: 'center'
    },
    showHideText: {
        color: Colors.textColor,
        fontSize: Font.fontSize3
    },
});

const DATA = [
    {
        option: 'Basic Information',
        status: true
    },
    {
        option: 'Other Information',
        status: false
    },
    {
        option: 'Social Links',
        status: false
    },
    {
        option: 'Address / Location',
        status: false
    },
    {
        option: 'Account Member',
        status: false
    },
    {
        option: 'Team Member',
        status: false
    },
];


const ACCOUNTMEMBERS = [
    {
        name: 'Michele Snyder',
    },
    {
        name: 'Charlotte Davies',
    },
    {
        name: 'William Doe',
    },
    {
        name: 'Julian',
    },
    {
        name: 'Christopher',
    },
    {
        name: 'Maverick',
    },
    {
        name: 'Andrew',
    },
    {
        name: 'Joshua',
    },
];


const CompanyProfileHeading = ({ title, color }) => (
    <View>
        <Text style={{
            fontSize: Font.fontSize4,
            fontFamily: Font.montserrat_Bold,
            color: color
        }}>{title}</Text>
    </View>
);


const AddButton = ({ title, color, backgroundColor, onPress }) => (
    <TouchableOpacity
        activeOpacity={.7}
        onPress={onPress}
        style={{
            width: mobileW * 18 / 100,
            backgroundColor: backgroundColor
        }}>
        <Text style={{
            alignSelf: 'center',
            paddingVertical: mobileW * 0.8 / 100,
            color: color,
            fontFamily: Font.montserrat_Bold
        }}>
            {title}
        </Text>
    </TouchableOpacity>

);

const AppButton = ({ onPress, title, color, backgroundColor }) => (
    <TouchableOpacity
        style={[styles.profileButton, { backgroundColor: backgroundColor }]}
        activeOpacity={.7}
        onPress={onPress}
    >
        <Text style={{
            fontSize: Font.fontSize4,
            color: color,
            textTransform: 'uppercase',
            fontFamily: Font.montserrat_Bold
        }}>{title}</Text>
    </TouchableOpacity>
);
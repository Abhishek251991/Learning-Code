import React, { Component } from 'react'
import { Dimensions, Modal, TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, Keyboard } from 'react-native';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { ImageBackground } from 'react-native';
import EmployerFooter from './EmployerFooter';


const DATA = [
    {
        name: 'Accounting finance ', subName: 'Carter', city: 'Zürich', days: '4', status: false
    },
    {
        name: 'Accounting', subName: 'Christopher', city: 'Zürich', days: '14', status: true
    },
    {
        name: 'Agriculture', subName: 'Julian', city: 'Lucerne', days: '9', status: false
    },
    {
        name: 'Accounting finance', subName: 'Jayden', city: 'Gallen', days: '2', status: false
    },
    {
        name: 'Art', subName: 'Grayson', city: 'Winterthur', days: '7', status: false
    },
    {
        name: 'Education', subName: 'Lincoln', city: 'Lausanne', days: '2', status: false
    },
    {
        name: 'School', subName: 'Ezra', city: 'Basel', days: '1', status: false
    },
    {
        name: 'Hospital', subName: 'Thomas', city: 'Bienne', days: '6', status: false
    },
    {
        name: 'Medical', subName: 'Anthony', city: 'Lugano', days: '7', status: false
    },
    {
        name: 'Freelance', subName: 'Hudson', city: 'Bern', days: '5', status: false
    },
];

export default class EmployerFindJobDetailScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data_arr: DATA,
            isDescription: true,
            isRelated: false,
            modalVisible1: false,
            usertype: localStorage.getItemString('userType')
        }
    }

    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />


                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', backgroundColor: Colors.whiteColor,
                            height: mobileH * 10 / 100,
                        }}>
                            <TouchableOpacity style={{ width: '14%', }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={require('../../icons/back_icon.png')}
                                    style={{ alignSelf: 'center', width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '75%', justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Accountant Finance</Text>
                            </View>
                            <TouchableOpacity onPress={() => {
                            }} style={{ width: '10%', }}>
                                <View style={{
                                    backgroundColor: Colors.darkGreenColor,
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    width: mobileW * 9 / 100,
                                    height: mobileW * 8 / 100,
                                }}>
                                    <MaterialCommunityIcons name='heart-outline'
                                        size={30} color={Colors.whiteColor} />
                                </View>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}

                        <View style={styles.findJobDetailBody}>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                <View style={{ width: mobileW * 20 / 100 }}>

                                    <Image
                                        resizeMode={'cover'}
                                        style={{

                                            width: mobileW * 20 / 100,
                                            height: mobileW * 20 / 100,
                                        }} source={require('../../icons/placeholder.png')} />

                                    <View style={{
                                        marginTop: mobileW * 3 / 100,
                                        height: mobileW * 6 / 100,
                                    }}>
                                        <View style={{
                                            width: mobileW * 20 / 100,
                                            height: mobileW * 6 / 100,
                                            justifyContent: 'center',
                                            alignItems: 'center',
                                            backgroundColor: 'rgb(214,181,72)'
                                        }}>
                                            <Text numberOfLines={1}
                                                style={{
                                                    textTransform: 'uppercase',
                                                    color: Colors.whiteColor,
                                                    fontFamily: Font.montserrat_Medium,
                                                    fontSize: Font.fontSize3
                                                }}>
                                                part time
                                            </Text>
                                        </View>
                                    </View>
                                </View>

                                <View style={{ width: mobileW * 65 / 100 }}>
                                    <View style={{
                                        width: mobileW * 60 / 100,
                                        justifyContent: 'center',
                                    }}>
                                        <Text numberOfLines={2} style={{

                                            fontSize: mobileW * 3.5 / 100,
                                            color: Colors.textColor,
                                            fontFamily: Font.montserrat_Bold
                                        }}>
                                            Marketing Expert For Charity Organization
                                        </Text>

                                        <Text style={{
                                            marginTop: mobileW * 1 / 100,

                                            color: Colors.lightGreenColor,
                                            fontSize: Font.fontSize4
                                        }}>
                                            @Ebiquity Maxi
                                        </Text>

                                        <View style={{
                                            marginTop: mobileW * 5 / 100,
                                            width: mobileW * 55 / 100,
                                            height: mobileW * 8 / 100,

                                            flexDirection: 'row',
                                        }}>
                                            <Image
                                                style={{
                                                    width: 15,
                                                    height: 15,
                                                }}
                                                resizeMode={'contain'}
                                                source={require('../../icons/bag_icon.png')} />
                                            <Text numberOfLines={1} style={{
                                                paddingLeft: 10, fontSize: Font.fontSize3,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColorLight,
                                                marginRight: mobileW * 10 / 100,
                                            }}>Account / Finance</Text>
                                        </View>


                                        <View style={{
                                            width: mobileW * 55 / 100,

                                            height: mobileW * 8 / 100,
                                            flexDirection: 'row',
                                        }}>
                                            <Image
                                                style={{
                                                    width: 15,
                                                    height: 15,
                                                }}
                                                resizeMode={'contain'}
                                                source={require('../../icons/location_icon.png')} />
                                            <Text numberOfLines={1} style={{
                                                paddingLeft: 10, fontSize: Font.fontSize3,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColorLight,
                                                marginRight: mobileW * 10 / 100,
                                            }}>Regent St, Carnaby, London W!B 5AH,UK</Text>
                                        </View>

                                        <View style={{
                                            width: mobileW * 55 / 100,
                                            height: mobileW * 8 / 100,

                                            flexDirection: 'row',
                                        }}>
                                            <Image
                                                style={{
                                                    width: 15,
                                                    height: 15,
                                                }}
                                                resizeMode={'contain'}
                                                source={require('../../icons/clock_icon.png')} />
                                            <Text numberOfLines={1} style={{
                                                paddingLeft: 10, fontSize: Font.fontSize3,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColorLight,
                                                marginRight: mobileW * 10 / 100,
                                            }}>Post Date : September 11, 2021</Text>
                                        </View>

                                        <View style={{
                                            width: mobileW * 55 / 100,
                                            height: mobileW * 8 / 100,

                                            flexDirection: 'row',
                                        }}>
                                            <Image
                                                style={{
                                                    width: 15,
                                                    height: 15,
                                                }}
                                                resizeMode={'contain'}
                                                source={require('../../icons/clock_icon.png')} />
                                            <Text numberOfLines={1} style={{
                                                paddingLeft: 10, fontSize: Font.fontSize3,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColorLight,
                                                marginRight: mobileW * 10 / 100,
                                            }}>Apply Before : December 4 ,2019</Text>
                                        </View>
                                    </View>
                                    <View style={{
                                        width: mobileW * 55 / 100,
                                        height: mobileW * 8 / 100,

                                        flexDirection: 'row',
                                    }}>
                                        <Image
                                            style={{
                                                width: 15,
                                                height: 15,
                                            }}
                                            resizeMode={'contain'}
                                            source={require('../../icons/page_icon.png')} />
                                        <Text numberOfLines={1} style={{
                                            paddingLeft: 10, fontSize: Font.fontSize3,
                                            fontFamily: Font.montserrat_Regular,
                                            color: Colors.textColorLight,
                                            marginRight: mobileW * 10 / 100,
                                        }}>0 Applications(s)</Text>
                                    </View>

                                    <View style={{
                                        width: mobileW * 55 / 100,
                                        height: mobileW * 8 / 100,

                                        flexDirection: 'row',
                                    }}>
                                        <Image
                                            style={{
                                                width: 15,
                                                height: 15,
                                            }}
                                            resizeMode={'contain'}
                                            source={require('../../icons/eye_icon.png')} />
                                        <Text numberOfLines={1} style={{
                                            paddingLeft: 10, fontSize: Font.fontSize3,
                                            fontFamily: Font.montserrat_Regular,
                                            color: Colors.textColorLight,
                                            marginRight: mobileW * 10 / 100,
                                        }}>Views(s) 745</Text>
                                    </View>
                                </View>
                            </View>



                            <View style={{
                                justifyContent: 'center',



                            }}>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-evenly' }}>
                                    <TouchableOpacity style={{
                                        width: mobileW * 30 / 100,
                                        height: mobileW * 10 / 100,
                                        justifyContent: 'center',
                                        alignItems: 'center'
                                    }} activeOpacity={.7} onPress={() => {
                                        this.setState({ isDescription: true, isRelated: false });
                                    }}>
                                        <Text style={{ fontFamily: Font.montserrat_Medium, fontSize: mobileW * 3.5 / 100 }}>
                                            Description
                                        </Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity activeOpacity={.7} style={{
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                        width: mobileW * 30 / 100,
                                        height: mobileW * 10 / 100
                                    }} onPress={() => {
                                        this.setState({ isDescription: false, isRelated: true });
                                    }}>
                                        <Text style={{ fontFamily: Font.montserrat_Medium, fontSize: mobileW * 3.5 / 100 }}>
                                            Releted Jobs
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>

                        <View style={{ flexDirection: 'row' }}>
                            <View style={{
                                width: mobileW * 20 / 100,
                                borderBottomColor: Colors.greyColor,
                                borderBottomWidth: 1
                            }}></View>
                            <View style={{
                                width: mobileW * 21.5 / 100,
                                borderBottomColor: this.state.isDescription == true ? Colors.darkGreenColor : Colors.greyColor,
                                borderBottomWidth: this.state.isDescription == true ? 4 : 1,
                                borderRadius: this.state.isDescription == true ? 5 : 0
                            }}></View>
                            <View style={{
                                width: mobileW * 17.5 / 100,
                                borderBottomColor: Colors.greyColor,
                                borderBottomWidth: 1
                            }}></View>

                            <View style={{
                                width: mobileW * 23 / 100,
                                borderBottomColor: this.state.isRelated == true ? Colors.darkGreenColor : Colors.greyColor,
                                borderBottomWidth: this.state.isRelated == true ? 4 : 1,
                                borderRadius: this.state.isRelated == true ? 5 : 0
                            }}></View>

                            <View style={{
                                width: mobileW * 18 / 100,
                                borderBottomColor: Colors.greyColor,
                                borderBottomWidth: 1
                            }}></View>
                        </View>
                        {
                            this.state.isDescription == true &&
                            <View style={{ marginBottom: mobileW * 20 / 100, }}>
                                <View style={{
                                    height: mobileW * 25 / 100,
                                    justifyContent: 'center',

                                }}>
                                    <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
                                        <View>
                                            <View style={{ justifyContent: 'center', height: mobileW * 10 / 100, }}>
                                                <Image
                                                    resizeMode={'cover'}
                                                    style={{
                                                        alignSelf: 'center',
                                                        justifyContent: 'center',
                                                        width: mobileW * 6.5 / 100,
                                                        height: mobileW * 6.5 / 100,
                                                    }} source={require('../../icons/home_active_icon.png')} />
                                            </View>
                                            <View style={{
                                                width: mobileW * 20 / 100,
                                                height: mobileW * 10 / 100,
                                            }}>
                                                <Text style={{
                                                    textAlign: 'center',
                                                    fontSize: mobileW * 2.5 / 100,
                                                    fontFamily: Font.montserrat_Regular,
                                                    color: Colors.textColorLight,
                                                }}>
                                                    Offered Salary 1000
                                                </Text>
                                            </View>
                                        </View>




                                        <View>
                                            <View style={{ justifyContent: 'center', height: mobileW * 10 / 100 }}>
                                                <Image
                                                    resizeMode={'cover'}
                                                    style={{
                                                        alignSelf: 'center',
                                                        justifyContent: 'center',
                                                        width: mobileW * 6.5 / 100,
                                                        height: mobileW * 6.5 / 100,
                                                    }} source={require('../../icons/home_active_icon.png')} />
                                            </View>
                                            <View style={{
                                                width: mobileW * 20 / 100,
                                                height: mobileW * 10 / 100,
                                            }}>
                                                <Text style={{
                                                    textAlign: 'center',
                                                    fontSize: mobileW * 2.5 / 100,
                                                    fontFamily: Font.montserrat_Regular,
                                                    color: Colors.textColorLight,
                                                }}>
                                                    Career Level Manager
                                                </Text>
                                            </View>
                                        </View>

                                        <View>
                                            <View style={{ justifyContent: 'center', height: mobileW * 10 / 100, }}>
                                                <Image
                                                    resizeMode={'cover'}
                                                    style={{
                                                        alignSelf: 'center',
                                                        justifyContent: 'center',
                                                        width: mobileW * 6.5 / 100,
                                                        height: mobileW * 6.5 / 100,
                                                    }} source={require('../../icons/home_active_icon.png')} />
                                            </View>
                                            <View style={{
                                                width: mobileW * 20 / 100,
                                                height: mobileW * 10 / 100,
                                            }}>
                                                <Text style={{
                                                    textAlign: 'center',
                                                    fontSize: mobileW * 2.5 / 100,
                                                    fontFamily: Font.montserrat_Regular,
                                                    color: Colors.textColorLight,
                                                }}>
                                                    Experience Fresher
                                                </Text>
                                            </View>
                                        </View>

                                    </View>
                                </View>


                                <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
                                    <View>
                                        <View style={{ justifyContent: 'center', height: mobileW * 10 / 100, }}>
                                            <Image
                                                resizeMode={'cover'}
                                                style={{
                                                    alignSelf: 'center',
                                                    justifyContent: 'center',
                                                    width: mobileW * 6.5 / 100,
                                                    height: mobileW * 6.5 / 100,
                                                }} source={require('../../icons/home_active_icon.png')} />
                                        </View>
                                        <View style={{
                                            width: mobileW * 20 / 100,
                                            height: mobileW * 10 / 100,
                                        }}>
                                            <Text style={{
                                                textAlign: 'center',
                                                fontSize: mobileW * 2.5 / 100,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColorLight,
                                            }}>
                                                Offered Salary 1000
                                            </Text>
                                        </View>
                                    </View>




                                    <View>
                                        <View style={{ justifyContent: 'center', height: mobileW * 10 / 100, }}>
                                            <Image
                                                resizeMode={'cover'}
                                                style={{
                                                    alignSelf: 'center',
                                                    justifyContent: 'center',
                                                    width: mobileW * 6.5 / 100,
                                                    height: mobileW * 6.5 / 100,
                                                }} source={require('../../icons/home_active_icon.png')} />
                                        </View>
                                        <View style={{
                                            width: mobileW * 20 / 100,
                                            height: mobileW * 10 / 100,
                                        }}>
                                            <Text style={{
                                                textAlign: 'center',
                                                fontSize: mobileW * 2.5 / 100,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColorLight,
                                            }}>
                                                Career Level Manager
                                            </Text>
                                        </View>
                                    </View>

                                    <View>
                                        <View style={{ justifyContent: 'center', height: mobileW * 10 / 100, }}>
                                            <Image
                                                resizeMode={'cover'}
                                                style={{
                                                    alignSelf: 'center',
                                                    justifyContent: 'center',
                                                    width: mobileW * 6.5 / 100,
                                                    height: mobileW * 6.5 / 100,
                                                }} source={require('../../icons/home_active_icon.png')} />
                                        </View>
                                        <View style={{
                                            width: mobileW * 20 / 100,
                                            height: mobileW * 10 / 100,
                                        }}>
                                            <Text style={{
                                                textAlign: 'center',
                                                fontSize: mobileW * 2.5 / 100,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColorLight,
                                            }}>
                                                Experience Fresher
                                            </Text>
                                        </View>
                                    </View>


                                </View>


                                <View style={{ width: mobileW * 90 / 100, alignSelf: 'center' }}>
                                    <Text numberOfLines={1} style={{
                                        marginTop: mobileW * 2 / 100,
                                        fontFamily: Font.montserrat_Bold,
                                        color: Colors.textColor,
                                        fontSize: Font.fontSize4
                                    }}>
                                        Job Discription
                                    </Text>

                                    <Text numberOfLines={15} style={{
                                        marginTop: mobileW * 3 / 100,
                                        fontFamily: Font.montserrat_Medium,
                                        color: Colors.textColor,
                                        fontSize: Font.fontSize3half,
                                        textAlign: 'justify',
                                        lineHeight: 17
                                    }}>
                                        Job descriptions are more than just a document, they are an integral element of an effective HR structure. They summarise what a role's purpose is, what it is accountable for achieving and how those achievements are to be measured. The tasks and duties of the job description are how a role achieves its purpose
                                    </Text>
                                </View>

                                <View style={{ width: mobileW * 90 / 100, alignSelf: 'center' }}>
                                    <Text numberOfLines={1} style={{
                                        marginTop: mobileW * 2 / 100,
                                        fontFamily: Font.montserrat_Bold,
                                        color: Colors.textColor,
                                        fontSize: Font.fontSize4
                                    }}>
                                        What You Will Do
                                    </Text>

                                    <Text numberOfLines={15} style={{
                                        marginTop: mobileW * 3 / 100,
                                        fontFamily: Font.montserrat_Medium,
                                        color: Colors.textColor,
                                        fontSize: Font.fontSize3half,
                                        textAlign: 'justify',
                                        lineHeight: 18
                                    }}>
                                        Job descriptions are more than just a document, they are an integral element of an effective HR structure. They summarise what a role's purpose is, what it is accountable for achieving and how those achievements are to be measured. The tasks and duties of the job description are how a role achieves its purpose

                                    </Text>
                                </View>

                                <View style={{ width: mobileW * 90 / 100, alignSelf: 'center' }}>
                                    <Text numberOfLines={1} style={{
                                        marginTop: mobileW * 2 / 100,
                                        fontFamily: Font.montserrat_Bold,
                                        color: Colors.textColor,
                                        fontSize: Font.fontSize4
                                    }}>
                                        What we can offer you
                                    </Text>

                                    <Text numberOfLines={15} style={{
                                        marginTop: mobileW * 2 / 100,
                                        fontFamily: Font.montserrat_Medium,
                                        color: Colors.textColor,
                                        fontSize: Font.fontSize3half,
                                        textAlign: 'justify',
                                        lineHeight: 18
                                    }}>
                                        Job descriptions are more than just a document, they are an integral element of an effective HR structure. They summarise what a role's purpose is, what it is accountable for achieving and how those achievements are to be measured. The tasks and duties of the job description are how a role achieves its purpose
                                    </Text>

                                    <View style={{

                                        width: mobileW * 90 / 100, alignSelf: 'center', justifyContent: 'center'

                                    }}>
                                        <Image style={{ resizeMode: 'contain', width: '100%', height: mobileH * 30 / 100 }} source={require('../../icons/google_map.jpg')}
                                        />
                                    </View>

                                    <View>
                                        <Text numberOfLines={1} style={{
                                            fontFamily: Font.montserrat_Bold,
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4
                                        }}>
                                            Required Skills
                                        </Text>
                                    </View>

                                    <View style={{
                                        height: mobileW * 12 / 100, marginBottom: 10,
                                        justifyContent: 'center'
                                    }}>
                                        <View style={{
                                            flexDirection: 'row',
                                            justifyContent: 'space-between'
                                        }}>
                                            <View style={styles.butonView}>
                                                <Text style={{

                                                    fontSize: Font.fontSize4,
                                                    color: Colors.whiteColor,
                                                    fontFamily: Font.montserrat_Regular,
                                                    textAlign: 'center'

                                                }}>
                                                    App
                                                </Text>
                                            </View>
                                            <View style={styles.butonView}>
                                                <Text style={{

                                                    fontSize: Font.fontSize4,
                                                    color: Colors.whiteColor,
                                                    fontFamily: Font.montserrat_Regular,
                                                    textAlign: 'center'

                                                }}>
                                                    Jobs
                                                </Text>
                                            </View>
                                            <View style={styles.butonView}>
                                                <Text style={{
                                                    textAlign: 'center',
                                                    fontSize: Font.fontSize4,
                                                    fontFamily: Font.montserrat_Regular,
                                                    color: Colors.whiteColor,
                                                    textAlign: 'center'

                                                }}>
                                                    Superio
                                                </Text>
                                            </View>
                                            <View style={styles.butonView}>
                                                <Text style={{

                                                    fontSize: Font.fontSize4,
                                                    fontFamily: Font.montserrat_Regular,
                                                    color: Colors.whiteColor,
                                                    textAlign: 'center'
                                                }}>
                                                    Support
                                                </Text>
                                            </View>
                                        </View>
                                    </View>

                                    <TouchableOpacity activeOpacity={.7} onPress={() => { this.setState({ modalVisible1: true }) }}>
                                        <View style={{
                                            height: mobileW * 13 / 100, backgroundColor: '#53b427',
                                            justifyContent: 'center', marginBottom: mobileW * 2 / 100, borderRadius: 6,
                                            alignItems: 'center',
                                        }}>
                                            <Text style={{
                                                fontSize: Font.fontSize4,
                                                color: Colors.whiteColor
                                            }}>
                                                APPLY FOR THE JOB
                                            </Text>

                                        </View>
                                    </TouchableOpacity>
                                    <Text style={{
                                        fontSize: mobileW * 3.5 / 100,
                                        color: '#53b427',
                                        fontFamily: Font.montserrat_Bold,
                                        alignSelf: 'center',
                                        marginTop: mobileW * 1.5 / 100
                                    }}>
                                        Application end in 10d 16h 25min
                                    </Text>
                                    <TouchableOpacity onPress={() => { this.props.navigation.navigate('Profesional_Resume') }}  >
                                        <View style={{
                                            height: mobileW * 13 / 100, backgroundColor: '#ffb14a',
                                            justifyContent: 'center', marginBottom: mobileW * 10 / 100, borderRadius: 6,
                                            alignItems: 'center',
                                            marginTop: mobileW * 8 / 100
                                        }}>
                                            <Text style={{
                                                fontSize: Font.fontSize4,
                                                color: Colors.whiteColor
                                            }}>
                                                CONTACT EMPLOYER
                                            </Text>

                                        </View>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        }
                        {
                            this.state.isRelated == true &&
                            <FlatList
                                data={this.state.data_arr}
                                style={{ marginBottom: mobileW * 20 / 100 }}
                                renderItem={({ item, index }) =>
                                    <TouchableOpacity activeOpacity={.7} onPress={() => {
                                        this.props.navigation.navigate('EmployerComponayDetail');
                                    }}>
                                        <View style={{
                                            height: mobileW * 45 / 100,
                                            width: mobileW * 90 / 100,
                                            marginBottom: 1,
                                            marginTop: mobileW * 4 / 100,
                                            alignSelf: 'center',
                                            backgroundColor: Colors.whiteColor,
                                            shadowColor: '#000',
                                            shadowOffset: {
                                                width: 2,
                                                height: 2,
                                            },
                                            shadowOpacity: 0.5,
                                            shadowRadius: 0.5,
                                            elevation: 2,
                                        }}>
                                            <View style={{ flexDirection: 'row' }}>

                                                <View style={{
                                                    width: mobileW * 30 / 100,
                                                    height: mobileW * 45 / 100,
                                                }}>
                                                    <View style={{
                                                        marginTop: mobileW * 3 / 100,
                                                        height: mobileW * 22 / 100,
                                                        justifyContent: 'center',
                                                        alignItems: 'center',
                                                    }}>
                                                        <Image
                                                            resizeMode={'cover'}
                                                            style={{
                                                                width: mobileW * 22 / 100,
                                                                height: mobileW * 18 / 100,
                                                            }} source={require('../../icons/placeholder.png')} />

                                                    </View>
                                                    <View style={{
                                                        width: mobileW * 30 / 100,
                                                        justifyContent: 'center',
                                                        alignItems: 'center',
                                                        height: mobileW * 6 / 100,
                                                    }}>

                                                        <View style={{
                                                            width: mobileW * 22 / 100,
                                                            height: mobileW * 6 / 100,
                                                            justifyContent: 'center',
                                                            alignItems: 'center',
                                                            backgroundColor: 'rgb(214,181,72)'
                                                        }}>
                                                            <Text numberOfLines={1}
                                                                style={{
                                                                    textTransform: 'uppercase',
                                                                    color: Colors.whiteColor,
                                                                    fontFamily: Font.montserrat_Medium,
                                                                    fontSize: Font.fontSize3
                                                                }}>
                                                                part time
                                                            </Text>
                                                        </View>
                                                    </View>
                                                </View>
                                                <View style={{
                                                    width: mobileW * 60 / 100,
                                                    height: mobileW * 45 / 100,
                                                }}>
                                                    <View style={{ flexDirection: 'row' }}>
                                                        <View style={{
                                                            width: mobileW * 48 / 100,
                                                            height: mobileW * 26 / 100,
                                                            justifyContent: 'center',
                                                        }}>
                                                            <View style={{
                                                                width: mobileW * 48 / 100,
                                                                height: mobileW * 20 / 100,
                                                                justifyContent: 'center',
                                                            }}>
                                                                <Text numberOfLines={2} style={{
                                                                    fontSize: Font.fontSize4,
                                                                    color: Colors.textColor,
                                                                    fontFamily: Font.montserrat_Bold
                                                                }}>
                                                                    Marketing Expert For {item.name}
                                                                </Text>
                                                                <Text style={{
                                                                    color: Colors.lightGreenColor,
                                                                    fontSize: Font.fontSize4
                                                                }}>
                                                                    @{item.subName}
                                                                </Text>
                                                            </View>
                                                        </View>

                                                        <View style={{
                                                            width: mobileW * 8 / 100,
                                                            height: mobileW * 17 / 100,
                                                            justifyContent: 'center',
                                                            alignItems: 'center',
                                                        }}>
                                                            <TouchableOpacity activeOpacity={.7} onPress={() => { }}>
                                                                <View style={{

                                                                    backgroundColor: item.status ? Colors.darkGreenColor : Colors.extraLightGreenColor,
                                                                    width: mobileW * 8 / 100,
                                                                    height: mobileW * 8 / 100,
                                                                    justifyContent: 'center',
                                                                    alignItems: 'center',
                                                                }}>
                                                                    <MaterialCommunityIcons name='heart-outline'
                                                                        size={30} color={item.status ? Colors.whiteColor : Colors.darkGreenColor} />
                                                                </View>
                                                            </TouchableOpacity>
                                                        </View>
                                                    </View>
                                                    <View style={{
                                                        width: mobileW * 55 / 100,
                                                        height: mobileW * 6 / 100,

                                                        flexDirection: 'row'
                                                    }}>
                                                        <Image
                                                            style={{
                                                                width: 25,
                                                                height: 20,
                                                            }}
                                                            resizeMode={'contain'}
                                                            source={require('../../icons/bag_icon.png')} />
                                                        <Text numberOfLines={1} style={{
                                                            paddingLeft: 10, fontSize: Font.fontSize3,
                                                            fontFamily: Font.montserrat_Regular,
                                                            color: Colors.textColorLight,
                                                            marginRight: mobileW * 10 / 100,
                                                        }}>{item.name}</Text>
                                                    </View>

                                                    <View style={{
                                                        width: mobileW * 55 / 100,
                                                        height: mobileW * 6 / 100,
                                                        flexDirection: 'row',
                                                    }}>
                                                        <Image
                                                            style={{
                                                                width: 25,
                                                                height: 20,
                                                            }}
                                                            resizeMode={'contain'}
                                                            source={require('../../icons/location_icon.png')} />
                                                        <Text numberOfLines={1} style={{
                                                            marginRight: mobileW * 10 / 100,
                                                            paddingLeft: 10, fontSize: Font.fontSize3,
                                                            fontFamily: Font.montserrat_Regular,
                                                            color: Colors.textColorLight
                                                        }}>Regent St, Carnaby,{item.city}</Text>
                                                    </View>

                                                    <View style={{
                                                        width: mobileW * 55 / 100,
                                                        height: mobileW * 6 / 100,

                                                        flexDirection: 'row'
                                                    }}>
                                                        <Image
                                                            style={{
                                                                width: 25,
                                                                height: 20,
                                                            }}
                                                            resizeMode={'contain'}
                                                            source={require('../../icons/clock_icon.png')} />
                                                        <Text numberOfLines={1} style={{
                                                            marginRight: mobileW * 10 / 100,
                                                            paddingLeft: 10, fontSize: Font.fontSize3,
                                                            fontFamily: Font.montserrat_Regular,
                                                            color: Colors.textColorLight
                                                        }}>Published {item.days} days ago</Text>
                                                    </View>
                                                </View>
                                            </View>
                                        </View>
                                    </TouchableOpacity>
                                }
                            >
                            </FlatList>
                        }
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={this.state.modalVisible1}
                    onRequestClose={() => {
                        this.setState({ modalVisible1: false });
                    }}>
                    <SafeAreaView style={{ flex: 1 }}>
                        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', alignSelf: 'center', width: mobileW * 100 / 100, alignContent: 'center', backgroundColor: 'rgba(0,0,0,0.6)', height: mobileH * 100 / 100 }}>
                            <View style={{ height: mobileH * 15 / 100, width: mobileW * 90 / 100, backgroundColor: '#fff', alignSelf: 'center', borderRadius: mobileW * 2 / 100, padding: mobileW * 4 / 100, borderWidth: 1, borderColor: Colors.border_color }}>
                                <TouchableOpacity activeOpacity={.7} onPress={() => { this.setState({ modalVisible1: false }) }}>
                                    <Image
                                        style={{
                                            width: 25,
                                            height: 20,
                                            alignSelf: 'flex-end'
                                        }}
                                        resizeMode={'contain'}
                                        source={require('../../icons/clock_icon.png')} />
                                </TouchableOpacity>
                                <Text style={{ fontSize: mobileW * 3.5 / 100, fontFamily: Font.montserrat_Medium, color: Colors.greyColor, marginTop: mobileW * 2 / 100, alignSelf: 'center' }}>Required Candidates login to applying this job click here to logout And try again</Text>
                            </View>
                        </View>
                    </SafeAreaView>
                </Modal>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    findJobDetailBody: {
        width: mobileW * 90 / 100,
        alignSelf: 'center',
    },
    butonView:
    {
        width: mobileW * 22 / 100,
        backgroundColor: Colors.textColor,
        alignItems: 'center',
        justifyContent: 'center',
        height: mobileH * 3.5 / 100
    }
});

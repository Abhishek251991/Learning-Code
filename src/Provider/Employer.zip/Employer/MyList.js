import React, { Component } from 'react'
import { Image, SafeAreaView, TouchableOpacity, StyleSheet, View, FlatList, ScrollView, StatusBar, Text, ImageBackground, Modal } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
import Footer from '../../Provider/Footer';
import { mobileW, commonStyle, mobileH, localStorage, Colors, Font } from '../../Provider/utilslib/Utils';
import EmployerFooter from './EmployerFooter';

const DATA = [
    {
        name: 'total', description: 'applicants', colorValue: Colors.statusbarcolor, navigate: 'CandidateDashboard', status: true,
        count: 3
    },
    {
        name: 'shortlisted', description: 'applicants', colorValue: 'rgb(91,126,197)', status: false, count: 19
    },
    {
        name: 'rejected', description: 'applicants', colorValue: 'rgb(236,97,81)', status: false, count: 16
    },
    {
        name: 'unviewd', description: 'applicants', colorValue: 'rgb(214,181,72)', status: false, count: 0
    },
];

const MYLIST = [
    {
        name: 'Accounting  ', subName: 'Carter', city: 'Zürich', days: '4', status: false, age: 62, phone: '0958547545'
    },
    {
        name: 'Accounting', subName: 'Christopher', city: 'Zürich', days: '14', status: true, age: 54, phone: '09585475456'
    },
    {
        name: 'Agriculture', subName: 'Julian', city: 'Lucerne', days: '9', status: false, age: 45, phone: '0958547544'
    },
    {
        name: 'Accounting finance', subName: 'Jayden', city: 'Gallen', days: '2', status: true, age: 55, phone: '0958547543'
    },
    {
        name: 'Art', subName: 'Grayson', city: 'Winterthur', days: '7', status: false, age: 22, phone: '0958547542'
    },
    {
        name: 'Education', subName: 'Lincoln', city: 'Lausanne', days: '2', status: true, age: 21, phone: '0958547545'
    },
];

export default class EmployerMyListScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data_arr: DATA,
            my_list_arr: MYLIST,
            checkbox: true,
            isVisible: false,
            usertype: localStorage.getItemString('userType')
        }
    }

    checkboxTermsAndCondition = () => {
        if (this.state.checkbox) {
            this.setState({ checkbox: false })
        } else {
            this.setState({ checkbox: true })
        }
    }

    callFuntion = (index) => {
        let data = this.state.my_list_arr;
        for (let i = 0; i < data.length; i++)
            data[i].status = false;
        data[index].status = true;
        this.setState({ my_list_arr: data });
    }

    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        <Modal
                            animationType={'slide'}
                            transparent={true}
                            backgroundColor={'red'}
                            visible={this.state.isVisible}
                            onRequestClose={() => { console.log("Modal has been closed.") }}>
                            <View style={{
                                marginTop: 'auto',
                                height: '45%',
                                width: mobileW * 100 / 100,
                                backgroundColor: Colors.whiteColor,
                                shadowColor: '#000',
                                shadowOffset: {
                                    width: 0,
                                    height: 2,
                                },
                                shadowOpacity: 5,
                                shadowRadius: 5,
                                elevation: 22,
                            }}>
                                <TouchableOpacity activeOpacity={.7} onPress={() => {
                                    this.setState({ isVisible: false })
                                }}>
                                    <View style={{ height: mobileW * 5 / 100 }} />
                                    <View style={{
                                        width: mobileW * 15 / 100,
                                        borderBottomColor: Colors.darkGreenColor,
                                        borderRadius: 6,
                                        alignSelf: 'center',
                                        borderBottomWidth: 6
                                    }}>
                                    </View>
                                </TouchableOpacity>

                                <View style={{
                                    marginTop: mobileW * 4 / 100,
                                    width: mobileW * 90 / 100,
                                    height: mobileW * 10 / 100,
                                    justifyContent: 'center',
                                    alignSelf: 'center',
                                }}>
                                    <View>
                                        <Text style={{
                                            fontSize: Font.fontSize4,
                                            color: Colors.textColor,
                                            fontFamily: Font.montserrat_Bold,
                                        }}>
                                            Filter by Job
                                        </Text>
                                    </View>
                                </View>


                                <View style={{ width: '100%', marginBottom: mobileW * 3 / 100, }}>
                                    <View style={{
                                        color: Colors.textColor,
                                        alignSelf: 'center',
                                        borderColor: Colors.greyColor,
                                        borderWidth: 0.7,
                                        width: mobileW * 90 / 100,
                                        paddingVertical: mobileW * 3 / 100,
                                        paddingHorizontal: 18,
                                        fontSize: Font.fontSize4,
                                        fontFamily: Font.montserrat_Regular,
                                        flexDirection: 'row',
                                        justifyContent: 'space-between'
                                    }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            paddingVertical: mobileW * 1.5 / 100,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            Select
                                        </Text>
                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                            <MaterialCommunityIcons name='menu-down' size={35}
                                                color={Colors.textColor} style={{}} />
                                        </View>
                                    </View>
                                </View>

                                <View style={{ width: '100%', marginBottom: mobileW * 3 / 100, }}>
                                    <View style={{
                                        width: '90%', alignSelf: 'center',
                                        flexDirection: 'row', justifyContent: 'space-between'
                                    }}>
                                        <View style={{
                                            color: Colors.textColor,
                                            alignSelf: 'center',
                                            borderColor: Colors.greyColor,
                                            borderWidth: 0.7,
                                            width: mobileW * 43.5 / 100,
                                            paddingVertical: mobileW * 3 / 100,
                                            paddingHorizontal: 18,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular,
                                            flexDirection: 'row',
                                            justifyContent: 'space-between'
                                        }}>
                                            <Text style={{
                                                color: Colors.textColor,
                                                paddingVertical: mobileW * 1 / 100,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular
                                            }}>
                                                Select
                                            </Text>
                                            <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                <Image source={require('../../icons/calender_blue_icon.png')}
                                                    style={{ width: mobileW * 6 / 100, height: mobileW * 6 / 100 }} />
                                            </View>
                                        </View>
                                        <View style={{
                                            color: Colors.textColor,
                                            alignSelf: 'center',
                                            borderColor: Colors.greyColor,
                                            borderWidth: 0.7,
                                            width: mobileW * 43.5 / 100,
                                            paddingVertical: mobileW * 3 / 100,
                                            paddingHorizontal: 18,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular,
                                            flexDirection: 'row',
                                            justifyContent: 'space-between'
                                        }}>
                                            <Text style={{
                                                color: Colors.textColor,
                                                paddingVertical: mobileW * 1 / 100,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular
                                            }}>
                                                Select
                                            </Text>
                                            <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                <Image source={require('../../icons/calender_blue_icon.png')}
                                                    style={{ width: mobileW * 6 / 100, height: mobileW * 6 / 100 }} />
                                            </View>
                                        </View>
                                    </View>
                                </View>
                                <View style={{ width: '100%', marginTop: mobileW * 4 / 100, marginBottom: mobileW * 3 / 100, }}>
                                    <View style={{
                                        width: '90%', alignSelf: 'center',
                                        flexDirection: 'row', justifyContent: 'space-between'
                                    }}>
                                        <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                            <View style={{
                                                width: mobileW * 43.5 / 100,
                                                paddingVertical: mobileW * 4 / 100,
                                                alignItems: 'center',
                                                backgroundColor: Colors.darkGreenColor
                                            }}>
                                                <Text style={{
                                                    fontFamily: Font.montserrat_Medium,
                                                    textTransform: 'uppercase',
                                                    color: Colors.whiteColor
                                                }}>submit</Text>
                                            </View>
                                        </TouchableOpacity>
                                        <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                            <View style={{
                                                width: mobileW * 43.5 / 100,
                                                paddingVertical: mobileW * 4 / 100,
                                                alignItems: 'center',
                                                backgroundColor: Colors.darkGreenColor,
                                            }}>
                                                <Text style={{
                                                    textTransform: 'uppercase',
                                                    color: Colors.whiteColor,
                                                    fontFamily: Font.montserrat_Medium
                                                }}>export to excel</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            </View>
                            {/* </TouchableOpacity> */}

                        </Modal>

                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', backgroundColor: Colors.silverLightColor, height: mobileH * 8 / 100,
                        }}>
                            <TouchableOpacity style={{ width: '15%', }} onPress={() => { }}>
                                <Image source={require('../../icons/drower_menu_icon.png')}
                                    style={{ alignSelf: 'center', width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '70%', justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>All Applicants</Text>
                            </View>
                            <TouchableOpacity onPress={() => { this.setState({ isVisible: !this.state.isVisible }) }} style={{ width: '15%' }}>
                                <Image source={require('../../icons/option_icon.png')}
                                    style={{ alignSelf: 'center', width: mobileW * 10 / 100, height: mobileW * 10 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <View style={{
                            width: '100%',

                            backgroundColor: Colors.silverLightColor,
                            height: mobileH * 35 / 100
                        }}>

                            <View style={{
                                width: mobileW * 90 / 100,
                                alignSelf: 'center',
                            }}>
                                <FlatList
                                    contentContainerStyle={{ marginBottom: mobileW * 20 / 100 }}
                                    data={this.state.data_arr}
                                    numColumns={2}
                                    renderItem={({ item, index }) => {
                                        return (
                                            <View style={{
                                                width: mobileW * 45 / 100
                                            }}>
                                                <View style={{
                                                    width: mobileW * 42.5 / 100,
                                                    alignSelf: 'center',
                                                    backgroundColor: item.colorValue,
                                                    paddingVertical: mobileW * 4.5 / 100,
                                                    marginTop: mobileW * 3.5 / 100
                                                }}>
                                                    <View style={{ marginLeft: mobileW * 3.5 / 100 }}>
                                                        <Text numberOfLines={1} style={{
                                                            color: Colors.whiteColor,
                                                            fontFamily: Font.montserrat_Bold, fontSize: Font.fontSize5
                                                        }}>
                                                            {item.count}
                                                        </Text>
                                                        <Text numberOfLines={1} style={{
                                                            marginTop: mobileW * 2.5 / 100,
                                                            color: Colors.whiteColor,
                                                            fontFamily: Font.montserrat_Bold,
                                                            textTransform: 'uppercase',
                                                            fontSize: Font.fontSize3
                                                        }}>
                                                            {item.name}
                                                        </Text>
                                                        <Text numberOfLines={1} style={{
                                                            color: Colors.whiteColor,
                                                            fontFamily: Font.montserrat_Medium,
                                                            fontSize: Font.fontSize3,
                                                            textTransform: 'uppercase'
                                                        }}>
                                                            {item.description}
                                                        </Text>

                                                    </View>
                                                </View>
                                            </View>
                                        );
                                    }}
                                    keyExtractor={(item, index) => index.toString()}
                                />
                            </View>
                        </View>

                        <View style={{ width: mobileW * 90 / 100, alignSelf: 'center' }}>

                            <View style={{
                                alignSelf: 'center', marginTop: mobileW * 5 / 100,
                                width: mobileW * 82 / 100, flexDirection: 'row', justifyContent: 'space-between'
                            }}>
                                <Text style={{
                                    paddingVertical: mobileW * 1 / 100,
                                    fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>
                                    Financed Manager
                                </Text>
                                <View style={{ flexDirection: 'row', }}>
                                    <Text style={{
                                        color: Colors.textColor,
                                        paddingVertical: mobileW * 2.5 / 100
                                    }}>
                                        Select All
                                    </Text>
                                    <TouchableOpacity
                                        onPress={() => this.checkboxTermsAndCondition()}
                                        style={{
                                            flexDirection: 'row', width: mobileW * 10 / 100,
                                            justifyContent: 'space-between',
                                        }}>
                                        {this.state.checkbox ? <MaterialCommunityIcons name='check-box-outline' size={40}
                                            color={Colors.darkGreenColor} />
                                            : <MaterialCommunityIcons name='checkbox-blank-outline' size={40}
                                                color={Colors.darkGreenColor} />}
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                        <FlatList
                            contentContainerStyle={{ paddingBottom: mobileW * 18 / 100 }}
                            style={{
                                marginLeft: 12,
                                marginRight: mobileW * 5 / 100,
                            }}
                            data={this.state.my_list_arr}
                            showsHorizontalScrollIndicator={false}
                            renderItem={({ item, index }) => {
                                return (
                                    <View style={{
                                        marginTop: 10,
                                        width: mobileW * 90 / 100,
                                        alignSelf: 'center',
                                    }}>
                                        <View style={{
                                            width: mobileW * 90 / 100,
                                            alignSelf: 'center',
                                            backgroundColor: Colors.whiteColor,
                                            shadowColor: '#000',

                                            shadowOffset: {
                                                width: 0,
                                                height: 1,
                                            },
                                            shadowOpacity: 0.5,
                                            shadowRadius: 0.5,
                                            elevation: 3,
                                            padding: mobileW * 3 / 100
                                        }}>
                                            <View style={{
                                                flexDirection: 'row',
                                            }}>
                                                <View style={{ width: '30%' }}>
                                                    <Image
                                                        style={{ width: mobileW * 20 / 100, height: mobileW * 20 / 100 }}
                                                        source={require('../../icons/placeholder.png')} />
                                                </View>

                                                <View style={{ width: '60%' }}>
                                                    <Text style={{
                                                        fontSize: Font.fontSize4, color: Colors.textColor,
                                                        fontFamily: Font.montserrat_Bold,
                                                    }}>{item.subName}</Text>
                                                    <Text style={{
                                                        fontSize: Font.fontSize3half, color: Colors.darkGreenColor,
                                                        fontFamily: Font.montserrat_Regular,
                                                    }}>Property Agent</Text>
                                                    <Text style={{
                                                        fontSize: Font.fontSize2half, color: Colors.textColor,
                                                        fontFamily: Font.montserrat_Regular,
                                                    }}>Age : {item.age} years</Text>
                                                    <Text style={{
                                                        fontSize: Font.fontSize2half, color: Colors.textColor,
                                                        fontFamily: Font.montserrat_Regular,
                                                    }}>Phone : {item.phone}</Text>

                                                    <View style={{
                                                        flexDirection: 'row', paddingVertical: mobileW * 1.5 / 100,
                                                    }}>
                                                        <Image
                                                            style={{
                                                                width: mobileW * 6 / 100,
                                                                height: mobileW * 6 / 100
                                                            }}
                                                            resizeMode={'contain'}
                                                            source={require('../../icons/bag_icon.png')} />
                                                        <Text numberOfLines={1} style={{ paddingVertical: mobileW * 1 / 100, marginLeft: mobileW * 2 / 100, color: Colors.textColorLight, fontSize: Font.fontSize3 }}>
                                                            {item.name}
                                                        </Text>
                                                    </View>

                                                    <View style={{
                                                        flexDirection: 'row', paddingVertical: mobileW * 1.5 / 100,
                                                    }}>
                                                        <Image
                                                            style={{
                                                                width: mobileW * 6 / 100,
                                                                height: mobileW * 6 / 100
                                                            }}
                                                            resizeMode={'contain'}
                                                            source={require('../../icons/clock_icon.png')} />
                                                        <Text numberOfLines={1} style={{ marginLeft: mobileW * 2 / 100, color: Colors.textColorLight, fontSize: Font.fontSize3 }}>
                                                            Applied At : September {item.days},2021
                                                        </Text>
                                                    </View>

                                                    <View style={{
                                                        flexDirection: 'row', paddingVertical: mobileW * 1.5 / 100,
                                                    }}>
                                                        <Image
                                                            style={{
                                                                width: mobileW * 6 / 100,
                                                                height: mobileW * 6 / 100
                                                            }}
                                                            resizeMode={'contain'}
                                                            source={require('../../icons/currency_icon.png')} />
                                                        <Text numberOfLines={1} style={{ marginLeft: mobileW * 2 / 100, color: Colors.textColorLight, fontSize: Font.fontSize3 }}>
                                                            $ {item.age}.00 / Hourly
                                                        </Text>
                                                    </View>

                                                    <View style={{
                                                        flexDirection: 'row', paddingVertical: mobileW * 1.5 / 100,
                                                    }}>
                                                        <Image
                                                            style={{
                                                                width: mobileW * 7 / 100,
                                                                height: mobileW * 7 / 100
                                                            }}
                                                            resizeMode={'contain'}
                                                            source={require('../../icons/eye_open_icon.png')} />

                                                        <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                                            <View style={{
                                                                marginLeft: mobileW * 2.2 / 100,
                                                                borderColor: Colors.greyColor, borderWidth: 1,
                                                                alignItems: 'center',
                                                                paddingLeft: mobileW * 1.5 / 100,
                                                                flexDirection: 'row', justifyContent: 'space-between',
                                                                width: mobileW * 20 / 100
                                                            }}>
                                                                <Text style={{ fontSize: mobileW * 3.5 / 100, justifyContent: 'center' }}>Action</Text>
                                                                <MaterialCommunityIcons name='menu-down' size={25}
                                                                    color={Colors.textColor} style={{}} />
                                                            </View>
                                                        </TouchableOpacity>
                                                    </View>
                                                </View>

                                                <View style={{ width: '10%' }}>
                                                    <TouchableOpacity
                                                        onPress={() => { this.callFuntion(index) }}
                                                        style={{
                                                            flexDirection: 'row', width: mobileW * 10 / 100,
                                                            justifyContent: 'space-between',
                                                        }}>
                                                        {item.status ? <MaterialCommunityIcons name='check-box-outline' size={40}
                                                            color={Colors.darkGreenColor} />
                                                            : <MaterialCommunityIcons name='checkbox-blank-outline' size={40}
                                                                color={Colors.darkGreenColor} />}
                                                    </TouchableOpacity>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                );
                            }}
                            keyExtractor={(item, index) => index.toString()}
                        />
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='EmployerMyList' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    image: {
        flex: 1,
    },
    employerScreenBody: {
        width: mobileW * 90 / 100,
        height: 500,
        backgroundColor: 'yellow'
    },
});

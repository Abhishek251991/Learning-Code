import React, { Component } from 'react';
import { FlatList } from 'react-native';
import { Keyboard, Image, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View, } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mobileH, msgProvider, msgText, config, localStorage, Colors, Font, localImage } from '../../Provider/utilslib/Utils';

const AppButton = ({ onPress, title, color, backgroundColor }) => (
    <TouchableOpacity
        style={[styles.button, { backgroundColor: backgroundColor }]}
        activeOpacity={.7}
        onPress={onPress}
    >
        <Text style={{
            fontSize: Font.fontSize4,
            color: color,
            textTransform: 'uppercase',
            fontFamily: Font.montserrat_Bold
        }}>{title}</Text>
    </TouchableOpacity>
);
export default class ChangePasswordScreen extends Component {
    constructor(props) {
        localStorage.setItemString('userType', '1');
        super(props);
        this.state = {
            oldPassword: '',
            newPassword: '',
            confirmNewPassword: '',
            secureOldPasswordText: true,
            secureConfirmNewPasswordText: true,
            secureNewPasswordText: true,
        }
    }

    eyeOldPasswordPress() {
        if (this.state.secureOldPasswordText) {
            this.setState({ secureOldPasswordText: false });
        } else {
            this.setState({ secureOldPasswordText: true });
        }
    }
    eyeConfirmNewPasswordPress() {
        if (this.state.secureConfirmNewPasswordText) {
            this.setState({ secureConfirmNewPasswordText: false });
        } else {
            this.setState({ secureConfirmNewPasswordText: true });
        }
    }
    eyeNewPasswordPress() {
        if (this.state.secureNewPasswordText) {
            this.setState({ secureNewPasswordText: false });
        } else {
            this.setState({ secureNewPasswordText: true });
        }
    }
    changePasswordCallApi() {
        Keyboard.dismiss()
        // --------------- Get Values into variables -----------------------
        let oldPassword = this.state.oldPassword.trim();
        let newPassword = this.state.newPassword.trim();
        let confirmNewPassword = this.state.confirmNewPassword.trim();
        // -------------------Empty Validation Check------------------------  
        if (oldPassword.length <= 0) {
            msgProvider.toast(msgText.emptyOldPassword[config.language], 'center')
            return false;
        }
        if (oldPassword.length < 6) {
            msgProvider.toast(msgText.oldPasswordMinLength[config.language], 'center')
            return false;
        }
        if (newPassword.length <= 0) {
            msgProvider.toast(msgText.emptyNewPassword[config.language], 'center')
            return false;
        }
        if (newPassword.length < 6) {
            msgProvider.toast(msgText.newPasswordMinLength[config.language], 'center')
            return false;
        }
        if (confirmNewPassword.length <= 0) {
            msgProvider.toast(msgText.emptyConfirmNewPassword[config.language], 'center')
            return false;
        }
        if (confirmNewPassword.length < 6) {
            msgProvider.toast(msgText.confirmNewPasswordMinLength[config.language], 'center')
            return false;
        }
        this.props.navigation.navigate('Employer');
        // ----------------- Make Url For Particular API ----------------
        // let url = config.apiUrl + "login.php";
        // console.log(url);
        // -------------- Create Navigation Object/Instance -------------
        // const { navigate } = this.props.navigation;

        //--------- Create Form Data Object And Set Values into it ------- 
        // var data = new FormData();
        // data.append('email', email)
        // data.append('password', password)
        // data.append('device_type', config.deviceType)
        // data.append("player_id", player_id_me1)
        // data.append("action_type", 'normal_login')
        // data.append('language', config.language)

        // ---------- Print Data Object To Verify Your Data----------------
        // console.log('data', data);

        //----------- Call GetAPI OR POST To Send Your Request ------------- 
        // apifuntion.postApi(url, data).then((obj) => {
        //     if (obj.success == 'true') {
        //         console.log(obj);
        //         var userDetails = obj.user_details;
        //         const userValue = { email: email, password: password };

        //         //------------------ Set User Details and Auto Login Details Into LocalStorage ---------------
        //         localStorage.setItemObject('user_login', userValue);
        //         localStorage.setItemObject('user_arr', userDetails);

        //         // --------------- Send Welcome notification to user -------------------
        //         if (obj.notification_arr != 'NA') {
        //             notification.notification_arr(obj.notification_arr);
        //         }

        //         //-----------Show Success Message Toast---------
        //         msgProvider.toast(obj.msg[0], 'center')
        //         this.setState({ email: '', password: '' });
        //         this.props.navigation.navigate('Home')
        //     } else {
        //         //-----------Show Failed Message Toast-----------
        //         msgProvider.toast(obj.msg[0], 'center')
        //         return false;
        //     }
        // }).catch((error) => {
        //     console.log(error);
        // });
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Change Password</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={{ width: '78%' }}>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}

                        <View style={{ marginTop: mobileW * 5 / 100 }}>
                            {/* old password text field  */}
                            <View style={{ width: '100%', marginBottom: mobileW * 3 / 100, }}>
                                <View style={{ width: mobileW * 82 / 100, alignSelf: 'center' }}>
                                    <Text style={{
                                        marginBottom: mobileW * 2 / 100,
                                        color: Colors.greyColor,
                                        fontSize: Font.fontSize3half,
                                        fontFamily: Font.montserrat_Regular
                                    }}>
                                        Old Password
                                    </Text>
                                </View>
                                <View style={{
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <TextInput
                                        keyboardType='default'
                                        placeholder={'Old Password'}
                                        placeholderTextColor={Colors.textColor}
                                        selectionColor={Colors.textColor}
                                        maxLength={16}
                                        minLength={6}
                                        secureTextEntry={this.state.secureOldPasswordText}
                                        onChangeText={(input) => this.setState({ oldPassword: input })}
                                        onSubmitEditing={() => { Keyboard.dismiss() }}
                                        style={{
                                            color: Colors.textColor,
                                            width: mobileW * 75 / 100,
                                            paddingVertical: mobileW * 3.5 / 100,
                                            paddingLeft: 18,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}
                                    ></TextInput>
                                    <TouchableOpacity onPress={() => { this.eyeOldPasswordPress() }}
                                        style={styles.eyeButton}>
                                        <Text style={styles.showHideText}>{this.state.secureOldPasswordText ? "Show" : "Hide"}</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                            {/*  password text field  */}
                            {/* old password text field  */}
                            <View style={{ width: '100%', marginBottom: mobileW * 3 / 100, }}>
                                <View style={{ width: mobileW * 82 / 100, alignSelf: 'center' }}>
                                    <Text style={{
                                        marginBottom: mobileW * 2 / 100,
                                        color: Colors.greyColor,
                                        fontSize: Font.fontSize3half,
                                        fontFamily: Font.montserrat_Regular
                                    }}>
                                        New Password
                                    </Text>
                                </View>
                                <View style={{
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <TextInput
                                        keyboardType='default'
                                        placeholder={'New Password'}
                                        placeholderTextColor={Colors.textColor}
                                        selectionColor={Colors.textColor}
                                        maxLength={16}
                                        minLength={6}
                                        secureTextEntry={this.state.secureNewPasswordText}
                                        onChangeText={(input) => this.setState({ newPassword: input })}
                                        onSubmitEditing={() => { Keyboard.dismiss() }}
                                        style={{
                                            color: Colors.textColor,
                                            width: mobileW * 75 / 100,
                                            paddingVertical: mobileW * 3.5 / 100,
                                            paddingLeft: 18,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}
                                    ></TextInput>
                                    <TouchableOpacity onPress={() => { this.eyeNewPasswordPress() }}
                                        style={styles.eyeButton}>
                                        <Text style={styles.showHideText}>{this.state.secureNewPasswordText ? "Show" : "Hide"}</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                            {/*  password text field  */}
                            {/* old password text field  */}
                            <View style={{ width: '100%', marginBottom: mobileW * 3 / 100, }}>
                                <View style={{ width: mobileW * 82 / 100, alignSelf: 'center' }}>
                                    <Text style={{
                                        marginBottom: mobileW * 2 / 100,
                                        color: Colors.greyColor,
                                        fontSize: Font.fontSize3half,
                                        fontFamily: Font.montserrat_Regular
                                    }}>
                                        Confirm New Password
                                    </Text>
                                </View>
                                <View style={{
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <TextInput
                                        keyboardType='default'
                                        placeholder={'Confirm New Password'}
                                        placeholderTextColor={Colors.textColor}
                                        selectionColor={Colors.textColor}
                                        maxLength={16}
                                        minLength={6}
                                        secureTextEntry={this.state.secureConfirmNewPasswordText}
                                        onChangeText={(input) => this.setState({ confirmNewPassword: input })}
                                        onSubmitEditing={() => { Keyboard.dismiss() }}
                                        style={{
                                            color: Colors.textColor,
                                            width: mobileW * 75 / 100,
                                            paddingVertical: mobileW * 3.5 / 100,
                                            paddingLeft: 18,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}
                                    ></TextInput>
                                    <TouchableOpacity onPress={() => { this.eyeConfirmNewPasswordPress() }}
                                        style={styles.eyeButton}>
                                        <Text style={styles.showHideText}>{this.state.secureConfirmNewPasswordText ? "Show" : "Hide"}</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                            {/*  password text field  */}

                            <View style={{
                                marginTop: mobileW * 7 / 100,
                                width: mobileW * 90 / 100,
                                alignSelf: 'center',
                                height: mobileW * 22 / 100,
                                justifyContent: 'center'
                            }}>

                                <AppButton
                                    onPress={() => { this.changePasswordCallApi() }}
                                    title={"update"}
                                    color={Colors.whiteColor}
                                    backgroundColor={Colors.darkGreenColor}
                                />
                            </View>
                        </View>




                    </KeyboardAwareScrollView>
                </ScrollView>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    eyeButton: {
        width: mobileW * 15 / 100,
        height: mobileW * 8 / 100,
        alignItems: 'center',
        justifyContent: 'center',
        alignSelf: 'center'
    },
    showHideText: {
        color: Colors.darkGreenColor,
        fontSize: Font.fontSize3
    },
    button: {
        height: mobileW * 16 / 100,
        justifyContent: 'center',
        alignItems: 'center'
    },
});
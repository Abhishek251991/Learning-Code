import React, { Component } from 'react'
import { TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Keyboard } from 'react-native';
import { color } from 'react-native-reanimated';


const AppButton = ({ onPress, title, color, backgroundColor }) => (
    <TouchableOpacity
        style={[Styles.loginButton, { backgroundColor: backgroundColor }]}
        activeOpacity={.7}
        onPress={onPress}
    >
        <Text style={{
            fontSize: Font.fontSize4,
            color: color,
            textTransform: 'uppercase',
            fontFamily: Font.montserrat_Bold
        }}>{title}</Text>
    </TouchableOpacity>
);
export default class AddMeetingScreen extends Component {
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Add Meeting</Text>
                            </View>
                        </View>
                        <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', marginTop: mobileW * 4 / 100 }}>

                            <Text style={Styles.inputLabelText}>Meeting Title</Text>

                            <View style={{
                                justifyContent: 'center',

                            }}>
                                <TextInput
                                    style={Styles.textInputEmail}
                                    borderColor={Colors.borderColorCode}
                                    keyboardType={'default'}
                                    placeholder={'Business Meeting'}
                                    placeholderTextColor={Colors.textColor}
                                    maxLength={64}
                                    onChangeText={(input) => this.setState({ title: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                ></TextInput>
                            </View>


                            <Text style={Styles.inputLabelText}>Meeting Date</Text>
                            <TouchableOpacity>
                                <View style={{ borderWidth: 0.7, paddingVertical: mobileW * 3.5 / 100, padding: mobileW * 3 / 100, borderColor: Colors.borderColorCode, flexDirection: 'row', alignItems: 'center' }}>
                                    <Text style={{ width: '90%', color: Colors.textColor, fontSize: mobileW * 3.5 / 100, fontFamily: Font.montserrat_Medium }}   >
                                        DD/MM/YY
                                    </Text>
                                    <View style={{ width: '10%', alignItems: 'center' }}>
                                        <Image source={localImage.calenderImage}
                                            style={{ alignSelf: 'center', width: mobileW * 6 / 100, height: mobileW * 6 / 100, resizeMode: 'contain' }}>
                                        </Image>
                                    </View>
                                </View>
                            </TouchableOpacity>

                            <Text style={Styles.inputLabelText}>Select User</Text>
                            <TouchableOpacity>
                                <View style={{ borderWidth: 0.7, paddingVertical: mobileW * 3.5 / 100, padding: mobileW * 3 / 100, borderColor: Colors.borderColorCode, flexDirection: 'row', alignItems: 'center' }}>
                                    <Text style={{ width: '90%', color: Colors.textColor, fontSize: mobileW * 3.5 / 100, fontFamily: Font.montserrat_Medium }}   >
                                        Select User
                                    </Text>
                                    <View style={{ width: '10%', alignItems: 'center' }}>
                                        <Image source={require('../../icons/down_arrow.png')}
                                            style={{ alignSelf: 'center', width: mobileW * 3 / 100, height: mobileW * 3 / 100, resizeMode: 'contain' }}>
                                        </Image>
                                    </View>
                                </View>
                            </TouchableOpacity>
                            <AppButton
                                onPress={() => { this.props.navigation.goBack() }}
                                title="submit"
                                color={Colors.whiteColor}
                                backgroundColor={Colors.darkGreenColor}
                            />
                            {/* <TouchableOpacity onPress={() => { this.props.navigation.goBack() }}>
                                <View style={{ borderWidth: 0.7, paddingVertical: mobileW * 3.5 / 100, padding: mobileW * 3 / 100, borderColor: Colors.borderColorCode, flexDirection: 'row', alignItems: 'center', backgroundColor: '#60bb78', marginTop: mobileW * 10 / 100 }}>
                                    <Text style={{ width: '90%', color: '#fff', fontSize: mobileW * 4 / 100, fontFamily: Font.montserrat_Medium, textAlign: 'center' }}   >
                                        Submit
                                    </Text>
                                </View>
                            </TouchableOpacity> */}


                        </View>







                    </KeyboardAwareScrollView>
                </ScrollView>
            </View>
        )
    }
}
const Styles = StyleSheet.create({


    inputLabelText: {
        color: Colors.greyColor,
        fontSize: mobileW * 3.5 / 100,
        fontFamily: Font.montserrat_Regular,
        margin: mobileW * 2.5 / 100
    },
    textInputEmail: {
        color: Colors.textColor,
        borderWidth: 0.7,
        paddingVertical: mobileW * 3 / 100,
        padding: mobileW * 3 / 100,
        fontSize: mobileW * 3.5 / 100,
        fontFamily: Font.montserrat_Medium
    },
    loginButton: {
        marginTop: mobileW * 10 / 100,
        height: mobileW * 14 / 100,
        justifyContent: 'center',
        alignItems: 'center'
    },

})
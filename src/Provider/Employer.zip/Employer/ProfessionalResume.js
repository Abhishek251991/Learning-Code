import React, { Component } from 'react'
import { Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, ImageBackground } from 'react-native';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Footer from '../../Provider/Footer';
import EmployerFooter from './EmployerFooter';

export default class ProfesionalResumeScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            usertype: 2
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView style={{ paddingBottom: mobileW * 5 / 100 }} contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <ImageBackground style={{ width: mobileW * 100 / 100, height: mobileH * 55 / 100 }} source={require('../../icons/employer_home_icon.png')} >
                            <View style={{
                                flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                                alignItems: 'center', height: mobileH * 8 / 100
                            }}>
                                <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                                    <Image source={localImage.backArrowImage}
                                        style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain', tintColor: '#fff' }}>
                                    </Image>
                                </TouchableOpacity>
                                <View style={{ width: '90%', alignSelf: 'center' }}>
                                    <Text style={{
                                        width: '100%', fontSize: Font.fontSize5, color: '#fff',
                                        fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                    }}>Professional Resume</Text>
                                </View>
                            </View>
                        </ImageBackground>
                        <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', marginTop: mobileW * 7 / 100, }}>
                            <Text style={{
                                fontSize: mobileW * 3.5 / 100, color: '#000',
                                fontFamily: Font.montserrat_Bold, textAlign: 'justify'
                            }}>Fill it online, and download in secands.Build a professional design C.V add ready-to-use suggestions, and get the job</Text>
                            <Text style={{
                                marginTop: mobileW * 5 / 100,
                                fontSize: mobileW * 3.5 / 100, color: '#000',
                                fontFamily: Font.montserrat_Bold, textAlign: 'justify'
                            }}>Choose a C.V template,fill it out ,and download in secands.Create a professional curriculum vltate in a few click.Just pick one of designed cv templetes below,and ready to use suggestions,and get the job</Text>
                            <Text style={styles.textView}>. Select design and click on genrate PDF in A4 size</Text>
                            <Text style={styles.textView}>. Can print your resume with your printer</Text>
                            <Text style={styles.textView}>. Can use while applying on new job</Text>
                            <Text style={styles.textView}>. Can upload to CV manager as a default for your aplplied jobs.</Text>
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        )
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    textView: {
        fontSize: mobileW * 3 / 100,
        fontFamily: Font.montserrat_Medium,
        marginTop: mobileW * 1 / 100,
        color: Colors.greyColor

    }

});
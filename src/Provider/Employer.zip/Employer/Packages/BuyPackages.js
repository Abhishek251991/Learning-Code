
import React, { Component } from 'react';
import { SafeAreaView, FlatList, ScrollView, Image, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import EmployerFooter from '../EmployerFooter';

const tab_arr = [
    { 'name': 'CV Packages', status: false, navigate: 'EmployerPackageScreen' },
    { 'name': 'Job Packages', status: true, navigate: 'JobPackages' },
    { 'name': 'Buy Packages', status: false, navigate: 'NA' },
]

const BuyPackage = [
    {
        id: '#28173', name: 'Basic C.V Pack', remaining: '9', resumeStatus: 'Active', owner: 'Elijah', status: true, city: 'Zürich', days: '10', price: '19,000', start: 1, end: 2
    },
    {
        id: '#28174', name: 'Standard', remaining: '8', resumeStatus: 'Expired', owner: 'James', status: false, city: 'Geneva', days: '11', price: '18,000', start: 3, end: 3
    },
    {
        id: '#28175', name: 'Basic C.V Pack', remaining: '8', resumeStatus: 'Active', owner: 'Benjamin', status: false, city: 'Basel', days: '12', price: '17,000', start: 4, end: 6
    }, {
        id: '#28176', name: 'Standard', remaining: '8', resumeStatus: 'Expired', owner: 'Lucas', status: false, city: 'Sion', days: '13', price: '16,000', start: 5, end: 6
    }, {
        id: '#28177', name: 'Basic C.V Pack', remaining: '8', resumeStatus: 'Active', owner: 'Elijah', status: false, city: 'Schaffhausen', days: '14', price: '15,000', start: 7, end: 8
    }, {
        id: '#28178', name: 'Standard', remaining: '14', resumeStatus: 'Expired', owner: 'Henry', status: false, city: 'Basel', days: '15', price: '14,000', start: 1, end: 8
    }, {
        id: '#28179', name: 'Basic C.V Pack', remaining: '4', resumeStatus: 'Expired', owner: 'Alexander', status: false, city: 'Fribourg', days: '16', price: '13,000', start: 11, end: 25
    }, {
        id: '#28171', name: 'Standard', remaining: '4', resumeStatus: 'Active', owner: 'Mason', status: false, city: 'Basel', days: '17', price: '12,000', start: 13, end: 30
    }, {
        id: '#28172', name: 'Basic C.V Pack', remaining: '8', resumeStatus: 'Active', owner: 'Michael', status: false, city: 'Thun', days: '18', price: '11,000', start: 10, end: 20
    }, {
        id: '#28170', name: 'Standard', remaining: '14', resumeStatus: 'Expired', owner: 'Ethan', status: false, city: 'Lucerne', days: '19', price: '10,000', start: 5, end: 15
    },
];

const data_arr = [
    {
        'heading': 'Basic-Free',
        'msg': 'First step to becoming everything you want to be',
        'offer': 'FREE',
        'msg_offer': 'Is mail worked with a number of remittance business as well as international policy marker',
        'one': '1st job posting',
        'two': 'Featured on Demand',
        'three': 'Job displayed for 30 days',
        'Four': 'Preminum Support 24/7',

        'view_point': false
    },
    {
        'heading': 'STANDART',
        'msg': 'First step to becoming everything you want to be',
        'offer': '$100',
        'msg_offer': 'Is mail worked with a number of remittance business as well as international policy marker',
        'one': '2 Jobs posting ',
        'two': 'Job Displayed for 30days',


        'view_point': true
    }
]
const data_arr_sec = [
    {
        'one': '1st job posting',
        'two': 'Featured on Demand',
        'three': 'Job displayed for 30 days',
        'Four': 'Preminum Support 24/7',

        'view_point': false
    },
    {
        'one': '2 Jobs posting ',
        'two': 'Job Displayed for 30days',


        'view_point': true
    }
]



const sec_arr = [
    {
        'heading': 'Basic-Free',
        'msg': 'First step to becoming everything you want to be',
        'offer': 'FREE',
        'msg_offer': 'Is mail worked with a number of remittance business as well as international policy marker',
        'one': '2 Views Only',
        'two': 'Access to 10 Resumes',
        'three': 'CV displayed for 10 days',
        'Four': 'No Candidate Featured On Demand',
        'five': 'No premium Support',
        'view_point': false
    },
    {
        'heading': 'Power CV Package',
        'msg': 'First step to becoming everything you want to be',
        'offer': '$100',
        'msg_offer': 'Is mail worked with a number of remittance business as well as international policy marker',
        'one': '5 Views ',
        'two': 'Access to 15 Resumes',

        'view_point': true
    }
]
export default class BuyPackageScreen extends Component {
    constructor(props) {
        super(props)
        this.state = {
            sec_arr: sec_arr,
            tab_arr: tab_arr,
            buyPackage: BuyPackage,
            data_arr: data_arr,
            tabpage: 'pending',
            data_arr_sec: data_arr_sec


        }
    }
    clicktabbtn = (item, index) => {
        let data = this.state.tab_arr
        for (let i = 0; i < data.length; i++) {
            data[i].status = false
        }
        data[index].status = true
        this.setState({ tab_arr: data, tabpage: item.name })
    }
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: Colors.whiteColor, }}>
                <ScrollView style={{ paddingBottom: mobileW * 30 / 100 }} contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Packages</Text>
                            </View>
                        </View>

                        <View style={{ width: '100%', alignSelf: 'center', paddingTop: mobileW * 5 / 100 }}>
                            <FlatList
                                data={this.state.tab_arr}
                                horizontal={true}
                                showsHorizontalScrollIndicator={false}
                                renderItem={({ item, index }) => {
                                    return (
                                        <TouchableOpacity onPress={() => {
                                            this.clicktabbtn(item, index)
                                            if (item.navigate != "NA") {
                                                this.props.navigation.navigate(item.navigate);
                                            }
                                        }} style={[{ width: 130, borderBottomColor: Colors.greyColor, borderBottomWidth: 3, paddingVertical: 5 }, item.status == true ? { borderBottomColor: '#60bb78' } : null]}>
                                            <Text style={{ fontSize: mobileW * 3.5 / 100, fontFamily: Font.montserrat_Bold, color: Colors.greyColor, textAlign: 'center' }} numberOfLines={1}>{item.name}</Text>
                                        </TouchableOpacity>
                                    )
                                }}
                                keyExtractor={(item, index) => index.toString()}
                            />
                        </View>

                        <View style={commonStyle.container}>
                            <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                                <KeyboardAwareScrollView>
                                    <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                                    <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />
                                    <View style={styles.screenBody}>
                                        <FlatList
                                            style={{ width: mobileW * 95 / 100, alignSelf: 'center', marginBottom: mobileW * 2 / 100 }}
                                            data={this.state.buyPackage}
                                            renderItem={({ item, index }) =>
                                                <View style={styles.cardShadowView}>
                                                    <View style={{
                                                        paddingVertical: mobileW * 3 / 100,
                                                        paddingHorizontal: mobileW * 3 / 100,
                                                        flexDirection: 'row',
                                                        justifyContent: 'space-between',
                                                    }}>
                                                        <Text style={{ color: Colors.greyColor, fontSize: Font.fontSize3, fontFamily: Font.montserrat_Medium }}>
                                                            {item.id}
                                                        </Text>
                                                        <Text style={{ color: Colors.greyColor, fontSize: Font.fontSize3, fontFamily: Font.montserrat_Medium }}>
                                                            Setember {item.start}, 2021 - Setember {item.end}, 2021
                                                        </Text>
                                                    </View>

                                                    <View style={{
                                                        paddingVertical: mobileW * 1 / 100,
                                                        paddingHorizontal: mobileW * 3 / 100,
                                                        flexDirection: 'row',
                                                        justifyContent: 'space-between',
                                                    }}>
                                                        <Text style={{
                                                            color: Colors.textColor,
                                                            fontSize: Font.fontSize4,
                                                            fontFamily: Font.montserrat_Bold
                                                        }}>
                                                            {item.name}
                                                        </Text>
                                                        <Text style={{
                                                            backgroundColor: item.resumeStatus == "Expired" ? Colors.darkYellowColor : Colors.darkGreenColor,
                                                            color: Colors.whiteColor,
                                                            paddingVertical: mobileW * 0.4 / 100,
                                                            paddingHorizontal: mobileW * 3 / 100,
                                                            fontSize: Font.fontSize3,
                                                            justifyContent: 'center',
                                                            fontFamily: Font.montserrat_Medium
                                                        }}>
                                                            {item.resumeStatus}
                                                        </Text>
                                                    </View>

                                                    <View style={{
                                                        flexDirection: 'row', paddingTop: mobileW * 3 / 100,
                                                        justifyContent: 'space-between'
                                                    }}>
                                                        <View style={{
                                                            backgroundColor: Colors.silverLightColor,
                                                            width: mobileW * 29.5 / 100,
                                                            paddingHorizontal: mobileW * 3 / 100
                                                        }}>
                                                            <View style={{
                                                                alignSelf: 'center',
                                                                paddingVertical: mobileW * 2 / 100
                                                            }}>
                                                                <Text style={{
                                                                    color: Colors.textColor,
                                                                    fontFamily: Font.montserrat_Medium,
                                                                    fontSize: Font.fontSize4,
                                                                    textAlign: 'center'
                                                                }}>{item.days}</Text>
                                                                <Text style={{
                                                                    color: Colors.textColor,
                                                                    fontFamily: Font.montserrat_Medium,
                                                                    fontSize: Font.fontSize2half
                                                                }}>CVs Total</Text>
                                                            </View>
                                                        </View>
                                                        <View style={{
                                                            backgroundColor: Colors.silverLightColor,
                                                            width: mobileW * 29.5 / 100,
                                                            paddingVertical: mobileW * 2 / 100
                                                        }}>
                                                            <View style={{ alignSelf: 'center' }}>
                                                                <Text style={{
                                                                    paddingLeft: mobileW * 2 / 100,
                                                                    color: Colors.textColor,
                                                                    fontFamily: Font.montserrat_Medium,
                                                                    fontSize: Font.fontSize4,
                                                                    textAlign: 'center'
                                                                }}>{item.start}</Text>
                                                                <Text style={{
                                                                    paddingLeft: mobileW * 2 / 100,
                                                                    color: Colors.textColor,
                                                                    fontFamily: Font.montserrat_Medium,
                                                                    fontSize: Font.fontSize2half
                                                                }}>CVs Used</Text>
                                                            </View>
                                                        </View>
                                                        <View style={{
                                                            backgroundColor: Colors.silverLightColor,
                                                            width: mobileW * 29.5 / 100,
                                                            paddingVertical: mobileW * 2 / 100
                                                        }}>
                                                            <View style={{ alignSelf: 'center' }}>
                                                                <Text style={{
                                                                    paddingLeft: mobileW * 2 / 100,
                                                                    color: Colors.textColor,
                                                                    fontFamily: Font.montserrat_Medium,
                                                                    fontSize: Font.fontSize4,
                                                                    textAlign: 'center'
                                                                }}>{item.remaining}</Text>
                                                                <Text style={{
                                                                    paddingLeft: mobileW * 2 / 100,
                                                                    color: Colors.textColor,
                                                                    fontFamily: Font.montserrat_Medium,
                                                                    fontSize: Font.fontSize2half,

                                                                }}>Cvs Remainings</Text>
                                                            </View>
                                                        </View>
                                                    </View>
                                                </View>
                                            }
                                            keyExtractor={(item, index) => index.toString()}
                                        >
                                        </FlatList>
                                    </View>
                                </KeyboardAwareScrollView>
                            </ScrollView>
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        {
                            name: 'Employer', label: 'Main', countshow: false, image: require('../../../icons/sector_blue.png'),
                            activeimage: require('../../../icons/home_active_icon.png')
                        },
                        {
                            name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../../icons/bell_icon.png'),
                            activeimage: require('../../../icons/bell_active_icon.png')
                        },
                        {
                            name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../../icons/list_icon.png'),
                            activeimage: require('../../../icons/mylist_active_icon.png')
                        },
                        {
                            name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false,
                            image: require('../../../icons/account_icon.png'), activeimage: require('../../../icons/acount_active_icon.png')
                        },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        )
    }
}
const styles = StyleSheet.create({

    mainBox: {
        width: mobileW * 55 / 100,

        borderWidth: 4,
        borderColor: '#f5f7fc',
        alignItems: 'center',
        padding: mobileW * 1 / 100,
        margin: mobileW * 2 / 100

    },
    mainBox_new: {
        width: mobileW * 55 / 100,
        paddingVertical: mobileH * 1 / 100,
        borderWidth: 4,
        borderColor: '#f5f7fc',
        alignItems: 'center',

        margin: mobileW * 2 / 100
    },
    thiredView: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'center',
        padding: mobileW * 1 / 100,
        marginTop: mobileW * 2 / 100



    },
    ImageView: {
        width: '15%',
        alignSelf: 'center',

    },
    contentView: {
        width: '85%',
        alignSelf: 'center',
    },
    appBarStyle: {
        flexDirection: 'row',
        width: '100%',
        paddingHorizontal: 10,
        alignItems: 'center',
        backgroundColor: Colors.whiteColor,
        height: mobileH * 8 / 100,
    },
    leadingContainerStyle: {
        width: '15%',
    },
    leadingIcon: {
        marginLeft: mobileW * 3 / 100,
        width: mobileW * 7 / 100,
        height: mobileW * 7 / 100,
        resizeMode: 'contain'
    },
    centerContainerStyle: {
        width: '70%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    centerTitleText: {
        width: '100%',
        fontSize: Font.fontSize5,
        color: Colors.textColor,
        fontFamily: Font.montserrat_Bold,
        textAlign: 'center'
    },
    actionContainerStyle: {
        width: '15%'
    },
    actionButtons: {
        alignSelf: 'center',
        width: mobileW * 7.5 / 100,
        height: mobileW * 7.5 / 100,
        resizeMode: 'contain'
    },
    screenBody: {
        width: mobileW * 100 / 100,
        alignSelf: 'center',
    },
    cardShadowView: {
        width: mobileW * 90 / 100,
        marginBottom: 1,
        marginTop: mobileW * 4 / 100,
        alignSelf: 'center',
        backgroundColor: Colors.whiteColor,
        shadowColor: '#000',
        shadowOffset: {
            width: 2,
            height: 2,
        },
        shadowOpacity: 0.5,
        shadowRadius: 0.5,
        elevation: 2,
    },
    textView: {
        color: Colors.textColor,
        fontSize: mobileW * 3 / 100,
        fontFamily: Font.montserrat_Medium,
    },
    textView2: {
        color: Colors.textColor,
        fontSize: mobileW * 3 / 100,
        fontFamily: Font.montserrat_Medium,
        textAlign: 'center'
    }

})


// import React, { Component } from 'react';
// import { SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
// import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
// import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

// const DATASAVEDCANDIDATE = [
//     {
//         id: '#28173', name: 'Basic C.V Pack', remaining: '9', resumeStatus: 'Active', owner: 'Elijah', status: true, city: 'Zürich', days: '10', price: '19,000', start: 1, end: 2
//     },
//     {
//         id: '#28174', name: 'Standard', remaining: '8', resumeStatus: 'Expired', owner: 'James', status: false, city: 'Geneva', days: '11', price: '18,000', start: 3, end: 3
//     },
//     {
//         id: '#28175', name: 'Basic C.V Pack', remaining: '8', resumeStatus: 'Active', owner: 'Benjamin', status: false, city: 'Basel', days: '12', price: '17,000', start: 4, end: 6
//     }, {
//         id: '#28176', name: 'Standard', remaining: '8', resumeStatus: 'Expired', owner: 'Lucas', status: false, city: 'Sion', days: '13', price: '16,000', start: 5, end: 6
//     }, {
//         id: '#28177', name: 'Basic C.V Pack', remaining: '8', resumeStatus: 'Active', owner: 'Elijah', status: false, city: 'Schaffhausen', days: '14', price: '15,000', start: 7, end: 8
//     }, {
//         id: '#28178', name: 'Standard', remaining: '14', resumeStatus: 'Expired', owner: 'Henry', status: false, city: 'Basel', days: '15', price: '14,000', start: 1, end: 8
//     }, {
//         id: '#28179', name: 'Basic C.V Pack', remaining: '4', resumeStatus: 'Expired', owner: 'Alexander', status: false, city: 'Fribourg', days: '16', price: '13,000', start: 11, end: 25
//     }, {
//         id: '#28171', name: 'Standard', remaining: '4', resumeStatus: 'Active', owner: 'Mason', status: false, city: 'Basel', days: '17', price: '12,000', start: 13, end: 30
//     }, {
//         id: '#28172', name: 'Basic C.V Pack', remaining: '8', resumeStatus: 'Active', owner: 'Michael', status: false, city: 'Thun', days: '18', price: '11,000', start: 10, end: 20
//     }, {
//         id: '#28170', name: 'Standard', remaining: '14', resumeStatus: 'Expired', owner: 'Ethan', status: false, city: 'Lucerne', days: '19', price: '10,000', start: 5, end: 15
//     },
// ];

// export default class BuyPackagesScreen extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             savedCandidateArray: DATASAVEDCANDIDATE,
//             usertype: localStorage.getItemString('userType')
//         }
//     }

//     render() {
//         return (
//             <View style={commonStyle.container}>
//                 <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
//                     <KeyboardAwareScrollView>
//                         <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
//                         <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />
//                         <View style={styles.screenBody}>
//                             <FlatList
//                                 style={{ width: mobileW * 95 / 100, alignSelf: 'center', marginBottom: mobileW * 2 / 100 }}
//                                 data={this.state.savedCandidateArray}
//                                 renderItem={({ item, index }) =>
//                                     <View style={styles.cardShadowView}>
//                                         <View style={{
//                                             paddingVertical: mobileW * 3 / 100,
//                                             paddingHorizontal: mobileW * 3 / 100,
//                                             flexDirection: 'row',
//                                             justifyContent: 'space-between',
//                                         }}>
//                                             <Text style={{ color: Colors.greyColor, fontSize: Font.fontSize3, fontFamily: Font.montserrat_Medium }}>
//                                                 {item.id}
//                                             </Text>
//                                             <Text style={{ color: Colors.greyColor, fontSize: Font.fontSize3, fontFamily: Font.montserrat_Medium }}>
//                                                 Setember {item.start}, 2021 - Setember {item.end}, 2021
//                                             </Text>
//                                         </View>

//                                         <View style={{
//                                             paddingVertical: mobileW * 1 / 100,
//                                             paddingHorizontal: mobileW * 3 / 100,
//                                             flexDirection: 'row',
//                                             justifyContent: 'space-between',
//                                         }}>
//                                             <Text style={{
//                                                 color: Colors.textColor,
//                                                 fontSize: Font.fontSize4,
//                                                 fontFamily: Font.montserrat_Bold
//                                             }}>
//                                                 {item.name}
//                                             </Text>
//                                             <Text style={{
//                                                 backgroundColor: item.resumeStatus == "Expired" ? Colors.darkYellowColor : Colors.darkGreenColor,
//                                                 color: Colors.whiteColor,
//                                                 paddingVertical: mobileW * 0.4 / 100,
//                                                 paddingHorizontal: mobileW * 3 / 100,
//                                                 fontSize: Font.fontSize3,
//                                                 justifyContent: 'center',
//                                                 fontFamily: Font.montserrat_Medium
//                                             }}>
//                                                 {item.resumeStatus}
//                                             </Text>
//                                         </View>

//                                         <View style={{
//                                             flexDirection: 'row', paddingTop: mobileW * 3 / 100,
//                                             justifyContent: 'space-between'
//                                         }}>
//                                             <View style={{
//                                                 backgroundColor: Colors.silverLightColor,
//                                                 width: mobileW * 29.5 / 100,
//                                                 paddingHorizontal: mobileW * 3 / 100
//                                             }}>
//                                                 <View style={{
//                                                     alignSelf: 'center',
//                                                     paddingVertical: mobileW * 2 / 100
//                                                 }}>
//                                                     <Text style={{
//                                                         color: Colors.textColor,
//                                                         fontFamily: Font.montserrat_Medium,
//                                                         fontSize: Font.fontSize4,
//                                                         textAlign: 'center'
//                                                     }}>{item.days}</Text>
//                                                     <Text style={{
//                                                         color: Colors.textColor,
//                                                         fontFamily: Font.montserrat_Medium,
//                                                         fontSize: Font.fontSize2half
//                                                     }}>CVs Total</Text>
//                                                 </View>
//                                             </View>
//                                             <View style={{
//                                                 backgroundColor: Colors.silverLightColor,
//                                                 width: mobileW * 29.5 / 100,
//                                                 paddingVertical: mobileW * 2 / 100
//                                             }}>
//                                                 <View style={{ alignSelf: 'center' }}>
//                                                     <Text style={{
//                                                         paddingLeft: mobileW * 2 / 100,
//                                                         color: Colors.textColor,
//                                                         fontFamily: Font.montserrat_Medium,
//                                                         fontSize: Font.fontSize4,
//                                                         textAlign: 'center'
//                                                     }}>{item.start}</Text>
//                                                     <Text style={{
//                                                         paddingLeft: mobileW * 2 / 100,
//                                                         color: Colors.textColor,
//                                                         fontFamily: Font.montserrat_Medium,
//                                                         fontSize: Font.fontSize2half
//                                                     }}>CVs Used</Text>
//                                                 </View>
//                                             </View>
//                                             <View style={{
//                                                 backgroundColor: Colors.silverLightColor,
//                                                 width: mobileW * 29.5 / 100,
//                                                 paddingVertical: mobileW * 2 / 100
//                                             }}>
//                                                 <View style={{ alignSelf: 'center' }}>
//                                                     <Text style={{
//                                                         paddingLeft: mobileW * 2 / 100,
//                                                         color: Colors.textColor,
//                                                         fontFamily: Font.montserrat_Medium,
//                                                         fontSize: Font.fontSize4,
//                                                         textAlign: 'center'
//                                                     }}>{item.remaining}</Text>
//                                                     <Text style={{
//                                                         paddingLeft: mobileW * 2 / 100,
//                                                         color: Colors.textColor,
//                                                         fontFamily: Font.montserrat_Medium,
//                                                         fontSize: Font.fontSize2half,

//                                                     }}>Cvs Remainings</Text>
//                                                 </View>
//                                             </View>
//                                         </View>
//                                     </View>
//                                 }
//                                 keyExtractor={(item, index) => index.toString()}
//                             >
//                             </FlatList>
//                         </View>
//                     </KeyboardAwareScrollView>
//                 </ScrollView>
//             </View>
//         );
//     }
// }

// const styles = StyleSheet.create({
//     appBarStyle: {
//         flexDirection: 'row',
//         width: '100%',
//         paddingHorizontal: 10,
//         alignItems: 'center',
//         backgroundColor: Colors.whiteColor,
//         height: mobileH * 8 / 100,
//     },
//     leadingContainerStyle: {
//         width: '15%',
//     },
//     leadingIcon: {
//         marginLeft: mobileW * 3 / 100,
//         width: mobileW * 7 / 100,
//         height: mobileW * 7 / 100,
//         resizeMode: 'contain'
//     },
//     centerContainerStyle: {
//         width: '70%',
//         justifyContent: 'center',
//         alignItems: 'center'
//     },
//     centerTitleText: {
//         width: '100%',
//         fontSize: Font.fontSize5,
//         color: Colors.textColor,
//         fontFamily: Font.montserrat_Bold,
//         textAlign: 'center'
//     },
//     actionContainerStyle: {
//         width: '15%'
//     },
//     actionButtons: {
//         alignSelf: 'center',
//         width: mobileW * 7.5 / 100,
//         height: mobileW * 7.5 / 100,
//         resizeMode: 'contain'
//     },
//     screenBody: {
//         width: mobileW * 100 / 100,
//         alignSelf: 'center',
//     },
//     cardShadowView: {
//         width: mobileW * 90 / 100,
//         marginBottom: 1,
//         marginTop: mobileW * 4 / 100,
//         alignSelf: 'center',
//         backgroundColor: Colors.whiteColor,
//         shadowColor: '#000',
//         shadowOffset: {
//             width: 2,
//             height: 2,
//         },
//         shadowOpacity: 0.5,
//         shadowRadius: 0.5,
//         elevation: 2,
//     }
// });
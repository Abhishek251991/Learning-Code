import React, { Component } from 'react';
import { SafeAreaView, FlatList, ScrollView, Image, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Footer from '../../../Provider/Footer';
import EmployerFooter from '../EmployerFooter';
const tab_arr = [
    { 'name': 'CV Packages', status: true, navigate: 'NA' },
    { 'name': 'Job Packages', status: false, navigate: 'JobPackages' },
    { 'name': 'Buy Packages', status: false, navigate: 'BuyPackage' },
]
const data_arr = [
    {
        'heading': 'Basic-Free',
        'msg': 'First step to becoming everything you want to be',
        'offer': 'FREE',
        'msg_offer': 'Is mail worked with a number of remittance business as well as international policy marker',
        'one': '2 Views Only',
        'two': 'Access to 10 Resumes',
        'three': 'CV displayed for 10 days',
        'Four': 'No Candidate Featured On Demand',
        'five': 'No premium Support',
        'view_point': false
    },
    {
        'heading': 'Power CV Package',
        'msg': 'First step to becoming everything you want to be',
        'offer': '$30.00',
        'msg_offer': 'Is mail worked with a number of remittance business as well as international policy marker',
        'one': '5 Views ',
        'two': 'Access to 15 Resumes',
        'three': 'CV displayed for 10 days',
        'Four': 'No Candidate Featured On Demand',
        'five': 'No premium Support',
        'view_point': true
    }
]
const sec_arr = [
    {
        'heading': 'Basic-Free',
        'msg': 'First step to becoming everything you want to be',
        'offer': 'FREE',
        'msg_offer': 'Is mail worked with a number of remittance business as well as international policy marker',
        'one': '2 Views Only',
        'two': 'Access to 10 Resumes',
        'three': 'CV displayed for 10 days',
        'Four': 'No Candidate Featured On Demand',
        'five': 'No premium Support',
        'view_point': false
    },
    {
        'heading': 'Power CV Package',
        'msg': 'First step to becoming everything you want to be',
        'offer': '$30.00',
        'msg_offer': 'Is mail worked with a number of remittance business as well as international policy marker',
        'one': '5 Views ',
        'two': 'Access to 15 Resumes',
        'three': 'CV displayed for 10 days',
        'Four': 'No Candidate Featured On Demand',
        'five': 'No premium Support',
        'view_point': true
    }
]
export default class EmployerPackageScreen extends Component {
    constructor(props) {
        super(props)
        this.state = {
            sec_arr: sec_arr,
            tab_arr: tab_arr,
            data_arr: data_arr,
            tabpage: 'pending',


        }
    }
    clicktabbtn = (item, index) => {
        let data = this.state.tab_arr
        for (let i = 0; i < data.length; i++) {
            data[i].status = false
        }
        data[index].status = true
        this.setState({ tab_arr: data, tabpage: item.name })
    }
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: Colors.whiteColor, }}>
                <ScrollView style={{ paddingBottom: mobileW * 30 / 100 }} contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Packages</Text>
                            </View>
                        </View>

                        <View style={{ width: '100%', alignSelf: 'center', paddingTop: mobileW * 5 / 100 }}>
                            <FlatList
                                data={this.state.tab_arr}
                                horizontal={true}
                                showsHorizontalScrollIndicator={false}
                                renderItem={({ item, index }) => {
                                    return (
                                        <TouchableOpacity onPress={() => {
                                            this.clicktabbtn(item, index)
                                            if (item.navigate != "NA") {
                                                this.props.navigation.navigate(item.navigate);
                                            }
                                        }} style={[{ width: 130, borderBottomColor: Colors.greyColor, borderBottomWidth: 3, paddingVertical: 5 }, item.status == true ? { borderBottomColor: '#60bb78' } : null]}>
                                            <Text style={{ fontSize: mobileW * 3.5 / 100, fontFamily: Font.montserrat_Bold, color: Colors.greyColor, textAlign: 'center' }} numberOfLines={1}>{item.name}</Text>
                                        </TouchableOpacity>
                                    )
                                }}
                                keyExtractor={(item, index) => index.toString()}
                            />
                        </View>
                        <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', justifyContent: 'center', marginTop: mobileW * 4 / 100 }}>
                            <Text style={{ fontFamily: Font.montserrat_Bold, fontSize: mobileW * 5 / 100, textAlign: 'left', color: Colors.textColor }}>Our CV Packages</Text>
                            <Text style={{ fontFamily: Font.montserrat_Medium, fontSize: mobileW * 3.3 / 100, textAlign: 'left', marginTop: mobileW * 3 / 100 }}>A better career is out there.Well help you find it. We're your first step to becoming everything you want to be</Text>

                            <View >
                                <FlatList
                                    data={this.state.data_arr}
                                    horizontal={true}
                                    showsHorizontalScrollIndicator={false}
                                    renderItem={({ item, index }) => {
                                        return (
                                            <View style={Styles.mainBox}>

                                                <Text style={{ color: '#60bb78', fontFamily: Font.montserrat_Bold, fontSize: mobileW * 4 / 100 }} numberOfLines={1}>{item.heading}</Text>
                                                <Text style={{ color: Colors.textColor, fontFamily: Font.montserrat_Medium, fontSize: mobileW * 2.5 / 100, textAlign: 'center' }} numberOfLines={2}>{item.msg}</Text>
                                                <View style={{ backgroundColor: '#f5f7fc', width: '100%', alignItems: 'center', padding: mobileW * 2 / 100 }}>
                                                    <Text style={{ color: Colors.textColor, fontFamily: Font.montserrat_Bold, fontSize: mobileW * 8 / 100 }} numberOfLines={1}>{item.offer}</Text>
                                                    {/* {item.view_point == true &&
                <Text style={{color:Colors.textColor,fontFamily:Font.montserrat_Bold,fontSize:mobileW*3/100}} >Only</Text>} */}

                                                    <Text style={{ color: Colors.textColor, fontFamily: Font.montserrat_Medium, fontSize: mobileW * 2 / 100, textAlign: 'center', width: '100%', marginTop: mobileW * 2.5 / 100 }} numberOfLines={3}>{item.msg_offer}</Text>

                                                </View>
                                                <View style={Styles.thiredView}>
                                                    <View style={Styles.ImageView}>
                                                        <Image style={{ width: mobileW * 5 / 100, height: mobileH * 3 / 100 }} source={require('../../../icons/72.png')}></Image></View>
                                                    <View style={Styles.contentView}>
                                                        <Text style={Styles.textView}>{item.one} </Text>
                                                    </View>
                                                </View>
                                                <View style={Styles.thiredView}>
                                                    <View style={Styles.ImageView}>
                                                        <Image style={{ width: mobileW * 5 / 100, height: mobileH * 3 / 100 }} source={require('../../../icons/72.png')}></Image></View>
                                                    <View style={Styles.contentView}>
                                                        <Text style={Styles.textView}>{item.two} </Text>
                                                    </View>
                                                </View>
                                                <View style={Styles.thiredView}>
                                                    <View style={Styles.ImageView}>
                                                        <Image style={{ width: mobileW * 5 / 100, height: mobileH * 3 / 100 }} source={require('../../../icons/72.png')}></Image></View>
                                                    <View style={Styles.contentView}>
                                                        <Text style={Styles.textView}>{item.three} </Text>
                                                    </View>
                                                </View>
                                                <View style={Styles.thiredView}>
                                                    <View style={Styles.ImageView}>
                                                        <Image style={{ width: mobileW * 5 / 100, height: mobileH * 3 / 100 }} source={require('../../../icons/72.png')}></Image></View>
                                                    <View style={Styles.contentView}>
                                                        <Text style={Styles.textView}>{item.Four} </Text>
                                                    </View>
                                                </View>
                                                <View style={Styles.thiredView}>
                                                    <View style={Styles.ImageView}>
                                                        <Image style={{ width: mobileW * 5 / 100, height: mobileH * 3 / 100 }} source={require('../../../icons/72.png')}></Image></View>
                                                    <View style={Styles.contentView}>
                                                        <Text style={Styles.textView}>{item.five} </Text>
                                                    </View>
                                                </View>
                                                <TouchableOpacity>
                                                    <View style={{ backgroundColor: '#60bb78', alignSelf: 'center', alignItems: 'center', width: mobileW * 50 / 100, height: mobileH * 6 / 100, alignSelf: 'center', justifyContent: 'center', marginTop: mobileW * 2 / 100, marginBottom: mobileW * 2 / 100 }}>
                                                        <Text style={{ color: '#fff', fontFamily: Font.montserrat_Bold, fontSize: mobileW * 5 / 100 }}>GET STARTED</Text>
                                                    </View>
                                                </TouchableOpacity>

                                            </View>
                                        )
                                    }}
                                    keyExtractor={(item, index) => index.toString()}
                                />
                            </View>

                            <Text style={{ fontFamily: Font.montserrat_Bold, fontSize: mobileW * 5 / 100, textAlign: 'left', color: Colors.textColor }}>Buy Additional C.V Packages</Text>
                            <Text style={{ fontFamily: Font.montserrat_Medium, fontSize: mobileW * 3.3 / 100, textAlign: 'left', marginTop: mobileW * 3 / 100 }}>A better career is out there.Well help you find it. We're your first step to becoming everything you want to be</Text>

                            <View >
                                <FlatList
                                    data={this.state.sec_arr}
                                    horizontal={true}
                                    contentContainerStyle={{ paddingBottom: mobileW * 30 / 100 }}
                                    showsHorizontalScrollIndicator={false}
                                    renderItem={({ item, index }) => {
                                        return (
                                            <View style={Styles.mainBox}>
                                                {item.view_point == true &&
                                                    <View style={{ width: mobileW * 50 / 100, paddingVertical: mobileW * 1.5 / 100, alignSelf: 'center', justifyContent: 'center', backgroundColor: Colors.textColor, alignItems: 'center' }}>
                                                        <Text style={{ color: '#fff', fontFamily: Font.montserrat_Bold, fontSize: mobileW * 4 / 100 }}>Special C.V Off</Text>
                                                    </View>}
                                                <Text style={{ color: '#60bb78', fontFamily: Font.montserrat_Bold, fontSize: mobileW * 4 / 100, marginBottom: mobileW * 2 / 100 }} numberOfLines={1}>{item.heading}</Text>

                                                <View style={{ backgroundColor: '#f5f7fc', width: '100%', alignItems: 'center', padding: mobileW * 2 / 100 }}>
                                                    <Text style={{ color: Colors.textColor, fontFamily: Font.montserrat_Bold, fontSize: mobileW * 8 / 100 }} numberOfLines={1}>{item.offer}</Text>
                                                    <TouchableOpacity>
                                                        <View style={{ backgroundColor: '#60bb78', alignSelf: 'center', alignItems: 'center', width: mobileW * 40 / 100, height: mobileH * 6 / 100, alignSelf: 'center', justifyContent: 'center', marginTop: mobileW * 2 / 100, marginBottom: mobileW * 2 / 100, borderRadius: mobileW * 5 / 100 }}>
                                                            <Text style={{ color: '#fff', fontFamily: Font.montserrat_Bold, fontSize: mobileW * 4 / 100 }}>CHOOSE PLAN</Text>
                                                        </View>
                                                    </TouchableOpacity>

                                                </View>
                                                <View style={Styles.thiredView}>

                                                    <View style={Styles.contentView}>
                                                        <Text style={Styles.textView2}>{item.one} </Text>
                                                    </View>
                                                </View>
                                                <View style={Styles.thiredView}>

                                                    <View style={Styles.contentView}>
                                                        <Text style={Styles.textView2}>{item.two} </Text>
                                                    </View>
                                                </View>
                                                <View style={Styles.thiredView}>

                                                    <View style={Styles.contentView}>
                                                        <Text style={Styles.textView2}>{item.three} </Text>
                                                    </View>
                                                </View>
                                                <View style={Styles.thiredView}>

                                                    <View style={Styles.contentView}>
                                                        <Text style={Styles.textView2}>{item.Four} </Text>
                                                    </View>
                                                </View>
                                                <View style={Styles.thiredView}>
                                                    <View style={Styles.contentView}>
                                                        <Text style={Styles.textView2}>{item.five} </Text>
                                                    </View>
                                                </View>
                                            </View>
                                        )
                                    }}
                                    keyExtractor={(item, index) => index.toString()}
                                />
                            </View>
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        {
                            name: 'Employer', label: 'Main', countshow: false, image: require('../../../icons/sector_blue.png'),
                            activeimage: require('../../../icons/home_active_icon.png')
                        },
                        {
                            name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../../icons/bell_icon.png'),
                            activeimage: require('../../../icons/bell_active_icon.png')
                        },
                        {
                            name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../../icons/list_icon.png'),
                            activeimage: require('../../../icons/mylist_active_icon.png')
                        },
                        {
                            name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false,
                            image: require('../../../icons/account_icon.png'), activeimage: require('../../../icons/acount_active_icon.png')
                        },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        )
    }
}
const Styles = StyleSheet.create({



    mainBox: {
        width: mobileW * 55 / 100,

        borderWidth: 4,
        borderColor: '#f5f7fc',
        alignItems: 'center',
        padding: mobileW * 1 / 100,
        margin: mobileW * 2 / 100

    },
    thiredView: {
        flexDirection: 'row',
        alignItems: 'center',
        alignSelf: 'center',
        padding: mobileW * 1 / 100,



    },
    ImageView: {
        width: '15%',
        alignSelf: 'center',

    },
    contentView: {
        width: '85%',
        alignSelf: 'center',


    },
    textView: {
        color: Colors.textColor,
        fontSize: mobileW * 3 / 100,
        fontFamily: Font.montserrat_Medium,
    },
    textView2: {
        color: Colors.textColor,
        fontSize: mobileW * 3 / 100,
        fontFamily: Font.montserrat_Medium,
        textAlign: 'center'
    }

})
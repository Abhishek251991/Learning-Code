import React, { Component } from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity, FlatList } from 'react-native';
import { Colors, Font, commonStyle, mobileW, mobileH, localStorage, } from '../../Provider/utilslib/Utils';

const DATA = [
    {
        name: 'Dashboard', navigate: 'EmployerDashboard', status: false
    },
    {
        name: 'Compnay Profile', navigate: 'EmployerComponyProfileScreen', status: false
    },
    {
        name: 'Post A New Job', navigate: 'PostANewJob', status: false
    },
    {
        name: 'Manage Jobs', navigate: 'EmployerManageJobs', status: false
    },
    {
        name: 'All Applicants', navigate: 'EmployerMyList', status: false
    },
    {
        name: 'Meetings', navigate: 'Meeting', status: false
    },
    {
        name: 'Saved Candidated', navigate: 'SavedCandidate', status: false
    },
    {
        name: 'Packages', navigate: 'EmployerPackageScreen', status: false
    },
    {
        name: 'Transactions', navigate: 'Transctions', status: false
    },
    {
        name: 'Followers', navigate: 'Followers', status: false
    },
    {
        name: 'Change Password', navigate: 'ChangePassword', status: false
    },
    {
        name: 'Message/Chat', navigate: 'MessageChat', status: false
    },
    {
        name: 'Candidate', navigate: 'CandidateScreen', status: false
    },
    {
        name: 'Reviews', navigate: 'EmployerReviewScreen', status: false
    },
    {
        name: '5 Tips For Success', navigate: 'TipSucsess', status: false
    }
];

export default class EmployerHomedrawer extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data_arr: DATA,
            componyName: 'Zeeva Hairing Co',
        }
    }
    callFuntion = (index) => {
        let data = this.state.data_arr;
        for (let i = 0; i < data.length; i++)
            data[i].status = false;

        data[index].status = true;
        this.setState({ data_arr: data });
    }
    render() {
        return (
            <View style={commonStyle.container}>

                <View style={{
                    height: mobileW * 24 / 100,
                    alignItems: 'center',
                    justifyContent: 'center'
                }}>
                    <Image source={require('../../icons/employer_profile_icon.png')} style={{
                        height: mobileW * 20 / 100, width: mobileW * 20 / 100,
                        borderRadius: mobileW * 10 / 100,
                    }} />
                </View>
                <View style={{ alignSelf: 'center' }}>
                    <Text style={{
                        fontSize: mobileW * 4.5 / 100,
                        fontFamily: Font.montserrat_Bold,
                        color: Colors.textColor
                    }}>
                        {this.state.componyName}
                    </Text>
                </View>
                <FlatList
                    style={{ marginTop: mobileW * 4 / 100, alignSelf: 'center' }}
                    data={this.state.data_arr}
                    showsVerticalScrollIndicator={false}
                    renderItem={({ item, index }) => {
                        return (
                            <TouchableOpacity activeOpacity={.7} onPress={() => {
                                this.callFuntion(index)
                                if (item.navigate != "NA") {
                                    this.props.navigation.navigate(item.navigate);
                                }
                            }}>
                                <View style={{
                                    marginTop: mobileW * 4 / 100,
                                    justifyContent: 'center',
                                }}>
                                    <View style={{ flexDirection: 'row', }}>
                                        <Image source={item.status == true ?
                                            require('../../icons/acount_active_icon.png') :
                                            require('../../icons/account_icon.png')}
                                            style={{ height: 24, width: 24, }} />
                                        <View style={{ justifyContent: 'center' }}>
                                            <Text style={{
                                                marginLeft: mobileW * 3.5 / 100,
                                                fontSize: Font.fontSize3half,
                                                color: item.status == true ? Colors.darkGreenColor : Colors.textColor,
                                                fontFamily: Font.montserrat_Regular
                                            }}>
                                                {item.name}
                                            </Text>
                                        </View>
                                    </View>
                                </View>
                            </TouchableOpacity>
                        );
                    }}
                    keyExtractor={(item, index) => index.toString()}
                />
            </View>
        )
    }
}
const styles = StyleSheet.create({

    borderView: {
        borderBottomWidth: 1,
        borderColor: '#eeeeee',
        width: mobileW * 65 / 100,
        marginBottom: mobileW * 2 / 100,
        marginTop: mobileW * 2 / 100
    },
    borderViewsec: {
        borderBottomWidth: 1,
        borderColor: '#eeeeee',
        width: mobileW * 67 / 100,

        marginTop: mobileW * 4 / 100,

    },
    FirstView: {
        flexDirection: 'row',
        marginTop: mobileW * 4 / 100
    },
    textView: {
        fontFamily: Font.fontregular,
        fontSize: mobileW * 3.5 / 100,
        alignSelf: 'center',
        color: Colors.black_color,
        marginLeft: mobileW * 3 / 100
    }
})
import React, { Component } from 'react';
import { FlatList, Keyboard, TextInput, Image, Modal, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Footer from '../../Provider/Footer';
import { mobileW, commonStyle, mobileH, Colors, Font, localStorage, } from '../../Provider/utilslib/Utils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import StarRating from 'react-native-star-rating';
import EmployerFooter from './EmployerFooter';

const DATA = [
    {
        option: 'Description',
        status: true
    },
    {
        option: 'Team Members',
        status: false
    },
    {
        option: 'Active Jobs',
        status: false
    },
];

const DATAReletedJob = [
    {
        name: 'Accounting finance ', subName: 'Carter', city: 'Zürich', days: '4', status: false
    },
    {
        name: 'Accounting', subName: 'Christopher', city: 'Zürich', days: '14', status: true
    },
    {
        name: 'Agriculture', subName: 'Julian', city: 'Lucerne', days: '9', status: false
    },
    {
        name: 'Accounting finance', subName: 'Jayden', city: 'Gallen', days: '2', status: false
    },
    {
        name: 'Art', subName: 'Grayson', city: 'Winterthur', days: '7', status: false
    },
    {
        name: 'Education', subName: 'Lincoln', city: 'Lausanne', days: '2', status: false
    },
    {
        name: 'School', subName: 'Ezra', city: 'Basel', days: '1', status: false
    },
    {
        name: 'Hospital', subName: 'Thomas', city: 'Bienne', days: '6', status: false
    },
    {
        name: 'Medical', subName: 'Anthony', city: 'Lugano', days: '7', status: false
    },
    {
        name: 'Freelance', subName: 'Hudson', city: 'Bern', days: '5', status: false
    },
];

const InputLabel = ({ inputLabel }) => (
    <View style={styles.labelStyle}>
        <Text style={styles.textFieldLabel}>
            {inputLabel}
        </Text>
    </View>
);
const DATATEAMMEMBERS = [
    {
        name: 'Kathleen Moreno', jobDescription: 'Qs Manager', experience: 'Experience : 5 Years', status: false,
    },
    {
        name: 'Linda Henderson', jobDescription: 'Charity & Voluntary', experience: 'Experience : 9 Years', status: false,
    },
    {
        name: 'Peter Hawkins', jobDescription: 'Bank Manager', experience: 'Experience : 15 Years', status: true,
    },
    {
        name: 'Ralph Johnson', jobDescription: 'Qs Manager', experience: 'Experience : 5 Years', status: true,
    },
];

const AppButton = ({ onPress, title, color, backgroundColor }) => (
    <TouchableOpacity
        style={{
            backgroundColor: backgroundColor,
            height: mobileW * 14 / 100,
            justifyContent: 'center',
            alignItems: 'center'
        }}
        activeOpacity={.7}
        onPress={onPress}
    >
        <Text style={{
            fontSize: Font.fontSize4,
            color: color,
            textTransform: 'uppercase',
            fontFamily: Font.montserrat_Medium
        }}>{title}</Text>
    </TouchableOpacity>
);


export default class EmployerComponayDetail extends Component {
    constructor(props) {
        super(props);
        this.state = {
            releted_job_data_arr: DATAReletedJob,
            data_arr: DATA,
            data_team_members: DATATEAMMEMBERS,
            isDescription: true,
            isTeamMembers: false,
            isActiveJobs: false,
            isVisibleAddReview: false,
            usertype: localStorage.getItemString('userType'),
            review: '',
            contactFormModalVisible: false,
            checkboxCondition: false,
        }
    }
    checkboxTermsAndCondition = () => {
        if (this.state.checkboxCondition) {
            this.setState({ checkboxCondition: false })
        } else {
            this.setState({ checkboxCondition: true })
        }
    }
    callFunction = (index) => {
        let value = index.toString();
        switch (value) {
            case '0':
                this.setState({ isDescription: true, isTeamMembers: false, isActiveJobs: false });
                break;
            case '1':
                this.setState({ isDescription: false, isTeamMembers: true, isActiveJobs: false });
                break;
            case '2':
                this.setState({ isDescription: false, isTeamMembers: false, isActiveJobs: true });
                break;
        }
        let data = this.state.data_arr;
        for (let i = 0; i < data.length; i++)
            data[i].status = false;
        data[index].status = true;
        this.setState({ data_arr: data });
    }

    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* Review Modal  */}
                        <Modal
                            animationType={'slide'}
                            transparent={true}
                            backgroundColor={'red'}
                            visible={this.state.isVisibleAddReview}
                            onRequestClose={() => { console.log("Modal has been closed.") }}>
                            <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                                <View style={{
                                    marginTop: 'auto',
                                    height: '50%',
                                    width: mobileW * 100 / 100,
                                    backgroundColor: Colors.whiteColor,
                                    shadowColor: '#000',
                                    shadowOffset: {
                                        width: 0,
                                        height: 2,
                                    },
                                    shadowOpacity: 5,
                                    shadowRadius: 5,
                                    elevation: 22,
                                }}>
                                    <TouchableOpacity activeOpacity={.7} onPress={() => {
                                        this.setState({ isVisibleAddReview: false })
                                    }}>
                                        <View
                                            style={{
                                                height: mobileW * 5 / 100,
                                            }}
                                        />
                                        <View style={{
                                            width: mobileW * 15 / 100,
                                            borderBottomColor: Colors.darkGreenColor,
                                            borderRadius: 6,
                                            alignSelf: 'center',
                                            borderBottomWidth: 6
                                        }}>
                                        </View>
                                    </TouchableOpacity>
                                    <View style={{ width: mobileW * 85 / 100, alignSelf: 'center' }}>
                                        <View>
                                            <Text style={{
                                                marginTop: mobileW * 2 / 100,
                                                fontFamily: Font.montserrat_Bold,
                                                color: Colors.textColor,
                                                fontSize: Font.fontSize4
                                            }}>
                                                Review
                                            </Text>
                                        </View>
                                        <View style={{ width: mobileW * 40 / 100, alignSelf: 'center' }}>
                                            <StarRating
                                                containerStyle={{ paddingLeft: mobileW * 2 / 100 }}
                                                // containerStyle={{ }}
                                                emptyStar={require('../../icons/start_blank.png')}
                                                fullStar={require('../../icons/start_fill.png')}
                                                halfStar={require('../../icons/half_star.png')}
                                                disabled={true}
                                                maxStars={5}
                                                rating={3}
                                                starSize={mobileW * 5 / 100}
                                            // selectedStar={(rating) => this.onStarRatingPress(rating)}
                                            />
                                        </View>

                                        <View style={[styles.containerStyle, { marginTop: mobileW * 10 / 100 }]}>
                                            <TextInput
                                                keyboardType='default'
                                                placeholder={'Review'}
                                                placeholderTextColor={Colors.textColor}
                                                selectionColor={Colors.textColor}
                                                multiline={true}
                                                onChangeText={(input) => this.setState({ review: input })}
                                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                                style={{
                                                    textAlignVertical: 'top',
                                                    color: Colors.textColor,
                                                    alignSelf: 'center',
                                                    borderColor: Colors.greyColor,
                                                    borderWidth: 0.7,
                                                    width: mobileW * 90 / 100,
                                                    height: mobileW * 30 / 100,
                                                    paddingLeft: 18,
                                                    fontSize: Font.fontSize4,
                                                    fontFamily: Font.montserrat_Regular
                                                }}
                                            ></TextInput>
                                        </View>
                                        <View style={{ width: mobileW * 90 / 100, marginTop: mobileW * 10 / 100, alignSelf: 'center' }}>
                                            <AppButton
                                                onPress={() => { this.setState({ isVisibleAddReview: false }) }}
                                                title={'submit review'}
                                                color={Colors.whiteColor}
                                                backgroundColor={Colors.darkGreenColor}
                                            />
                                        </View>

                                    </View>
                                </View>
                            </ScrollView>
                        </Modal>
                        {/* Review Modal  */}
                        {/* Contact Form Modal  */}
                        <Modal
                            animationType={'slide'}
                            transparent={true}
                            backgroundColor={'red'}
                            visible={this.state.contactFormModalVisible}
                            onRequestClose={() => { console.log("Modal has been closed.") }}>
                            <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                                <View style={{
                                    marginTop: 'auto',
                                    height: '80%',
                                    width: mobileW * 100 / 100,
                                    backgroundColor: Colors.whiteColor,
                                    shadowColor: '#000',
                                    shadowOffset: {
                                        width: 0,
                                        height: 2,
                                    },
                                    shadowOpacity: 5,
                                    shadowRadius: 5,
                                    elevation: 22,
                                }}>
                                    <TouchableOpacity activeOpacity={.7} onPress={() => {
                                        this.setState({ contactFormModalVisible: false })
                                    }}>
                                        <View
                                            style={{
                                                height: mobileW * 5 / 100,
                                            }}
                                        />
                                        <View style={{
                                            width: mobileW * 15 / 100,
                                            borderBottomColor: Colors.darkGreenColor,
                                            borderRadius: 6,
                                            alignSelf: 'center',
                                            borderBottomWidth: 6
                                        }}>
                                        </View>
                                    </TouchableOpacity>
                                    <View style={{ width: mobileW * 90 / 100, alignSelf: 'center' }}>
                                        <View>
                                            <Text style={{
                                                marginTop: mobileW * 2 / 100,
                                                fontFamily: Font.montserrat_Bold,
                                                color: Colors.textColor,
                                                fontSize: Font.fontSize4
                                            }}>
                                                Contact Form
                                            </Text>
                                        </View>
                                        <View style={{ marginTop: mobileW * 5 / 100 }}>
                                            <View style={styles.containerStyle}>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'User Name'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ memberTitle: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                            <View style={styles.containerStyle}>
                                                <TextInput
                                                    keyboardType='email-address'
                                                    placeholder={'Email Address'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ memberTitle: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                            <View style={styles.containerStyle}>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Phone Number'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    maxLength={50}
                                                    onChangeText={(input) => this.setState({ memberTitle: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={styles.inputStyle}
                                                ></TextInput>
                                            </View>
                                            <View style={[styles.containerStyle, {}]}>
                                                <TextInput
                                                    keyboardType='default'
                                                    placeholder={'Mesasage'}
                                                    placeholderTextColor={Colors.textColor}
                                                    selectionColor={Colors.textColor}
                                                    multiline={true}
                                                    onChangeText={(input) => this.setState({ review: input })}
                                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                                    style={{
                                                        textAlignVertical: 'top',
                                                        color: Colors.textColor,
                                                        alignSelf: 'center',
                                                        borderColor: Colors.greyColor,
                                                        borderWidth: 0.7,
                                                        width: mobileW * 90 / 100,
                                                        height: mobileW * 30 / 100,
                                                        paddingLeft: 18,
                                                        fontSize: Font.fontSize4,
                                                        fontFamily: Font.montserrat_Regular
                                                    }}
                                                ></TextInput>
                                            </View>
                                            <View style={{ width: mobileW * 90 / 100, marginTop: mobileW * 10 / 100, alignSelf: 'center' }}>
                                                <AppButton
                                                    onPress={() => { this.setState({ contactFormModalVisible: false }) }}
                                                    title={'send now'}
                                                    color={Colors.whiteColor}
                                                    backgroundColor={Colors.darkGreenColor}
                                                />
                                            </View>
                                            <View style={{ width: '100%', marginTop: mobileW * 5 / 100 }}>
                                                <View style={{ flexDirection: 'row', }}>

                                                    <View style={{ justifyContent: 'center', alignItems: 'center', }}>

                                                        <TouchableOpacity
                                                            onPress={() => this.checkboxTermsAndCondition()}
                                                            style={{
                                                                flexDirection: 'row', width: mobileW * 10 / 100,
                                                                justifyContent: 'space-between',
                                                            }}>
                                                            {this.state.checkboxCondition ?
                                                                <MaterialCommunityIcons name='check-box-outline' size={40} color={Colors.darkGreenColor} />
                                                                : <MaterialCommunityIcons name='checkbox-blank-outline' size={40} color={Colors.darkGreenColor} />}
                                                        </TouchableOpacity>
                                                    </View>
                                                    <View style={{ width: mobileW * 70 / 100, paddingTop: mobileW * 2 / 100 }}>
                                                        <Text style={{ width: mobileW * 70 / 100, fontSize: mobileW * 4 / 100, color: Colors.textColorLight }}>
                                                            By clicking checkbox , you agree to our
                                                        </Text>
                                                        <View style={{ flexDirection: 'row', }}>
                                                            <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.textColor, fontFamily: Font.montserrat_Bold }}>
                                                                Terms and Conditions
                                                            </Text>
                                                            <Text style={{ fontSize: mobileW * 3.5 / 100, color: Colors.textColorLight, paddingLeft: 5, }}>
                                                                and
                                                            </Text>
                                                            <Text style={{ paddingLeft: 5, fontSize: mobileW * 3.5 / 100, color: Colors.textColor, fontFamily: Font.montserrat_Bold }}>
                                                                Privacy Policy
                                                            </Text>
                                                        </View>
                                                    </View>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                            </ScrollView>
                        </Modal>
                        {/* Contact Form Modal  */}
                        {/* App Bar Start  */}
                        <View style={{
                            backgroundColor: Colors.whiteColor, width: mobileW * 100 / 100,
                            height: mobileW * 22 / 100
                        }}>
                            <View style={{ flexDirection: 'row' }}>
                                <TouchableOpacity style={{ width: '15%', height: mobileW * 12 / 100, justifyContent: 'center' }} onPress={() => {
                                    this.props.navigation.goBack()
                                }}>
                                    <Image source={require('../../icons/back_icon.png')}
                                        style={{
                                            alignSelf: 'center', width: mobileW * 7 / 100,
                                            height: mobileW * 7 / 100, resizeMode: 'contain'
                                        }}>
                                    </Image>
                                </TouchableOpacity>

                                <View style={{
                                    width: '70%',
                                    marginTop: mobileW * 2.5 / 100,
                                    height: mobileW * 19 / 100,
                                    justifyContent: 'center'
                                }} onPress={() => {

                                }}>
                                    <Image source={require('../../icons/placeholder.png')}
                                        style={{
                                            alignSelf: 'center', width: mobileW * 17 / 100,
                                            height: mobileW * 17 / 100, resizeMode: 'contain'
                                        }}>
                                    </Image>
                                </View>

                                <TouchableOpacity style={{
                                    width: '15%',
                                    height: mobileW * 12 / 100,
                                    justifyContent: 'center',
                                    marginTop: mobileW * 2.5 / 100,
                                }} onPress={() => {
                                    this.setState({ contactFormModalVisible: !this.state.contactFormModalVisible })
                                }}>
                                    <Image source={require('../../icons/message_icon.png')}
                                        style={{
                                            alignSelf: 'center', width: mobileW * 9 / 100,
                                            height: mobileW * 9 / 100, resizeMode: 'contain'
                                        }}>
                                    </Image>
                                </TouchableOpacity>
                            </View>
                        </View>
                        {/* app bar start  */}
                        <View style={{ width: mobileW * 90 / 100, alignSelf: 'center' }}>

                            <View style={{
                                alignSelf: 'center',
                                justifyContent: 'center',
                            }}>
                                <Text style={{
                                    fontFamily: Font.montserrat_Bold,
                                    color: Colors.textColor,
                                    fontSize: Font.fontSize5
                                }}>
                                    Ebiquity Maxi
                                </Text>
                            </View>

                            <View style={{
                                marginTop: mobileW * 3 / 100,
                                alignSelf: 'center',
                                width: mobileW * 22 / 100,
                                justifyContent: 'center',
                                alignItems: 'center',
                                backgroundColor: 'rgb(214,181,72)'
                            }}>
                                <Text numberOfLines={1}
                                    style={{
                                        textTransform: 'uppercase',
                                        color: Colors.whiteColor,
                                        paddingVertical: mobileW * 1 / 100,
                                        fontFamily: Font.montserrat_Medium,
                                        fontSize: Font.fontSize3,
                                        textTransform: 'uppercase'
                                    }}>
                                    featured
                                </Text>
                            </View>

                            <View style={{
                                flexDirection: 'row', justifyContent: 'center',
                                marginTop: mobileW * 2.5 / 100
                            }}>
                                <Image source={require('../../icons/location_icon.png')} style={{ height: mobileW * 6.3 / 100, width: mobileW * 4.8 / 100 }} />
                                <Text style={{ paddingLeft: 8, color: Colors.textColor, fontSize: Font.fontSize3half, fontFamily: Font.montserrat_Regular }}>Regent st,Carnaby,London W1B 5AH,UK</Text>
                            </View>

                            {/* A review and follow button  */}
                            <View style={{
                                flexDirection: 'row', marginTop: mobileW * 5 / 100,
                                justifyContent: 'space-between'
                            }}>
                                <TouchableOpacity activeOpacity={.7} onPress={() => { this.setState({ isVisibleAddReview: !this.state.isVisibleAddReview }) }}>
                                    <View style={{
                                        backgroundColor: Colors.darkGreenColor,
                                        justifyContent: 'center',
                                        width: mobileW * 44 / 100,
                                        paddingVertical: mobileW * 2.4 / 100
                                    }}>
                                        <Text style={{
                                            alignSelf: 'center',
                                            color: Colors.whiteColor,
                                            fontSize: mobileW * 3.5 / 100,
                                            fontFamily: Font.montserrat_Bold
                                        }}>
                                            + Add A Review
                                        </Text>
                                    </View>
                                </TouchableOpacity>
                                <TouchableOpacity activeOpacity={.7} onPress={() => { }}>
                                    <View style={{
                                        backgroundColor: Colors.darkGreenColor,
                                        justifyContent: 'center',
                                        width: mobileW * 44 / 100,
                                    }}>
                                        <View style={{
                                            flexDirection: 'row', alignSelf: 'center',
                                            paddingVertical: mobileW * 2.4 / 100
                                        }}>
                                            <Image source={require('../../icons/follow_icon.png')} style={{
                                                height: mobileW * 5 / 100, width: mobileW * 5 / 100
                                            }} />
                                            <Text style={{
                                                paddingLeft: mobileW * 2 / 100,
                                                alignSelf: 'center',
                                                color: Colors.whiteColor,
                                                fontSize: mobileW * 3.5 / 100,
                                                fontFamily: Font.montserrat_Bold
                                            }}>
                                                Follow
                                            </Text>
                                        </View>
                                    </View>
                                </TouchableOpacity>
                            </View>
                            {/* A review and follow button  */}
                        </View>
                        <View style={{ width: '100%' }}>
                            <FlatList
                                style={{
                                    width: mobileW * 100 / 100,
                                    marginTop: mobileW * 2 / 100,
                                }}
                                numColumns={3}
                                data={this.state.data_arr}
                                showsHorizontalScrollIndicator={false}
                                renderItem={({ item, index }) => {
                                    return (
                                        <TouchableOpacity onPress={() => {
                                            this.callFunction(index);
                                        }} activeOpacity={.7}>
                                            <Text style={{
                                                paddingVertical: mobileW * 3.5 / 100,
                                                paddingHorizontal: mobileW * 7.2 / 100,
                                                borderBottomColor: item.status ? Colors.darkGreenColor : Colors.greyColor,
                                                borderBottomWidth: item.status ? 2 : 1,
                                                color: item.status ? Colors.textColor : Colors.greyColor,
                                                fontFamily: item.status ? Font.montserrat_Bold : Font.montserrat_Medium,
                                                fontSize: item.status ? Font.fontSize3half : Font.fontSize3
                                            }}>
                                                {item.option}
                                            </Text>
                                        </TouchableOpacity>
                                    );
                                }}>
                            </FlatList>
                        </View>
                        {
                            this.state.isDescription &&
                            <View style={{
                                width: mobileW * 90 / 100,
                                alignSelf: 'center'
                            }}>
                                <View style={{
                                    marginTop: mobileW * 6 / 100,
                                    width: mobileW * 90 / 100, flexDirection: 'row',
                                    alignSelf: 'center'
                                }}>
                                    <View style={{ width: mobileW * 30 / 100 }}>
                                        <Image style={styles.imageSize} resizeMode={'contain'} source={require('../../icons/folder_icon.png')} />
                                        <View style={{ paddingVertical: mobileW * 3 / 100 }}>
                                            <Text style={styles.discriptionTextStyle}>
                                                Sectors Automotive Jobs
                                            </Text>
                                        </View>
                                    </View>
                                    <View style={{ width: mobileW * 30 / 100 }}>
                                        <Image style={styles.imageSize} resizeMode={'contain'} source={require('../../icons/green_bag_icon.png')} />
                                        <View style={{ paddingVertical: mobileW * 3 / 100 }}>
                                            <Text style={styles.discriptionTextStyle}>
                                                Post Jobs
                                            </Text>
                                            <Text style={styles.discriptionTextStyle}>
                                                1
                                            </Text>
                                        </View>
                                    </View>
                                    <View style={{ width: mobileW * 30 / 100 }}>
                                        <Image style={styles.imageSize} resizeMode={'contain'} source={require('../../icons/eye_icon_bg_white.png')} />
                                        <View style={{ paddingVertical: mobileW * 3 / 100 }}>
                                            <Text style={styles.discriptionTextStyle}>
                                                Viewed
                                            </Text>
                                            <Text style={styles.discriptionTextStyle}>
                                                1348
                                            </Text>
                                        </View>
                                    </View>
                                </View>
                                <View style={{ width: mobileW * 30 / 100, marginTop: mobileW * 4 / 100 }}>
                                    <Image style={styles.imageSize} resizeMode={'contain'}
                                        source={require('../../icons/calender_icon.png')} />
                                    <View style={{ paddingVertical: mobileW * 3 / 100 }}>
                                        <Text style={styles.discriptionTextStyle}>
                                            Viewed
                                        </Text>
                                        <Text style={styles.discriptionTextStyle}>
                                            1348
                                        </Text>
                                    </View>
                                </View>
                                <View style={{ width: mobileW * 90 / 100 }}>
                                    <View>
                                        <Text style={styles.companyTitleText}>Company Discription</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.companyDescriptionText}>
                                            Far much that one rank behheld bluebird after outside ignobly allegdly more when oh arroganlty vehement irresistibly fussy penguin insect additionally wow absolutely crud meretriciouslty haslity dalmatian a glowered inset one echidna casswary some parrot and  much goodness some froze the sullen much valiantly petted this along across highthandely much dog out thr mmuch alas evasiverly neutal lazy reset.
                                        </Text>
                                    </View>
                                </View>
                            </View>
                        }
                        {
                            this.state.isTeamMembers &&
                            <View style={{
                                width: mobileW * 90 / 100,
                                alignSelf: 'center',
                            }}>
                                <FlatList
                                    style={{ marginBottom: mobileW * 15 / 100, }}
                                    data={this.state.data_team_members}
                                    numColumns={2}
                                    renderItem={({ item, index }) => {
                                        return (
                                            <View style={{
                                                marginBottom: mobileW * 2.5 / 100,
                                                width: mobileW * 45 / 100,
                                            }}>
                                                <View style={{
                                                    width: mobileW * 42.5 / 100,
                                                    alignSelf: 'center',
                                                    marginTop: mobileW * 3.5 / 100
                                                }}>
                                                    <View style={{
                                                        alignSelf: 'center',
                                                        width: mobileW * 42.5 / 100,
                                                        paddingVertical: mobileW * 4.5 / 100,
                                                        backgroundColor: Colors.whiteColor,
                                                        shadowColor: 'red',
                                                        shadowOffset: {
                                                            width: 0,
                                                            height: 1,
                                                        },
                                                        shadowOpacity: 0.5,
                                                        shadowRadius: 0.5,
                                                        elevation: 3
                                                    }}>
                                                        <View>
                                                            <Image
                                                                borderRadius={mobileW * 50 / 100}
                                                                resizeMode={'contain'}
                                                                source={item.status ? require('../../icons/candidate_image.png') : null} style={item.status ? styles.cardImageSize : { width: 0, height: 0 }} />
                                                        </View>
                                                        <View>
                                                            <Text style={{
                                                                marginTop: mobileW * 2 / 100,
                                                                fontSize: Font.fontSize4,
                                                                alignSelf: 'center',
                                                                fontFamily: Font.montserrat_Bold,
                                                                color: Colors.textColor
                                                            }}>
                                                                {item.name}
                                                            </Text>
                                                            <Text style={{
                                                                marginTop: mobileW * 1.5 / 100,
                                                                fontSize: Font.fontSize3,
                                                                alignSelf: 'center',
                                                                fontFamily: Font.montserrat_Regular,
                                                                color: Colors.textColor
                                                            }}>
                                                                {item.jobDescription}
                                                            </Text>
                                                            <Text style={{
                                                                marginTop: mobileW * 1.5 / 100,
                                                                fontSize: Font.fontSize3,
                                                                alignSelf: 'center',
                                                                fontFamily: Font.montserrat_Regular,
                                                                color: Colors.darkGreenColor
                                                            }}>
                                                                {item.experience}
                                                            </Text>
                                                        </View>
                                                        <View style={{ width: mobileW * 39 / 100, alignSelf: 'center', marginTop: mobileW * 2 / 100 }}>
                                                            <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
                                                                <Image resizeMode={'contain'} source={require('../../icons/facebook_icon.png')} style={styles.social_icon} />
                                                                <Image resizeMode={'contain'} source={require('../../icons/google_icon.png')} style={styles.social_icon} />
                                                                <Image resizeMode={'contain'} source={require('../../icons/twitter_icon.png')} style={styles.social_icon} />
                                                                <Image resizeMode={'contain'} source={require('../../icons/linkedin_icon.png')} style={styles.social_icon} />
                                                            </View>
                                                        </View>
                                                    </View>
                                                </View>
                                            </View>
                                        );
                                    }}
                                    keyExtractor={(item, index) => index.toString()}
                                />
                            </View>
                        }
                        {
                            this.state.isActiveJobs &&
                            <View style={{ width: mobileW * 100 / 100 }}>
                                <View style={{
                                    width: mobileW * 91 / 100,
                                    alignSelf: 'center',
                                    marginBottom: mobileW * 17 / 100
                                }}>
                                    <FlatList
                                        data={this.state.releted_job_data_arr}
                                        renderItem={({ item, index }) =>
                                            <TouchableOpacity activeOpacity={.7} onPress={() => {
                                            }}>
                                                <View style={{
                                                    height: mobileW * 45 / 100,
                                                    width: mobileW * 90 / 100,
                                                    marginBottom: 1,
                                                    marginTop: mobileW * 4 / 100,
                                                    alignSelf: 'center',
                                                    backgroundColor: Colors.whiteColor,
                                                    shadowColor: '#000',
                                                    shadowOffset: {
                                                        width: 2,
                                                        height: 2,
                                                    },
                                                    shadowOpacity: 0.5,
                                                    shadowRadius: 0.5,
                                                    elevation: 2,
                                                }}>
                                                    <View style={{ flexDirection: 'row' }}>

                                                        <View style={{
                                                            width: mobileW * 30 / 100,
                                                            height: mobileW * 45 / 100,
                                                        }}>
                                                            <View style={{
                                                                marginTop: mobileW * 3 / 100,
                                                                height: mobileW * 22 / 100,
                                                                justifyContent: 'center',
                                                                alignItems: 'center',
                                                            }}>
                                                                <Image
                                                                    resizeMode={'cover'}
                                                                    style={{
                                                                        width: mobileW * 22 / 100,
                                                                        height: mobileW * 18 / 100,
                                                                    }} source={require('../../icons/placeholder.png')} />

                                                            </View>
                                                            <View style={{
                                                                width: mobileW * 30 / 100,
                                                                justifyContent: 'center',
                                                                alignItems: 'center',
                                                                height: mobileW * 6 / 100,
                                                            }}>

                                                                <View style={{
                                                                    width: mobileW * 22 / 100,
                                                                    height: mobileW * 6 / 100,
                                                                    justifyContent: 'center',
                                                                    alignItems: 'center',
                                                                    backgroundColor: 'rgb(214,181,72)'
                                                                }}>
                                                                    <Text numberOfLines={1}
                                                                        style={{
                                                                            textTransform: 'uppercase',
                                                                            color: Colors.whiteColor,
                                                                            fontFamily: Font.montserrat_Medium,
                                                                            fontSize: Font.fontSize3
                                                                        }}>
                                                                        part time
                                                                    </Text>
                                                                </View>
                                                            </View>
                                                        </View>
                                                        <View style={{
                                                            width: mobileW * 60 / 100,
                                                            height: mobileW * 45 / 100,
                                                        }}>
                                                            <View style={{ flexDirection: 'row' }}>
                                                                <View style={{
                                                                    width: mobileW * 48 / 100,
                                                                    height: mobileW * 26 / 100,
                                                                    justifyContent: 'center',
                                                                }}>
                                                                    <View style={{
                                                                        width: mobileW * 48 / 100,
                                                                        height: mobileW * 20 / 100,
                                                                        justifyContent: 'center',
                                                                    }}>
                                                                        <Text numberOfLines={2} style={{
                                                                            fontSize: Font.fontSize4,
                                                                            color: Colors.textColor,
                                                                            fontFamily: Font.montserrat_Bold
                                                                        }}>
                                                                            Marketing Expert For {item.name}
                                                                        </Text>
                                                                        <Text style={{
                                                                            color: Colors.lightGreenColor,
                                                                            fontSize: Font.fontSize4
                                                                        }}>
                                                                            @{item.subName}
                                                                        </Text>
                                                                    </View>
                                                                </View>

                                                                <View style={{
                                                                    width: mobileW * 8 / 100,
                                                                    height: mobileW * 17 / 100,
                                                                    justifyContent: 'center',
                                                                    alignItems: 'center',
                                                                }}>
                                                                    <TouchableOpacity activeOpacity={.7} onPress={() => { }}>
                                                                        <View style={{

                                                                            backgroundColor: item.status ? Colors.darkGreenColor : Colors.extraLightGreenColor,
                                                                            width: mobileW * 8 / 100,
                                                                            height: mobileW * 8 / 100,
                                                                            justifyContent: 'center',
                                                                            alignItems: 'center',
                                                                        }}>
                                                                            <MaterialCommunityIcons name='heart-outline'
                                                                                size={30} color={item.status ? Colors.whiteColor : Colors.darkGreenColor} />
                                                                        </View>
                                                                    </TouchableOpacity>
                                                                </View>
                                                            </View>
                                                            <View style={{
                                                                width: mobileW * 55 / 100,
                                                                height: mobileW * 6 / 100,

                                                                flexDirection: 'row'
                                                            }}>
                                                                <Image
                                                                    style={{
                                                                        width: 25,
                                                                        height: 20,
                                                                    }}
                                                                    resizeMode={'contain'}
                                                                    source={require('../../icons/bag_icon.png')} />
                                                                <Text numberOfLines={1} style={{
                                                                    paddingLeft: 10, fontSize: Font.fontSize3,
                                                                    fontFamily: Font.montserrat_Regular,
                                                                    color: Colors.textColorLight,
                                                                    marginRight: mobileW * 10 / 100,
                                                                }}>{item.name}</Text>
                                                            </View>

                                                            <View style={{
                                                                width: mobileW * 55 / 100,
                                                                height: mobileW * 6 / 100,
                                                                flexDirection: 'row',
                                                            }}>
                                                                <Image
                                                                    style={{
                                                                        width: 25,
                                                                        height: 20,
                                                                    }}
                                                                    resizeMode={'contain'}
                                                                    source={require('../../icons/location_icon.png')} />
                                                                <Text numberOfLines={1} style={{
                                                                    marginRight: mobileW * 10 / 100,
                                                                    paddingLeft: 10, fontSize: Font.fontSize3,
                                                                    fontFamily: Font.montserrat_Regular,
                                                                    color: Colors.textColorLight
                                                                }}>Regent St, Carnaby, {item.city}</Text>
                                                            </View>

                                                            <View style={{
                                                                width: mobileW * 55 / 100,
                                                                height: mobileW * 6 / 100,

                                                                flexDirection: 'row'
                                                            }}>
                                                                <Image
                                                                    style={{
                                                                        width: 25,
                                                                        height: 20,
                                                                    }}
                                                                    resizeMode={'contain'}
                                                                    source={require('../../icons/clock_icon.png')} />
                                                                <Text numberOfLines={1} style={{
                                                                    marginRight: mobileW * 10 / 100,
                                                                    paddingLeft: 10, fontSize: Font.fontSize3,
                                                                    fontFamily: Font.montserrat_Regular,
                                                                    color: Colors.textColorLight
                                                                }}>Published {item.days} days ago</Text>
                                                            </View>
                                                        </View>
                                                    </View>
                                                </View>
                                            </TouchableOpacity>
                                        }
                                    >
                                    </FlatList>
                                </View>
                            </View>
                        }
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    imageSize: {
        height: mobileW * 6.5 / 100,
        width: mobileW * 6.5 / 100,
        alignSelf: 'center'
    },
    discriptionTextStyle: {
        textAlign: 'center', color: Colors.textColor,
        fontSize: Font.fontSize2half,
        fontFamily: Font.montserrat_Medium,
    },
    companyTitleText: {
        color: Colors.textColor,
        fontFamily: Font.montserrat_Bold,
        fontSize: Font.fontSize4,
    },
    companyDescriptionText: {
        marginTop: mobileW * 2 / 100,
        marginBottom: mobileW * 18 / 100,
        color: Colors.textColor,
        fontFamily: Font.montserrat_Regular,
        fontSize: Font.fontSize3,
    },
    cardImageSize: {
        height: mobileW * 20 / 100,
        width: mobileW * 20 / 100,
        alignSelf: 'center'
    },
    social_icon: {
        width: mobileW * 6 / 100,
        height: mobileW * 6 / 100
    },
    starIconSize: {
        width: mobileW * 6 / 100,
        height: mobileW * 6 / 100
    },
    inputStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        paddingVertical: mobileW * 3.5 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    containerStyle: {
        width: '100%',
        marginTop: mobileW * 2 / 100,
        marginBottom: mobileW * 1 / 100,
    },
    labelStyle: {
        width: mobileW * 82 / 100, alignSelf: 'center'
    },
    textFieldLabel: {
        marginBottom: mobileW * 2 / 100,
        color: Colors.greyColor,
        fontSize: Font.fontSize3half,
        fontFamily: Font.montserrat_Regular
    },
});
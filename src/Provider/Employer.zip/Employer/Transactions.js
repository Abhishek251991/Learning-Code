import React, { Component } from 'react'
import { FlatList, Image, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Footer from '../../Provider/Footer';
import { mobileW, commonStyle, mobileH, Colors, localStorage, Font } from '../../Provider/utilslib/Utils';
import EmployerFooter from './EmployerFooter';

const DATA = [
    {
        number: '#28271', month: 'September 10,2021', type: 'Golden', price: '$90.00', paymentStatus: 'Accepted', colorValue: 'rgb(214,181,72)'
    },
    {
        number: '#28272', month: 'September 14,2021', type: 'Silver', price: '$100.00', paymentStatus: 'Pending', colorValue: Colors.darkGreenColor
    },
    {
        number: '#28273', month: 'September 18,2021', type: 'Golden', price: '$80.00', paymentStatus: 'Rejected', colorValue: 'red'
    },
    {
        number: '#28274', month: 'September 16,2021', type: 'Silver', price: '$50.00', paymentStatus: 'Accepted', colorValue: 'rgb(214,181,72)'
    },
    {
        number: '#28275', month: 'September 05,2021', type: 'Silver', price: '$70.00', paymentStatus: 'Pending', colorValue: 'rgb(214,181,72)'
    },
    {
        number: '#28278', month: 'September 12,2021', type: 'Silver', price: '$30.00', paymentStatus: 'Rejected', colorValue: 'red'
    },
    {
        number: '#28279', month: 'September 10,2021', type: 'Golden', price: '$40.00', paymentStatus: 'Accepted', colorValue: 'rgb(214,181,72)'
    },
    {
        number: '#28280', month: 'September 05,2021', type: 'Golden', price: '$70.00', paymentStatus: 'Pending', colorValue: Colors.darkGreenColor
    }
];

export default class TransctionsScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data_arr: DATA,
            usertype: localStorage.getItemString('userType')
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '15%', }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={require('../../icons/back_icon.png')}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Transactions</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={{ width: '78%' }}>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}

                        <FlatList
                            style={{
                                width: mobileW * 100 / 100,
                                alignSelf: 'center',
                                marginBottom: mobileW * 15 / 100
                            }}
                            data={this.state.data_arr}
                            showsHorizontalScrollIndicator={false}
                            renderItem={({ item, index }) => {
                                return (
                                    <View style={{
                                        height: mobileW * 32 / 100,
                                        marginTop: 10,
                                        width: mobileW * 90 / 100,
                                        alignSelf: 'center'
                                    }}>
                                        <View style={{
                                            height: mobileW * 30 / 100,
                                            width: mobileW * 90 / 100,
                                            alignSelf: 'center',
                                            backgroundColor: Colors.whiteColor,
                                            shadowColor: '#000',
                                            shadowOffset: {
                                                width: 0,
                                                height: 1,
                                            },
                                            shadowOpacity: 0.5,
                                            shadowRadius: 0.5,
                                            elevation: 3,
                                            padding: mobileW * 3 / 100
                                        }}>

                                            <View style={{
                                                flexDirection: 'row', justifyContent: 'space-between'
                                            }}>

                                                <View style={{ height: mobileW * 25 / 100, justifyContent: 'space-evenly' }}>
                                                    <Text style={{

                                                        color: Colors.greyColor,
                                                        fontFamily: Font.montserrat_Medium,
                                                        fontSize: Font.fontSize3
                                                    }}>
                                                        {item.number}
                                                    </Text>
                                                    <Text style={{
                                                        color: Colors.textColor,
                                                        fontFamily: Font.montserrat_Bold,
                                                        fontSize: Font.fontSize4
                                                    }}>
                                                        {item.type}
                                                    </Text>

                                                    <View style={{
                                                        height: mobileW * 10 / 100, width: mobileW * 25 / 100,
                                                        justifyContent: 'center'
                                                    }}>
                                                        <View style={{
                                                            height: mobileW * 6 / 100, width: mobileW * 20 / 100,

                                                            backgroundColor: item.colorValue, justifyContent: 'center',
                                                            alignItems: 'center'
                                                        }}>
                                                            <Text style={{ color: Colors.whiteColor, fontSize: Font.fontSize3half, fontFamily: Font.montserrat_Medium }}>{item.paymentStatus}</Text>
                                                        </View>
                                                    </View>
                                                </View>

                                                <View style={{ height: mobileW * 25 / 100, justifyContent: 'space-evenly' }}>
                                                    <Text style={{
                                                        textAlign: 'right',
                                                        fontSize: Font.fontSize3,
                                                        color: Colors.greyColor,
                                                        fontFamily: Font.montserrat_Medium
                                                    }}>
                                                        {item.month}
                                                    </Text>

                                                    <Text style={{
                                                        textAlign: 'right',
                                                        color: Colors.textColor,
                                                        fontFamily: Font.montserrat_Bold,
                                                        fontSize: Font.fontSize4
                                                    }}>
                                                        {item.price}
                                                    </Text>

                                                    <View style={{
                                                        height: mobileW * 10 / 100, width: mobileW * 40 / 100,
                                                        justifyContent: 'center',
                                                    }}>
                                                        <View style={{ flexDirection: 'row', alignSelf: 'flex-end', }}>
                                                            <Image
                                                                source={require('../../icons/cradit_card_icon.png')}
                                                                style={{ width: 25, height: 25 }}
                                                            />
                                                            <Text style={{
                                                                textAlign: 'right',
                                                                color: Colors.textColor,
                                                                fontFamily: Font.montserrat_Medium,
                                                                fontSize: Font.fontSize4,
                                                                paddingLeft: mobileW * 2 / 100
                                                            }}>
                                                                Paypal
                                                            </Text>
                                                        </View>
                                                    </View>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                );
                            }}
                            keyExtractor={(item, index) => index.toString()}
                        />
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
});
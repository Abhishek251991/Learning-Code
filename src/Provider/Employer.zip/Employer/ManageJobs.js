import React, { Component } from 'react'
import { Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Footer from '../../Provider/Footer';
import EmployerFooter from './EmployerFooter';

const MYLIST = [
    {
        name: 'Accounting  ', allAplicants: '25', visited: '10', subName: 'Carter', city: 'Zürich', days: '4', status: false, age: 62, phone: '0958547545', end: '5'
    },
    {
        name: 'Accounting', allAplicants: '17', visited: '08', subName: 'Christopher', city: 'Zürich', days: '14', status: true, age: 54, phone: '09585475456', end: '20'
    },
    {
        name: 'Agriculture', allAplicants: '05', visited: '1', subName: 'Julian', city: 'Lucerne', days: '9', status: false, age: 45, phone: '0958547544', end: '17'
    },
    {
        name: 'Accounting finance', allAplicants: '15', visited: '14', subName: 'Jayden', city: 'Gallen', days: '2', status: true, age: 55, phone: '0958547543', end: '9'
    },
    {
        name: 'Art', allAplicants: '25', visited: '20', subName: 'Grayson', city: 'Winterthur', days: '7', status: false, age: 22, phone: '0958547542', end: '10'
    },
    {
        name: 'Education', allAplicants: '15', visited: '10', subName: 'Lincoln', city: 'Lausanne', days: '2', status: true, age: 21, phone: '0958547545', end: '25'
    },
];

const CardBottomView = ({ title, description }) => (
    <View style={{
        paddingVertical: mobileW * 1.5 / 100,
        backgroundColor: Colors.silverLightColor,
        width: mobileW * 22 / 100,
    }}>
        <View style={{
            alignSelf: 'center',
        }}>
            <Text style={{
                paddingVertical: mobileW * 0.5 / 100,
                textAlign: 'center',
                color: Colors.textColor,
                fontFamily: Font.montserrat_Medium,
                fontSize: Font.fontSize2half
            }}>{title}</Text>
            <Text style={{
                color: Colors.textColor,
                fontFamily: Font.montserrat_Regular,
                fontSize: Font.fontSize2half
            }}>{description}</Text>
        </View>
    </View>
);

const CustomCardRow = ({ image, title, color }) => (
    <View style={{
        flexDirection: 'row',
        marginTop: mobileW * 2 / 100
    }}>
        <Image source={image}
            resizeMode={'contain'}
            style={{
                width: mobileW * 5.5 / 100,
                height: mobileW * 5.5 / 100
            }}
        ></Image>
        <Text style={{
            paddingVertical: mobileW * 1 / 100,
            paddingLeft: mobileW * 3 / 100,
            fontFamily: Font.montserrat_Regular,
            fontSize: Font.fontSize3,
            color: color
        }}>{title}</Text>
    </View>
);

const CustomCardCheckBoxRow = ({ iconName, title }) => (
    <View style={{
        flexDirection: 'row',
        marginTop: mobileW * 2 / 100
    }}>
        <MaterialCommunityIcons name={iconName} size={30} color={Colors.darkGreenColor} />
        <Text style={{
            paddingVertical: mobileW * 1 / 100,
            paddingLeft: mobileW * 3 / 100,
            fontFamily: Font.montserrat_Regular,
            fontSize: Font.fontSize4,
            color: Colors.textColor
        }}>{title}</Text>
    </View>
);

const ApprovedFixedButtom = ({ title }) => (
    <View style={{
        marginTop: mobileW * 2.5 / 100,
        width: mobileW * 20 / 100,
        justifyContent: 'center',
        backgroundColor: Colors.lightGreenColor,
    }}>
        <Text style={{
            paddingVertical: mobileW * 1 / 100,
            textAlign: 'center',
            fontSize: Font.fontSize3,
            color: Colors.whiteColor,
            fontFamily: Font.montserrat_Bold,
        }}>{title}</Text>
    </View>
);

const ManageJobCardIconButton = ({ onPress, imageName }) => (
    <TouchableOpacity activeOpacity={.7} onPress={onPress}>
        <View style={{ paddingVertical: mobileW * 2 / 100 }}>
            <Image source={imageName}
                resizeMode={'contain'}
                style={{
                    width: mobileW * 6 / 100,
                    height: mobileW * 6 / 100
                }} />
        </View>
    </TouchableOpacity>
);

export default class EmployerManageJobsScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            savedCandidateArray: MYLIST,
            usertype: localStorage.getItemString('userType')
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />
                        {/* App Bar Start  */}
                        <View style={styles.appBarStyle}>
                            <TouchableOpacity style={styles.leadingContainerStyle} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={styles.leadingIcon}>
                                </Image>
                            </TouchableOpacity>
                            <View style={styles.centerContainerStyle}>
                                <Text style={styles.centerTitleText}>Manage Jobs</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={styles.actionContainerStyle}>
                                <Image source={localImage.searchIcon}
                                    style={styles.actionButtons}>
                                </Image>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <View style={styles.screenBody}>
                            <FlatList
                                style={{ width: mobileW * 95 / 100, alignSelf: 'center', marginBottom: mobileW * 3 / 100 }}
                                data={this.state.savedCandidateArray}
                                renderItem={({ item, index }) =>

                                    <View style={styles.cardShadowView}>
                                        <View style={{ flexDirection: 'row' }}>
                                            <View style={{
                                                padding: mobileW * 3 / 100,
                                                width: mobileW * 75 / 100,
                                            }}>
                                                <Text style={{
                                                    fontSize: Font.fontSize4,
                                                    color: Colors.textColor,
                                                    fontFamily: Font.montserrat_Bold,
                                                }}>
                                                    Donation Collector For {item.name}
                                                    <Text style={{
                                                        fontSize: Font.fontSize3half,
                                                        color: Colors.lightGreenColor,
                                                        fontFamily: Font.montserrat_Bold,
                                                    }}>(Filled)</Text>
                                                </Text>
                                                <ApprovedFixedButtom title="Approved" />
                                                <CustomCardRow color={Colors.textColor} title="Accounting / Finance" image={localImage.bagIcon} />
                                                <CustomCardRow color={Colors.textColor} title={item.city + " , Switzerland"} image={localImage.locationImage} />
                                                <CustomCardRow color={Colors.textColor} title={'Created December ' + item.days + ' , 2017'} image={localImage.clockIcon} />
                                                <CustomCardRow color={Colors.textColor} title={'Deadline October ' + item.end + ' ,2021'} image={localImage.clockIcon} />
                                                <CustomCardRow color={Colors.lightGreenColor} title={item.days + " Applications(s)"} image={localImage.myListButtonIcon} />
                                                <CustomCardRow color={Colors.textColor} title={"Views(s) " + item.days} image={localImage.eyeIconBlue} />
                                                <CustomCardCheckBoxRow title="Fill Job" iconName='check-box-outline' />
                                                <CustomCardCheckBoxRow title="Featured Job" iconName='check-box-outline' />
                                            </View>
                                            <View style={{
                                                width: mobileW * 15 / 100,
                                                paddingVertical: mobileW * 2 / 100,
                                                alignItems: 'center'
                                            }}>
                                                <ManageJobCardIconButton imageName={localImage.eyeOpenImage} onPress={() => {
                                                    console.log('Eye Icon')
                                                }} />
                                                <ManageJobCardIconButton imageName={localImage.editImage} onPress={() => {
                                                    console.log('Edit Icon')
                                                }} />
                                                <ManageJobCardIconButton imageName={localImage.copyIcon} onPress={() => {
                                                    console.log('Copy Icon')
                                                }} />
                                                <ManageJobCardIconButton imageName={localImage.deleteImage} onPress={() => {
                                                    console.log('Delete Icon')
                                                }} />
                                            </View>
                                        </View>
                                        <View style={{
                                            flexDirection: 'row',
                                            justifyContent: 'space-between',
                                        }}>
                                            <CardBottomView title={item.allAplicants} description="All Applicants" />
                                            <CardBottomView title={item.visited} description="Total Visits" />
                                            <CardBottomView title={'Oct ' + item.end + ' , 2021'} description="Expiry Date" />
                                            <CardBottomView title="0" description="Insta Match" />
                                        </View>
                                    </View>
                                }
                                keyExtractor={(item, index) => index.toString()}
                            >
                            </FlatList>
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    appBarStyle: {
        flexDirection: 'row',
        width: '100%',
        paddingHorizontal: 10,
        alignItems: 'center',
        backgroundColor: Colors.whiteColor,
        height: mobileH * 8 / 100,
    },
    leadingContainerStyle: {
        width: '15%',
    },
    leadingIcon: {
        marginLeft: mobileW * 3 / 100,
        width: mobileW * 7 / 100,
        height: mobileW * 7 / 100,
        resizeMode: 'contain'
    },
    centerContainerStyle: {
        width: '70%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    centerTitleText: {
        width: '100%',
        fontSize: Font.fontSize5,
        color: Colors.textColor,
        fontFamily: Font.montserrat_Bold,
        textAlign: 'center'
    },
    actionContainerStyle: {
        width: '15%'
    },
    actionButtons: {
        alignSelf: 'center',
        width: mobileW * 7.5 / 100,
        height: mobileW * 7.5 / 100,
        resizeMode: 'contain'
    },
    screenBody: {
        width: mobileW * 100 / 100,
        alignSelf: 'center',
    },
    cardShadowView: {
        width: mobileW * 90 / 100,
        marginBottom: 1,
        marginTop: mobileW * 4 / 100,
        alignSelf: 'center',
        backgroundColor: Colors.whiteColor,
        shadowColor: '#000',
        shadowOffset: {
            width: 2,
            height: 2,
        },
        shadowOpacity: 0.5,
        shadowRadius: 0.5,
        elevation: 2,
    }
});
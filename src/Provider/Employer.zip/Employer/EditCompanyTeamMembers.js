import React, { Component } from 'react';
import { Keyboard, Image, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View, } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mediaprovider, msgProvider, mobileH, msgText, Cameragallery, config, localStorage, Colors, Font, localImage } from '../../Provider/utilslib/Utils';
import Footer from '../../Provider/Footer';
import { ImageBackground } from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import EmployerFooter from './EmployerFooter';

const InputLabel = ({ inputLabel }) => (
    <View style={styles.labelStyle}>
        <Text style={styles.textFieldLabel}>
            {inputLabel}
        </Text>
    </View>
);

const AppButton = ({ onPress, title, color, backgroundColor }) => (
    <TouchableOpacity
        style={[styles.loginButton, { backgroundColor: backgroundColor }]}
        activeOpacity={.7}
        onPress={onPress}
    >
        <Text style={{
            fontSize: Font.fontSize4,
            color: color,
            textTransform: 'uppercase',
            fontFamily: Font.montserrat_Bold
        }}>{title}</Text>
    </TouchableOpacity>
);

const UploadPhotoButton = ({ onPress, title, color, backgroundColor, borderColor }) => (
    <TouchableOpacity
        style={{
            marginTop: mobileW * 2.5 / 100,
            width: mobileW * 35 / 100, alignItems: 'center',
            borderColor: borderColor, borderWidth: 1.5,
            backgroundColor: backgroundColor, borderRadius: mobileW * 10 / 100
        }}
        activeOpacity={.7}
        onPress={onPress}
    >
        <Text style={{
            fontSize: Font.fontSize4,
            color: color,
            paddingVertical: mobileW * 2 / 100,
            fontFamily: Font.montserrat_Medium
        }}>{title}</Text>
    </TouchableOpacity>
);
export default class EditCompanyTeamMembersScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            memberTitle: '',
            designation: '',
            experience: '',
            facebookUrl: '',
            googleUrl: '',
            twitterUrl: '',
            linkedInUrl: '',
            description: '',
            profile_image: localImage.placeHolderImage,
            mediamodal: false,
            cameraon: false
        }
    }
    _openCamera = () => {
        mediaprovider.launchCamera().then((obj) => {
            console.log(obj.path);
            this.setState({
                profile_image: obj.path,
                mediamodal: false,
                cameraon: true,
            })
        })
    }
    _openGellery = () => {
        mediaprovider.launchGellery().then((obj) => {
            console.log(obj.path);
            this.setState({
                profile_image: obj.path,
                mediamodal: false,
                cameraon: true,
            })
        })
    }
    addTeamMemberApiCall() {
        Keyboard.dismiss()
        // --------------- Get Values into variables -----------------------
        let memberTitle = this.state.memberTitle.trim();
        let designation = this.state.designation.trim();
        let experience = this.state.experience.trim();
        let facebookUrl = this.state.facebookUrl.trim();
        let googleUrl = this.state.googleUrl.trim();
        let twitterUrl = this.state.twitterUrl.trim();
        let linkedInUrl = this.state.linkedInUrl.trim();
        let description = this.state.description.trim();

        if (memberTitle.length <= 0) {
            msgProvider.toast(msgText.memberTitleEmpty[config.language], 'center')
            return false;
        }
        if (designation.length <= 0) {
            msgProvider.toast(msgText.designationEmpty[config.language], 'center')
            return false;
        }
        if (experience.length <= 0) {
            msgProvider.toast(msgText.experienceEmpty[config.language], 'center')
            return false;
        }
        if (facebookUrl.length <= 0) {
            msgProvider.toast(msgText.facebookEmptyMsg[config.language], 'center')
            return false;
        }
        if (googleUrl.length <= 0) {
            msgProvider.toast(msgText.googleUrlEmpty[config.language], 'center')
            return false;
        }
        if (twitterUrl.length <= 0) {
            msgProvider.toast(msgText.twitterEmptyMsg[config.language], 'center')
            return false;
        }
        if (linkedInUrl.length <= 0) {
            msgProvider.toast(msgText.linkedInEmptyMsg[config.language], 'center')
            return false;
        }
        if (description.length <= 0) {
            msgProvider.toast(msgText.descriptionEmpty[config.language], 'center')
            return false;
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />
                        <Cameragallery mediamodal={this.state.mediamodal} Camerapopen={() => { this._openCamera() }}
                            Galleryopen={() => { this._openGellery() }} Canclemedia={() => { this.setState({ mediamodal: false }) }}
                        />
                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize4, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Edit Team Members</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={{ width: '78%' }}>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <View style={styles.addCompanyBody}>
                            <View style={styles.containerStyle}>
                                <InputLabel inputLabel={'Member Title'} />
                                <TextInput
                                    keyboardType='default'
                                    // placeholder={'Member Title'}
                                    placeholderTextColor={Colors.textColor}
                                    selectionColor={Colors.textColor}
                                    maxLength={50}
                                    onChangeText={(input) => this.setState({ memberTitle: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                    style={styles.inputStyle}
                                ></TextInput>
                            </View>
                            <View style={styles.containerStyle}>
                                <InputLabel inputLabel={'Designation'} />
                                <TextInput
                                    keyboardType='default'
                                    // placeholder={'Designation'}
                                    placeholderTextColor={Colors.textColor}
                                    selectionColor={Colors.textColor}
                                    maxLength={50}
                                    onChangeText={(input) => this.setState({ designation: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                    style={styles.inputStyle}
                                ></TextInput>
                            </View>
                            <View style={styles.containerStyle}>
                                <InputLabel inputLabel={'Experience'} />
                                <TextInput
                                    keyboardType='default'
                                    // placeholder={'Experience'}
                                    placeholderTextColor={Colors.textColor}
                                    selectionColor={Colors.textColor}
                                    maxLength={50}
                                    onChangeText={(input) => this.setState({ experience: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                    style={styles.inputStyle}
                                ></TextInput>
                            </View>
                            <View style={{ marginTop: mobileW * 2 / 100 }}>
                                <Text style={{
                                    fontSize: Font.fontSize4,
                                    color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold,
                                }}>
                                    Image
                                </Text>
                            </View>
                            <View>
                                {
                                    this.state.profile_image == "NA" &&
                                    <UploadPhotoButton
                                        title={'+ Upload Photo'}
                                        color={Colors.greyColor}
                                        borderColor={Colors.darkGreenColor}
                                        onPress={() => { this.setState({ mediamodal: true }) }}
                                        backgroundColor={Colors.whiteColor}
                                    />
                                }
                                {
                                    this.state.profile_image != "NA" &&
                                    <View>
                                        <ImageBackground
                                            style={{ height: mobileW * 20 / 100, width: mobileW * 30 / 100, resizeMode: 'contain' }}

                                            source={this.state.cameraon ? { uri: this.state.profile_image } : localImage.userPlaceholderIcon}
                                            resizeMode={'contain'}
                                        >
                                            <TouchableOpacity onPress={() => {
                                                this.setState({ profile_image: 'NA' })
                                            }} activeOpacity={.7}>
                                                <Entypo name='circle-with-cross' style={{ alignSelf: 'flex-end' }} size={30} color={Colors.lightRedColor} />
                                            </TouchableOpacity>
                                        </ImageBackground>
                                    </View>
                                }
                            </View>
                            <View style={styles.containerStyle}>
                                <InputLabel inputLabel={'Facebook URL'} />
                                <TextInput
                                    keyboardType='default'
                                    // placeholder={'Facebook URL'}
                                    placeholderTextColor={Colors.textColor}
                                    selectionColor={Colors.textColor}
                                    maxLength={50}
                                    onChangeText={(input) => this.setState({ facebookUrl: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                    style={styles.inputStyle}
                                ></TextInput>
                            </View>
                            <View style={styles.containerStyle}>
                                <InputLabel inputLabel={'Google + URL'} />
                                <TextInput
                                    keyboardType='default'
                                    // placeholder={'Google + URL'}
                                    placeholderTextColor={Colors.textColor}
                                    selectionColor={Colors.textColor}
                                    maxLength={50}
                                    onChangeText={(input) => this.setState({ googleUrl: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                    style={styles.inputStyle}
                                ></TextInput>
                            </View>
                            <View style={styles.containerStyle}>
                                <InputLabel inputLabel={'Twitter URL'} />
                                <TextInput
                                    keyboardType='default'
                                    // placeholder={'Twitter URL'}
                                    placeholderTextColor={Colors.textColor}
                                    selectionColor={Colors.textColor}
                                    maxLength={50}
                                    onChangeText={(input) => this.setState({ twitterUrl: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                    style={styles.inputStyle}
                                ></TextInput>
                            </View>
                            <View style={styles.containerStyle}>
                                <InputLabel inputLabel={'LinkedIn URL'} />
                                <TextInput
                                    keyboardType='default'
                                    // placeholder={'LinkedIn URL'}
                                    placeholderTextColor={Colors.textColor}
                                    selectionColor={Colors.textColor}
                                    maxLength={50}
                                    onChangeText={(input) => this.setState({ linkedInUrl: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                    style={styles.inputStyle}
                                ></TextInput>
                            </View>
                            <View style={styles.containerStyle}>
                                <InputLabel inputLabel={'Description'} />
                                <TextInput
                                    keyboardType='default'
                                    value={this.state.discription}
                                    // placeholder={'Description'}
                                    placeholderTextColor={Colors.textColor}
                                    selectionColor={Colors.textColor}
                                    multiline={true}
                                    onChangeText={(input) => this.setState({ description: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                    style={{
                                        textAlignVertical: 'top',
                                        color: Colors.textColor,
                                        alignSelf: 'center',
                                        borderColor: Colors.greyColor,
                                        borderWidth: 0.7,
                                        width: mobileW * 90 / 100,
                                        height: mobileW * 30 / 100,
                                        paddingLeft: 18,
                                        fontSize: Font.fontSize4,
                                        fontFamily: Font.montserrat_Regular
                                    }}
                                ></TextInput>
                            </View>
                            <View style={{ marginTop: mobileW * 15 / 100, marginBottom: mobileW * 20 / 100 }}>
                                <AppButton
                                    onPress={() => { this.addTeamMemberApiCall() }}
                                    title={'submit'}
                                    color={Colors.whiteColor}
                                    backgroundColor={Colors.darkGreenColor}
                                ></AppButton>
                            </View>

                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    addCompanyBody: {
        alignSelf: 'center',
        width: mobileW * 90 / 100
    },
    inputStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        paddingVertical: mobileW * 3.5 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    containerStyle: {
        width: '100%',
        marginTop: mobileW * 3 / 100,
        marginBottom: mobileW * 1 / 100,
    },
    labelStyle: {
        width: mobileW * 82 / 100, alignSelf: 'center'
    },
    textFieldLabel: {
        marginBottom: mobileW * 2 / 100,
        color: Colors.greyColor,
        fontSize: Font.fontSize3half,
        fontFamily: Font.montserrat_Regular
    },
    loginButton: {
        height: mobileW * 16 / 100,
        justifyContent: 'center',
        alignItems: 'center'
    },
});
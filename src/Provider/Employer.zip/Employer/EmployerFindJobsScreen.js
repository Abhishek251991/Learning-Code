import React, { Component } from 'react'
import { FlatList, Image, Modal, Text, TouchableOpacity } from 'react-native';
import { SafeAreaView, ScrollView, StatusBar, StyleSheet, View } from 'react-native'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Ionicons from 'react-native-vector-icons/Ionicons'
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
import { Colors, commonStyle, Font, mobileH, mobileW, localStorage, } from '../../Provider/utilslib/Utils'

const DATA = [
    {
        name: 'Accounting finance ', subName: 'Carter', city: 'Zürich', days: '4', status: false
    },
    {
        name: 'Accounting', subName: 'Christopher', city: 'Zürich', days: '14', status: true
    },
    {
        name: 'Agriculture', subName: 'Julian', city: 'Lucerne', days: '9', status: false
    },
    {
        name: 'Accounting finance', subName: 'Jayden', city: 'Gallen', days: '2', status: false
    },
    {
        name: 'Art', subName: 'Grayson', city: 'Winterthur', days: '7', status: false
    },
    {
        name: 'Education', subName: 'Lincoln', city: 'Lausanne', days: '2', status: false
    },
    {
        name: 'School', subName: 'Ezra', city: 'Basel', days: '1', status: false
    },
    {
        name: 'Hospital', subName: 'Thomas', city: 'Bienne', days: '6', status: false
    },
    {
        name: 'Medical', subName: 'Anthony', city: 'Lugano', days: '7', status: false
    },
    {
        name: 'Freelance', subName: 'Hudson', city: 'Bern', days: '5', status: false
    },
];

export default class EmployerFindJobsScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data_arr: DATA,
            isVisible: false,
            isOpenPostDateVisiable: false,
            selectDatePosted: 'Select',
            usertype: localStorage.getItemString('userType')
        }
    }

    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />
                        <Modal
                            animationType={'slide'}
                            transparent={true}
                            backgroundColor={'red'}
                            visible={this.state.isVisible}
                            onRequestClose={() => { console.log("Modal has been closed.") }}>
                            <View style={{
                                marginTop: 'auto',
                                height: '50%',
                                width: mobileW * 100 / 100,
                                backgroundColor: Colors.whiteColor,
                                shadowColor: '#000',
                                shadowOffset: {
                                    width: 0,
                                    height: 2,
                                },
                                shadowOpacity: 5,
                                shadowRadius: 5,
                                elevation: 22,
                            }}>
                                <TouchableOpacity activeOpacity={.7} onPress={() => {
                                    this.setState({ isVisible: false })
                                }}>
                                    <View
                                        style={{
                                            height: mobileW * 5 / 100,
                                        }}
                                    />
                                    <View style={{
                                        width: mobileW * 15 / 100,
                                        borderBottomColor: Colors.darkGreenColor,
                                        borderRadius: 6,
                                        alignSelf: 'center',
                                        borderBottomWidth: 6
                                    }}>
                                    </View>
                                </TouchableOpacity>

                                <View style={{
                                    width: mobileW * 90 / 100,
                                    height: mobileW * 10 / 100,
                                    justifyContent: 'center',
                                    alignSelf: 'center',
                                }}>
                                    <View>
                                        <Text style={{
                                            fontSize: Font.fontSize4,
                                            color: Colors.textColor,
                                            fontStyle: Font.montserrat_Bold
                                        }}>
                                            Locations
                                        </Text>
                                    </View>
                                </View>
                                <View style={{ width: '100%', marginBottom: mobileW * 3 / 100, }}>
                                    <View style={{
                                        color: Colors.textColor,
                                        alignSelf: 'center',
                                        borderColor: Colors.greyColor,
                                        borderWidth: 0.7,
                                        width: mobileW * 90 / 100,
                                        paddingVertical: mobileW * 4 / 100,
                                        paddingHorizontal: 18,
                                        fontSize: Font.fontSize4,
                                        fontFamily: Font.montserrat_Regular,
                                        flexDirection: 'row',
                                        justifyContent: 'space-between'
                                    }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular,
                                            paddingVertical: mobileW * 1 / 100,
                                        }}>
                                            Select
                                        </Text>
                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                        </View>
                                    </View>
                                </View>
                                <View style={{
                                    width: mobileW * 90 / 100,
                                    height: mobileW * 10 / 100,
                                    justifyContent: 'center',
                                    alignSelf: 'center',
                                }}>
                                    <View>
                                        <Text style={{
                                            fontSize: Font.fontSize4,
                                            color: Colors.textColor,
                                            fontStyle: Font.montserrat_Bold
                                        }}>
                                            Date Posted
                                        </Text>
                                    </View>
                                </View>
                                <TouchableOpacity onPress={() => {
                                    this.setState({ isOpenPostDateVisiable: !this.state.isOpenPostDateVisiable })
                                }} activeOpacity={.7}>

                                    <View style={{ width: '100%', }}>
                                        <View style={{
                                            color: Colors.textColor,
                                            alignSelf: 'center',
                                            borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                            borderWidth: 0.7,
                                            width: mobileW * 90 / 100,
                                            paddingVertical: mobileW * 4 / 100,
                                            paddingHorizontal: 18,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular,
                                            flexDirection: 'row',
                                            justifyContent: 'space-between'
                                        }}>
                                            <Text style={{
                                                color: Colors.textColor,
                                                fontSize: Font.fontSize4,
                                                paddingVertical: mobileW * 1 / 100,
                                                fontFamily: Font.montserrat_Regular
                                            }}>
                                                {this.state.selectDatePosted}
                                            </Text>
                                            <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                            </View>
                                        </View>
                                    </View>
                                </TouchableOpacity>
                                {
                                    this.state.isOpenPostDateVisiable == true &&
                                    <View style={{ width: '100%', }}>
                                        <View style={{
                                            color: Colors.textColor,
                                            alignSelf: 'center',
                                            borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                            borderWidth: 0.7,
                                            borderTopColor: Colors.whiteColor,
                                            width: mobileW * 90 / 100,
                                            height: mobileW * 26 / 100,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular,
                                        }}>

                                            <TouchableOpacity activeOpacity={.7} onPress={() => {
                                                this.setState({ selectDatePosted: 'Last Hour' })
                                                this.setState({ isOpenPostDateVisiable: false })
                                            }}>
                                                <View style={{
                                                    width: '100%', height: mobileW * 12 / 100,
                                                    backgroundColor: Colors.extraLightGreenColor,
                                                    justifyContent: 'center',
                                                }}>
                                                    <Text style={{
                                                        fontSize: Font.fontSize3half,
                                                        color: Colors.textColor,
                                                        paddingLeft: 20,
                                                        fontFamily: Font.montserrat_Regular
                                                    }}>
                                                        Last Hour
                                                    </Text>
                                                </View>

                                            </TouchableOpacity>

                                            <TouchableOpacity activeOpacity={.7} onPress={() => {
                                                this.setState({ selectDatePosted: 'Last 24 Hour' })
                                                this.setState({ isOpenPostDateVisiable: false })
                                            }}>
                                                <View style={{
                                                    width: '100%', height: mobileW * 12 / 100,
                                                    justifyContent: 'center',
                                                }}>
                                                    <Text style={{
                                                        fontSize: Font.fontSize3half,
                                                        color: Colors.textColor,
                                                        paddingLeft: 20,
                                                        fontFamily: Font.montserrat_Regular
                                                    }}>
                                                        Last 24 Hour
                                                    </Text>
                                                </View>
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                                }


                                <View style={{
                                    width: mobileW * 90 / 100,
                                    height: mobileW * 10 / 100,
                                    justifyContent: 'center',
                                    alignSelf: 'center',
                                }}>
                                    <View>
                                        <Text style={{
                                            fontSize: Font.fontSize4,
                                            color: Colors.textColor,
                                            fontStyle: Font.montserrat_Bold
                                        }}>
                                            Sector
                                        </Text>
                                    </View>
                                </View>


                                <View style={{ width: '100%', marginBottom: mobileW * 3 / 100, }}>
                                    <View style={{
                                        color: Colors.textColor,
                                        alignSelf: 'center',
                                        borderColor: Colors.greyColor,
                                        borderWidth: 0.7,
                                        width: mobileW * 90 / 100,
                                        paddingVertical: mobileW * 4 / 100,
                                        paddingHorizontal: 18,
                                        fontSize: Font.fontSize4,
                                        fontFamily: Font.montserrat_Regular,
                                        flexDirection: 'row',
                                        justifyContent: 'space-between'
                                    }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            paddingVertical: mobileW * 1 / 100,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            Select
                                        </Text>
                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                        </View>
                                    </View>

                                </View>


                            </View>
                            {/* </TouchableOpacity> */}

                        </Modal>



                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', backgroundColor: Colors.whiteColor,
                            height: mobileH * 10 / 100,
                        }}>
                            <TouchableOpacity style={{ width: '14%', }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={require('../../icons/back_icon.png')}
                                    style={{ alignSelf: 'center', width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '70%', justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Find Jobs</Text>
                            </View>
                            <TouchableOpacity onPress={() => {
                                this.setState({ isVisible: !this.state.isVisible })
                            }} style={{ width: '15%', }}>
                                <Image source={require('../../icons/option_icon.png')}
                                    style={{

                                        alignSelf: 'center', width: mobileW * 10 / 100,
                                        height: mobileW * 10 / 100, resizeMode: 'contain'
                                    }}>
                                </Image>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}

                        <View style={{
                            width: mobileW * 90 / 100, alignSelf: 'center', marginTop:
                                mobileW * 1.5 / 100
                        }}>

                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>

                                <View style={{
                                    backgroundColor: Colors.silverLightColor,
                                    width: mobileW * 42 / 100, height: mobileW * 13 / 100,
                                    flexDirection: 'row',
                                    justifyContent: 'space-around',
                                    alignItems: 'center'
                                }}>
                                    <View style={{
                                        backgroundColor: Colors.extraLightGreenColor,
                                        width: 28, height: 28,
                                        justifyContent: 'center',
                                        alignItems: 'center'
                                    }}>
                                        <Ionicons name='ios-swap-vertical-sharp' size={18} color={Colors.darkGreenColor} />
                                    </View>

                                    <Text style={{ color: Colors.textColorLight, fontFamily: Font.montserrat_Regular }}>
                                        Most Recent
                                    </Text>
                                    <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                </View>

                                <View style={{
                                    backgroundColor: Colors.silverLightColor,
                                    width: mobileW * 42 / 100, height: mobileW * 13 / 100,
                                    flexDirection: 'row',
                                    justifyContent: 'space-around',
                                    alignItems: 'center'
                                }}>
                                    <Text style={{ color: Colors.textColorLight, fontFamily: Font.montserrat_Regular }}>
                                        Records Per Page
                                    </Text>
                                    <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                </View>
                            </View>


                            <View style={{ marginTop: mobileW * 2 / 100 }}>
                                <Text style={{
                                    fontSize: Font.fontSize3half, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold
                                }}>
                                    Showing 1 - 10 of 18 results
                                </Text>
                            </View>


                            {/* Job modal list  */}
                            <View style={{ width: mobileW * 91 / 100, marginBottom: mobileW * 17 / 100 }}>
                                <FlatList
                                    data={this.state.data_arr}
                                    renderItem={({ item, index }) =>
                                        <TouchableOpacity activeOpacity={.7} onPress={() => {
                                            this.props.navigation.navigate('EmployerFindJobDetail');
                                        }}>
                                            <View style={{
                                                height: mobileW * 45 / 100,
                                                width: mobileW * 90 / 100,
                                                marginBottom: 1,
                                                marginTop: mobileW * 4 / 100,
                                                alignSelf: 'center',
                                                backgroundColor: Colors.whiteColor,
                                                shadowColor: '#000',
                                                shadowOffset: {
                                                    width: 2,
                                                    height: 2,
                                                },
                                                shadowOpacity: 0.5,
                                                shadowRadius: 0.5,
                                                elevation: 2,
                                            }}>
                                                <View style={{ flexDirection: 'row' }}>

                                                    <View style={{
                                                        width: mobileW * 30 / 100,
                                                        height: mobileW * 45 / 100,
                                                    }}>
                                                        <View style={{
                                                            marginTop: mobileW * 3 / 100,
                                                            height: mobileW * 22 / 100,
                                                            justifyContent: 'center',
                                                            alignItems: 'center',
                                                        }}>
                                                            <Image
                                                                resizeMode={'cover'}
                                                                style={{
                                                                    width: mobileW * 22 / 100,
                                                                    height: mobileW * 18 / 100,
                                                                }} source={require('../../icons/placeholder.png')} />

                                                        </View>
                                                        <View style={{
                                                            width: mobileW * 30 / 100,
                                                            justifyContent: 'center',
                                                            alignItems: 'center',
                                                            height: mobileW * 6 / 100,
                                                        }}>
                                                            <View style={{
                                                                width: mobileW * 22 / 100,
                                                                height: mobileW * 6 / 100,
                                                                justifyContent: 'center',
                                                                alignItems: 'center',
                                                                backgroundColor: 'rgb(214,181,72)'
                                                            }}>
                                                                <Text numberOfLines={1}
                                                                    style={{
                                                                        textTransform: 'uppercase',
                                                                        color: Colors.whiteColor,
                                                                        fontFamily: Font.montserrat_Medium,
                                                                        fontSize: Font.fontSize3
                                                                    }}>
                                                                    part time
                                                                </Text>
                                                            </View>
                                                        </View>
                                                    </View>
                                                    <View style={{
                                                        width: mobileW * 60 / 100,
                                                        height: mobileW * 45 / 100,
                                                    }}>
                                                        <View style={{ flexDirection: 'row' }}>
                                                            <View style={{
                                                                width: mobileW * 48 / 100,
                                                                height: mobileW * 26 / 100,
                                                                justifyContent: 'center',
                                                            }}>
                                                                <View style={{
                                                                    width: mobileW * 48 / 100,
                                                                    height: mobileW * 20 / 100,
                                                                    justifyContent: 'center',
                                                                }}>
                                                                    <Text numberOfLines={2} style={{
                                                                        fontSize: Font.fontSize4,
                                                                        color: Colors.textColor,
                                                                        fontFamily: Font.montserrat_Bold
                                                                    }}>
                                                                        Marketing Expert For {item.name}
                                                                    </Text>
                                                                    <Text style={{
                                                                        color: Colors.lightGreenColor,
                                                                        fontSize: Font.fontSize4
                                                                    }}>
                                                                        @{item.subName}
                                                                    </Text>
                                                                </View>
                                                            </View>

                                                            <View style={{
                                                                width: mobileW * 8 / 100,
                                                                height: mobileW * 17 / 100,
                                                                justifyContent: 'center',
                                                                alignItems: 'center',
                                                            }}>
                                                                <TouchableOpacity activeOpacity={.7} onPress={() => { }}>
                                                                    <View style={{

                                                                        backgroundColor: item.status ? Colors.darkGreenColor : Colors.extraLightGreenColor,
                                                                        width: mobileW * 8 / 100,
                                                                        height: mobileW * 8 / 100,
                                                                        justifyContent: 'center',
                                                                        alignItems: 'center',
                                                                    }}>
                                                                        <MaterialCommunityIcons name='heart-outline'
                                                                            size={30} color={item.status ? Colors.whiteColor : Colors.darkGreenColor} />
                                                                    </View>
                                                                </TouchableOpacity>
                                                            </View>
                                                        </View>
                                                        <View style={{
                                                            width: mobileW * 55 / 100,
                                                            height: mobileW * 6 / 100,

                                                            flexDirection: 'row'
                                                        }}>
                                                            <Image
                                                                style={{
                                                                    width: 25,
                                                                    height: 20,
                                                                }}
                                                                resizeMode={'contain'}
                                                                source={require('../../icons/bag_icon.png')} />
                                                            <Text numberOfLines={1} style={{
                                                                paddingLeft: 10, fontSize: Font.fontSize3,
                                                                fontFamily: Font.montserrat_Regular,
                                                                color: Colors.textColorLight,
                                                                marginRight: mobileW * 10 / 100,
                                                            }}>{item.name}</Text>
                                                        </View>

                                                        <View style={{
                                                            width: mobileW * 55 / 100,
                                                            height: mobileW * 6 / 100,
                                                            flexDirection: 'row',
                                                        }}>
                                                            <Image
                                                                style={{
                                                                    width: 25,
                                                                    height: 20,
                                                                }}
                                                                resizeMode={'contain'}
                                                                source={require('../../icons/location_icon.png')} />
                                                            <Text numberOfLines={1} style={{
                                                                marginRight: mobileW * 10 / 100,
                                                                paddingLeft: 10, fontSize: Font.fontSize3,
                                                                fontFamily: Font.montserrat_Regular,
                                                                color: Colors.textColorLight
                                                            }}>Regent St, Carnaby,{item.city}</Text>
                                                        </View>

                                                        <View style={{
                                                            width: mobileW * 55 / 100,
                                                            height: mobileW * 6 / 100,

                                                            flexDirection: 'row'
                                                        }}>
                                                            <Image
                                                                style={{
                                                                    width: 25,
                                                                    height: 20,
                                                                }}
                                                                resizeMode={'contain'}
                                                                source={require('../../icons/clock_icon.png')} />
                                                            <Text numberOfLines={1} style={{
                                                                marginRight: mobileW * 10 / 100,
                                                                paddingLeft: 10, fontSize: Font.fontSize3,
                                                                fontFamily: Font.montserrat_Regular,
                                                                color: Colors.textColorLight
                                                            }}>Published {item.days} days ago</Text>
                                                        </View>
                                                    </View>
                                                </View>
                                            </View>
                                        </TouchableOpacity>
                                    }
                                >
                                </FlatList>
                            </View>
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
});

import React, { Component } from 'react'
import { FlatList, TextInput, Image, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mobileH, Colors, localImage, localStorage, Font } from '../../Provider/utilslib/Utils';
import Fontisto from 'react-native-vector-icons/Fontisto';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Footer from '../../Provider/Footer';

export default class CandidateFilterScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            keywordFilter: '',
            locationFilter: '',
            usertype: localStorage.getItemString('userType')
        }
    }

    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={styles.appBarStyle}>
                            <TouchableOpacity style={styles.leadingContainerStyle} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={styles.leadingIcon}>
                                </Image>
                            </TouchableOpacity>
                            <View style={styles.centerContainerStyle}>
                                <Text style={styles.centerTitleText}>Filter</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={styles.actionContainerStyle}>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <View style={styles.screenBody}>
                            <View style={styles.containerStyle}>
                                <TextInput
                                    keyboardType='default'
                                    placeholder={'Title, Keywords, or Pharases '}
                                    placeholderTextColor={Colors.textColor}
                                    selectionColor={Colors.textColor}
                                    maxLength={50} F
                                    onChangeText={(input) => this.setState({ keywordFilter: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                    style={styles.inputStyle}
                                ></TextInput>
                            </View>
                            <View style={styles.containerStyle}>
                                <TextInput
                                    keyboardType='default'
                                    placeholder={'City State or Zip'}
                                    placeholderTextColor={Colors.textColor}
                                    selectionColor={Colors.textColor}
                                    maxLength={50}
                                    onChangeText={(input) => this.setState({ locationFilter: input })}
                                    onSubmitEditing={() => { Keyboard.dismiss() }}
                                    style={styles.inputStyle}
                                ></TextInput>
                            </View>
                            <View style={[styles.containerStyle, { flexDirection: 'row' }]}>
                                <TouchableOpacity activeOpacity={.7} onPress={() => { }}>
                                    <View style={[styles.dropDownListStyle, { flexDirection: 'row', justifyContent: 'space-between' }]}>
                                        <Text style={{
                                            fontSize: Font.fontSize4,
                                            paddingVertical: mobileW * 1 / 100,
                                            color: Colors.textColor,
                                            fontFamily: Font.montserrat_Regular
                                        }}>Automotive</Text>
                                        <MaterialCommunityIcons name='menu-down' size={35}
                                            color={Colors.textColor} style={{ marginRight: mobileW * 2 / 100 }} />
                                    </View>
                                </TouchableOpacity>
                                <TouchableOpacity style={{
                                    width: mobileW * 15 / 100,
                                    justifyContent: 'center',
                                    paddingVertical: mobileW * 3.5 / 100,
                                    fontSize: Font.fontSize4,
                                    backgroundColor: Colors.darkGreenColor,
                                }} activeOpacity={.7} onPress={() => { }}>
                                    <Fontisto style={{
                                        alignSelf: 'center',
                                    }} name='search'
                                        color={Colors.whiteColor}
                                        size={24} />
                                </TouchableOpacity>
                            </View>
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    appBarStyle: {
        flexDirection: 'row',
        width: '100%',
        paddingHorizontal: 10,
        alignItems: 'center',
        backgroundColor: Colors.whiteColor,
        height: mobileH * 8 / 100,
    },
    leadingContainerStyle: {
        width: '15%',
    },
    leadingIcon: {
        marginLeft: mobileW * 3 / 100,
        width: mobileW * 7 / 100,
        height: mobileW * 7 / 100,
        resizeMode: 'contain'
    },
    centerContainerStyle: {
        width: '70%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    centerTitleText: {
        width: '100%',
        fontSize: Font.fontSize5,
        color: Colors.textColor,
        fontFamily: Font.montserrat_Bold,
        textAlign: 'center'
    },
    actionContainerStyle: {
        width: '15%'
    },
    actionButtons: {
        alignSelf: 'center',
        width: mobileW * 7.5 / 100,
        height: mobileW * 7.5 / 100,
        resizeMode: 'contain'
    },
    screenBody: {
        width: mobileW * 100 / 100,
        alignSelf: 'center',
    },
    inputStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        paddingVertical: mobileW * 3.5 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    dropDownListStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 75 / 100,
        paddingVertical: mobileW * 3.5 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    containerStyle: {
        alignSelf: 'center',
        width: '90%',
        marginTop: mobileW * 3 / 100,
        marginBottom: mobileW * 1 / 100,
    },
});
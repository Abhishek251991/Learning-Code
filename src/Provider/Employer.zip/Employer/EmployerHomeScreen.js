import React, { Component } from 'react'
import { BackHandler } from 'react-native';
import { Image, SafeAreaView, TouchableOpacity, StyleSheet, View, FlatList, ScrollView, StatusBar, Text, ImageBackground } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
import Footer from '../../Provider/Footer';
import { mobileW, mobileH, commonStyle, localStorage, Colors, Font, handleback } from '../../Provider/utilslib/Utils';
import EmployerFooter from './EmployerFooter';

const DATA = [
    {
        name: 'Accounting finance',
        status: true,
        city: 'Zürich',
    },
    {
        name: 'Accounting',
        status: false,
        city: 'Geneva'
    },
    {
        name: 'Agriculture',
        status: false, city: 'Basel'
    }, {
        name: 'Accounting finance',
        status: false,
        city: 'Sion'
    }, {
        name: 'Art',
        status: false,
        city: 'Schaffhausen'
    }, {
        name: 'Education',
        status: false,
        city: 'Basel'
    }, {
        name: 'Vernier',
        status: false,
        city: 'Fribourg'
    }, {
        name: 'Hospital',
        status: false,
        city: 'Basel'
    }, {
        name: 'Medical',
        status: false,
        city: 'Thun'
    }, {
        name: 'Freelance',
        status: false,
        city: 'Lucerne'
    },
];

const BolgData = [
    {
        title: 'Independent contractor',
        discription: 'An issue that arises in most companies, especially the ones that are in the gig economy, is the classification of workers. A lot of workers that fulfill gigs are often hired as independent contractors.'
        , date: 'Dec 18,2021'
    },
    {
        title: 'Labor acquisition / hiring',
        discription: 'The main ways for employers to find workers and for people to find employers are via jobs listings in newspapers (via classified advertising) and online, also called job boards. Employers and job seekers also often find each other via professional'
        , date: 'Dec 21,2021'
    },
    {
        title: 'Training and development',
        discription: 'Training and development refers to the employers effort to equip a newly hired employee with the necessary skills to perform at the job and to help the employee grow within the organization'
        , date: 'Dec 25,2021'
    },
    {
        title: 'Remuneration',
        discription: 'There are many ways that employees are paid, including by hourly wages, by piecework, by yearly salary, or by gratuities (with the latter often being combined with another form of payment). '

        , date: 'Dec 28,2021'
    }
];


export default class EmployerHomeScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data_arr: DATA,
            blog_data_arr: BolgData,
            usertype: localStorage.getItemString('userType')
        }
        this._didFocusSubscription = props.navigation.addListener('focus', payload =>
            BackHandler.addEventListener('hardwareBackPress', handleback.handleBackPress)
        );
    }

    componentDidMount() {
        this._willBlurSubscription = this.props.navigation.addListener('blur', payload =>
            BackHandler.removeEventListener('hardwareBackPress', handleback.handleBackPress)
        );
    }


    callFuntion = (index) => {
        let data = this.state.data_arr;
        for (let i = 0; i < data.length; i++)
            data[i].status = false;
        data[index].status = true;
        this.setState({ data_arr: data });
    }

    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}

                        {/* App Bar End  */}
                        <View style={{
                            backgroundColor: 'white', width: '100%', height: mobileH * 57 / 100,
                        }}>
                            <View style={{
                                width: '100%', height: mobileH * 55 / 100,
                            }}>
                                <ImageBackground resizeMode={'stretch'} style={{
                                    height: mobileH * 50 / 100
                                }}
                                    source={require('../../icons/employer_home_icon.png')}>
                                    <View style={{
                                        flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                                        alignItems: 'center', height: mobileH * 8 / 100,
                                    }}>
                                        <TouchableOpacity style={{ width: '15%', }} onPress={() => { this.props.navigation.openDrawer() }}>
                                            <Image source={require('../../icons/drower_white_icon.png')}
                                                style={{ alignSelf: 'center', width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                            </Image>
                                        </TouchableOpacity>
                                        <View style={{ width: '70%', justifyContent: 'center', alignItems: 'center' }}>
                                            <Text style={{
                                                width: '100%', fontSize: Font.fontSize5, color: Colors.whiteColor,
                                                fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                            }}></Text>
                                        </View>
                                        <TouchableOpacity onPress={() => { }} style={{ width: '15%' }}>
                                            <Image source={require('../../icons/employer_profile_icon.png')}
                                                style={{ alignSelf: 'center', width: mobileW * 10 / 100, height: mobileW * 10 / 100, resizeMode: 'contain' }}>
                                            </Image>
                                        </TouchableOpacity>
                                    </View>


                                    <View style={{
                                        flexDirection: 'row',
                                        marginTop: mobileW * 12 / 100,
                                        alignSelf: 'center'
                                    }}>
                                        <Text style={{
                                            color: Colors.whiteColor,
                                            fontFamily: Font.montserrat_Bold,
                                            fontSize: Font.fontSize8,
                                        }}>Ziplabor</Text>

                                        <Text style={{
                                            paddingLeft: mobileW * 1.5 / 100,
                                            color: Colors.whiteColor,
                                            fontSize: Font.fontSize8,
                                        }}>Crop</Text>
                                    </View>

                                    <View style={{
                                        flexDirection: 'row',
                                        width: mobileW * 50 / 100,
                                        marginTop: mobileW * 2 / 100,
                                        alignSelf: 'center'
                                    }}>
                                        <Text style={{
                                            paddingLeft: mobileW * 1.5 / 100,
                                            color: Colors.whiteColor,
                                            textAlign: 'center',
                                            fontSize: Font.fontSize4,
                                        }}>
                                            Where employers and employees connect
                                        </Text>
                                    </View>
                                    <View style={{
                                        width: mobileW * 90 / 100,
                                        marginTop: mobileW * 2 / 100,
                                        alignSelf: 'center',
                                        justifyContent: 'space-between'
                                    }}>
                                        <Text style={{
                                            fontSize: Font.fontSize5,
                                            color: Colors.whiteColor,
                                            fontFamily: Font.montserrat_Bold
                                        }}>
                                            Popular Categories
                                        </Text>
                                        <View style={{ marginTop: mobileW * 3.5 / 100 }}>
                                            <Text style={{
                                                fontSize: mobileW * 3.6 / 100,
                                                color: Colors.whiteColor,
                                                fontFamily: Font.montserrat_Medium
                                            }}>
                                                A better career is out there. We'll help you fint it.
                                                We're your first step to becoming everything you want to be.
                                            </Text>
                                        </View>
                                    </View>
                                </ImageBackground>
                            </View>
                            <View style={{
                                width: '100%',
                                position: 'absolute',
                                bottom: 0,
                            }}>
                                <FlatList
                                    style={{
                                        alignSelf: 'center',
                                        width: mobileW * 94 / 100,
                                    }}
                                    horizontal={true}
                                    data={this.state.data_arr}
                                    showsHorizontalScrollIndicator={false}
                                    renderItem={({ item, index }) =>
                                        <TouchableOpacity activeOpacity={.7} onPress={() => {
                                            this.callFuntion(index);
                                            this.props.navigation.navigate('EmployerFindJobsScreen');
                                        }}>
                                            <View style={{
                                                marginBottom: 10,
                                                marginLeft: 8,
                                                width: mobileW * 25 / 100,
                                                height: mobileW * 24 / 100,
                                                alignItems: 'center',
                                                backgroundColor: item.status == true ? Colors.lightGreenColor : Colors.whiteColor,
                                                shadowColor: '#000',
                                                shadowOffset: {
                                                    width: 0,
                                                    height: 1,
                                                },
                                                shadowOpacity: 0.5,
                                                shadowRadius: 0.5,
                                                elevation: 3,
                                            }}>
                                                <View>
                                                    <Image
                                                        source={item.status == true ?
                                                            require('../../icons/select_white_icon.png')
                                                            : require('../../icons/sector_blue.png')}
                                                        style={{
                                                            marginTop: mobileW * 5 / 100,
                                                            width: mobileW * 8 / 100,
                                                            height: mobileW * 8 / 100
                                                        }} />
                                                </View>
                                                <Text
                                                    numberOfLines={2}
                                                    style={{
                                                        paddingHorizontal: 4,
                                                        textAlign: 'center',
                                                        color: item.status == true ?
                                                            Colors.whiteColor : Colors.textColor,
                                                        marginTop: mobileW * 1 / 100,
                                                        fontSize: Font.fontSize3,
                                                        fontFamily: Font.montserrat_Regular
                                                    }}>
                                                    {item.name}
                                                </Text>
                                            </View>
                                        </TouchableOpacity>
                                    }
                                />
                            </View>
                        </View>

                        <View style={{ marginTop: mobileW * 2 / 100, width: mobileW * 90 / 100, alignSelf: 'center' }}>
                            <View style={{
                                marginTop: mobileW * 2 / 100, flexDirection: 'row',
                                justifyContent: 'space-between'
                            }}>
                                <Text style={{
                                    fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold
                                }}>
                                    Featured Job Listing
                                </Text>
                                <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                                    <View style={{
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                        width: mobileW * 20 / 100,
                                        height: mobileW * 8 / 100,
                                        backgroundColor: Colors.darkGreenColor
                                    }}>
                                        <Text style={{
                                            color: Colors.whiteColor,
                                            fontFamily: Font.montserrat_Bold,
                                            fontSize: Font.fontSize3
                                        }}>
                                            See All
                                        </Text>
                                    </View>
                                </TouchableOpacity>
                            </View>

                            <View style={{ marginTop: mobileW * 3.5 / 100 }}>
                                <Text style={{
                                    fontSize: Font.fontSize3half,
                                    color: Colors.textColor,
                                    fontFamily: Font.montserrat_Medium
                                }}>
                                    A better career is out there. We'll help you fint it.
                                    We're your first step to becoming everything you want to be.
                                </Text>
                            </View>
                        </View>


                        <View style={{ width: '100%' }}>
                            <FlatList
                                style={{ marginLeft: 12, }}
                                horizontal={true}
                                data={this.state.data_arr}
                                showsHorizontalScrollIndicator={false}
                                renderItem={({ item, index }) =>
                                    <View style={{
                                        marginTop: mobileW * 5 / 100,
                                        marginLeft: 10, marginBottom: 10
                                    }}>
                                        <View style={{
                                            marginRight: mobileW * 2.5 / 100,
                                            width: mobileW * 55 / 100,
                                            backgroundColor: Colors.whiteColor,
                                            height: mobileW * 65 / 100,
                                            shadowColor: '#000',
                                            shadowOffset: {
                                                width: 0,
                                                height: 1,
                                            },
                                            shadowOpacity: 0.5,
                                            shadowRadius: 0.5,
                                            elevation: 3,
                                        }}>

                                            <View style={{
                                                width: mobileW * 55 / 100,
                                                height: mobileW * 30 / 100
                                            }}>
                                                <ImageBackground
                                                    resizeMode={'cover'}
                                                    style={{
                                                        width: mobileW * 55 / 100,
                                                        height: mobileW * 30 / 100,
                                                    }} source={require('../../icons/placeholder.png')}>

                                                    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>

                                                        <View style={{
                                                            width: mobileW * 26 / 100,
                                                            height: mobileW * 16 / 100,
                                                            justifyContent: 'center',
                                                            alignItems: 'center'
                                                        }}>
                                                            <View style={{
                                                                justifyContent: 'center',
                                                                alignItems: 'center',
                                                                width: mobileW * 16 / 100,
                                                                height: mobileW * 6 / 100,
                                                                backgroundColor: 'rgb(91,126,197)'
                                                            }}>
                                                                <Text style={{
                                                                    color: Colors.whiteColor,
                                                                    fontFamily: Font.montserrat_Bold,
                                                                    fontSize: Font.fontSize2half
                                                                }}>
                                                                    Full Time
                                                                </Text>
                                                            </View>
                                                        </View>

                                                        <View style={{
                                                            height: mobileW * 16 / 100,
                                                            marginRight: 10,
                                                            justifyContent: 'center',
                                                            alignItems: 'center'
                                                        }}>
                                                            <MaterialCommunityIcons name='heart-outline'
                                                                size={30} color={Colors.darkGreenColor} />
                                                        </View>
                                                    </View>
                                                </ImageBackground>
                                            </View>


                                            <View style={{ marginLeft: mobileW * 2 / 100, marginTop: mobileW * 2 / 100 }}>
                                                <Text style={{ color: Colors.lightGreenColor, fontSize: Font.fontSize3half }}>
                                                    @ Ebiquity Maxi
                                                </Text>

                                                <Text
                                                    numberOfLines={2}
                                                    style={{
                                                        fontSize: Font.fontSize4, color: Colors.textColor,
                                                        fontFamily: Font.montserrat_Bold
                                                    }}>
                                                    Marketing Expert For {item.name}
                                                </Text>
                                                <View style={{
                                                    width: mobileW * 50 / 100,
                                                    height: mobileW * 9 / 100,
                                                    marginTop: 10,
                                                    justifyContent: 'flex-start',
                                                    flexDirection: 'row'
                                                }}>
                                                    <Image
                                                        style={{
                                                            width: 25,
                                                            height: 20,
                                                        }}
                                                        resizeMode={'contain'}
                                                        source={require('../../icons/bag_icon.png')} />
                                                    <Text style={{
                                                        paddingLeft: 10, fontSize: Font.fontSize3half, fontFamily: Font.montserrat_Regular, color: Colors.textColorLight
                                                    }}>{item.name}</Text>
                                                </View>

                                                <View style={{
                                                    width: mobileW * 50 / 100,
                                                    height: mobileW * 9 / 100,
                                                    justifyContent: 'flex-start',
                                                    flexDirection: 'row'
                                                }}>
                                                    <Image
                                                        style={{
                                                            width: 25,
                                                            height: 20,
                                                        }}
                                                        resizeMode={'contain'}
                                                        source={require('../../icons/location_icon.png')} />
                                                    <Text style={{
                                                        paddingLeft: 10, fontSize: Font.fontSize3half, fontFamily: Font.montserrat_Regular, color: Colors.textColorLight
                                                    }}>{item.city}</Text>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                }
                            />
                        </View>
                        <View style={{ marginTop: mobileW * 2 / 100, width: mobileW * 90 / 100, alignSelf: 'center' }}>
                            <View style={{ marginTop: mobileW * 2 / 100, flexDirection: 'row', justifyContent: 'space-between' }}>
                                <Text style={{
                                    fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold
                                }}>
                                    From our blog
                                </Text>
                            </View>

                            <View style={{ marginTop: mobileW * 3.5 / 100 }}>
                                <Text style={{
                                    fontSize: Font.fontSize3half,
                                    color: Colors.textColor,
                                    fontFamily: Font.montserrat_Medium
                                }}>
                                    A better career is out there. We'll help you fint it.
                                    We're your first step to becoming everything you want to be.
                                </Text>
                            </View>
                        </View>
                        <View style={{ width: '100%' }}>
                            <FlatList
                                style={{
                                    marginLeft: 12,
                                    marginBottom: mobileW * 14 / 100,
                                    marginRight: mobileW * 2 / 100
                                }}
                                horizontal={true}
                                data={this.state.blog_data_arr}
                                showsHorizontalScrollIndicator={false}
                                renderItem={({ item, index }) =>
                                    <View style={{ marginTop: mobileW * 5 / 100, marginLeft: 10, marginBottom: 10 }}>
                                        <View style={{
                                            width: mobileW * 55 / 100,
                                            backgroundColor: Colors.whiteColor,
                                            height: mobileW * 75 / 100,
                                            shadowColor: '#000',
                                            marginRight: mobileW * 1 / 100,
                                            shadowOffset: {
                                                width: 0,
                                                height: 1,
                                            },
                                            shadowOpacity: 0.5,
                                            shadowRadius: 0.5,
                                            elevation: 3,
                                        }}>

                                            <View style={{
                                                width: mobileW * 55 / 100,
                                                height: mobileW * 30 / 100
                                            }}>
                                                <ImageBackground
                                                    resizeMode={'cover'}
                                                    style={{
                                                        width: mobileW * 55 / 100,
                                                        height: mobileW * 30 / 100,
                                                    }} source={require('../../icons/placeholder.png')}>
                                                </ImageBackground>
                                            </View>

                                            <View style={{ marginLeft: mobileW * 2 / 100, marginTop: mobileW * 2 / 100 }}>
                                                <Text style={{ color: Colors.greyColor, fontSize: Font.fontSize3half }}>
                                                    {item.date}
                                                </Text>

                                                <Text
                                                    numberOfLines={2}
                                                    style={{
                                                        fontSize: Font.fontSize4, color: Colors.textColor,
                                                        fontFamily: Font.montserrat_Bold
                                                    }}>
                                                    {item.title}
                                                </Text>
                                                <View style={{ marginTop: mobileW * 1 / 100, paddingHorizontal: mobileW * 1 / 100 }}>
                                                    <Text
                                                        numberOfLines={6}
                                                        style={{
                                                            fontSize: Font.fontSize3,
                                                            fontFamily: Font.montserrat_Medium,
                                                            color: Colors.textColorLight
                                                        }}>{item.discription}</Text>
                                                </View>
                                            </View>

                                        </View>
                                    </View>
                                }
                            />
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    image: {
        flex: 1,
    },
    employerScreenBody: {

        width: mobileW * 90 / 100,
        height: 500,
        backgroundColor: 'yellow'
    },
});

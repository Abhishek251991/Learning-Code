import React, { Component } from 'react';
import { TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, Modal } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
import Footer from '../../../Provider/Footer';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Keyboard } from 'react-native';

const JobPostHeading = ({ title, color }) => (
    <Text style={{
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Bold,
        color: color
    }}>{title}</Text>
);


const AddButton = ({ title, color, backgroundColor, onPress }) => (
    <TouchableOpacity
        activeOpacity={.7}
        onPress={onPress}
        style={{
            marginTop: mobileW * 6 / 100,
            paddingVertical: mobileW * 3.5 / 100,
            width: mobileW * 90 / 100,
            backgroundColor: backgroundColor
        }}>
        <Text style={{
            alignSelf: 'center',
            paddingVertical: mobileW * 1.5 / 100,
            color: color,
            fontSize: mobileW * 3.5 / 100,
            fontFamily: Font.montserrat_Bold
        }}>
            {title}
        </Text>
    </TouchableOpacity>
);


const CouponButton = ({ title, color, backgroundColor, onPress }) => (
    <TouchableOpacity
        activeOpacity={.7}
        onPress={onPress}
        style={{
            marginTop: mobileW * 6 / 100,
            paddingVertical: mobileW * 2.5 / 100,
            width: mobileW * 90 / 100,
            backgroundColor: backgroundColor
        }}>
        <Text style={{
            alignSelf: 'center',
            paddingVertical: mobileW * 1 / 100,
            color: color,
            fontSize: mobileW * 3 / 100,
            fontFamily: Font.montserrat_Medium
        }}>
            {title}
        </Text>
    </TouchableOpacity>
);


export default class ConfirmationScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            jobTitle: '',
            selectedCountry: 'NA',
            selectedState: 'NA',
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <View style={styles.screenBody}>
                    <JobPostHeading title="Confirmation" color={Colors.textColor} />

                    <CouponButton title='Have a coupon? Click here to enter your code'
                        color={Colors.whiteColor}
                        backgroundColor={Colors.darkGreenColor}
                    />

                    <View style={{ marginTop: mobileW * 4 / 100 }}>
                        <JobPostHeading title="Billing details" color={Colors.textColor} />
                    </View>


                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                First Name
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                placeholder={'First Name'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Last Name
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Last Name'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Company Name (optional)
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Company Name'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Country/ Region
                            </Text>
                        </View>

                        <TouchableOpacity onPress={() => {
                            // this.openListModal('jobsector');
                            // this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedCountry != "NA" ? this.state.selectedCountry : "Select"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Address
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Address'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Town/City
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Town/City'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                State
                            </Text>
                        </View>

                        <TouchableOpacity onPress={() => {
                            // this.openListModal('jobsector');
                            // this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedState != "NA" ? this.state.selectedState : "Select"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Zip
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Zip'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Phone
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='number-pad'
                                placeholder={'Phone'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={10}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Email Address
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='email-address'
                                placeholder={'Email Address'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={10}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Order Notes (Optional)
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Order Notes'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={10}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>


                    <View style={{ marginTop: mobileW * 4 / 100 }}>
                        <JobPostHeading title="Your Order" color={Colors.textColor} />
                    </View>

                    <View style={{
                        width: mobileW * 90 / 100,
                        backgroundColor: Colors.whiteColor,
                        shadowColor: '#000',
                        marginTop: mobileW * 2 / 100,
                        shadowOffset: {
                            width: 0,
                            height: 2,
                        },
                        shadowOpacity: 5,
                        shadowRadius: 5,
                        elevation: 1,
                        padding: mobileW * 3.5 / 100
                    }}>

                        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={{
                                fontSize: Font.fontSize4,
                                fontFamily: Font.montserrat_Regular,
                                color: Colors.textColor
                            }}>Golden X1</Text>
                            <Text style={{
                                fontSize: Font.fontSize4,
                                fontFamily: Font.montserrat_Regular,
                                color: Colors.textColor
                            }}>$90.00</Text>
                        </View>

                        <View style={{
                            paddingTop: mobileW * 2 / 100,
                            alignSelf: 'center',
                            width: mobileW * 80 / 100,
                            borderBottomWidth: 1,
                            borderBottomColor: Colors.silverLightColor
                        }}></View>

                        <View style={{ flexDirection: 'row', paddingTop: mobileW * 2 / 100, justifyContent: 'space-between' }}>
                            <Text style={{
                                fontSize: Font.fontSize4,
                                fontFamily: Font.montserrat_Regular,
                                color: Colors.textColor
                            }}>Subtotal</Text>
                            <Text style={{
                                fontSize: Font.fontSize4,
                                fontFamily: Font.montserrat_Regular,
                                color: Colors.textColor
                            }}>$90.00</Text>
                        </View>

                        <View style={{
                            alignSelf: 'center',
                            paddingTop: mobileW * 2 / 100,
                            width: mobileW * 80 / 100,
                            borderBottomWidth: 1,
                            borderBottomColor: Colors.silverLightColor
                        }}></View>

                        <View style={{ flexDirection: 'row', paddingTop: mobileW * 2 / 100, justifyContent: 'space-between' }}>
                            <Text style={{
                                fontSize: Font.fontSize4,
                                fontFamily: Font.montserrat_Bold,
                                color: Colors.textColor
                            }}>Total</Text>
                            <Text style={{
                                fontSize: Font.fontSize4,
                                fontFamily: Font.montserrat_Bold,
                                color: Colors.textColor
                            }}>$90.00</Text>
                        </View>
                    </View>

                    <View style={{ marginTop: mobileW * 4 / 100 }}>
                        <JobPostHeading title="What is PayPal?" color={Colors.textColor} />
                    </View>

                    <View style={{ marginTop: mobileW * 4 / 100 }}>
                        <Text style={{
                            fontSize: Font.fontSize4,
                            fontFamily: Font.montserrat_Regular,
                            color: Colors.textColor
                        }}>
                            Pay via PayPal; you can pay with your credit card if you don't have a PayPal account.</Text>
                    </View>

                    <View style={{ marginTop: mobileW * 4 / 100 }}>
                        <Text style={{
                            fontSize: Font.fontSize4,
                            fontFamily: Font.montserrat_Regular,
                            color: Colors.textColor
                        }}>Your personal data will be used to process your order, support your experience throughout this website, and for other purpose described in our privacy policy.
                        </Text>
                    </View>

                    <View style={{ marginTop: mobileW * 3 / 100 }}>
                        <AddButton
                            title='PROCEED TO PAYPAL'
                            color={Colors.whiteColor}
                            backgroundColor={Colors.darkGreenColor}
                            onPress={() => { }}
                        />
                    </View>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    screenBody: {
        marginTop: mobileW * 5 / 100,
        width: mobileW * 90 / 100,
        marginBottom: mobileW * 18 / 100,
        alignSelf: 'center',
    },
    textFieldLabel: {
        marginBottom: mobileW * 2 / 100,
        color: Colors.greyColor,
        fontSize: Font.fontSize3half,
        fontFamily: Font.montserrat_Regular
    },
    eyeButton: {
        width: mobileW * 15 / 100,
        height: mobileW * 8 / 100,
        alignItems: 'center',
        justifyContent: 'center',
        alignSelf: 'center'
    },
    showHideText: {
        color: Colors.textColor,
        fontSize: Font.fontSize3
    },
    inputStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        paddingVertical: mobileW * 3.5 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    inputHalfStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 44 / 100,
        paddingVertical: mobileW * 3 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    inputMultilineStyle: {
        textAlignVertical: 'top',
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        height: mobileW * 35 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    containerStyle: {
        width: '100%',
        marginTop: mobileW * 3 / 100,
        marginBottom: mobileW * 1 / 100,
    },
    labelStyle: {
        width: mobileW * 82 / 100, alignSelf: 'center'
    },
});

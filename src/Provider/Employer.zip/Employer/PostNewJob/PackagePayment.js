import React, { Component } from 'react';
import { TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, Modal } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
import Footer from '../../../Provider/Footer';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Keyboard } from 'react-native';

const JobPostHeading = ({ title, color }) => (
    <Text style={{
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Bold,
        color: color
    }}>{title}</Text>
);

const PackageAndPayment = [
    { package: 'Golden', price: '$90.00', days: '30', count: '15' },
    { package: 'Preminum', price: '$159.00', days: '60', count: '25' },
    { package: 'Silver', price: '$50.00', days: '20', count: '10' },
    { package: 'Standard', price: 'Free', days: '15', count: '1' },
];

export default class PackagePaymentScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            PackageAndPaymentArray: PackageAndPayment,
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <View style={styles.screenBody}>
                    <JobPostHeading title="Package & Payment" color={Colors.textColor} />

                    <FlatList
                        style={{ width: mobileW * 95 / 100, alignSelf: 'center', marginBottom: mobileW * 2 / 100 }}
                        data={this.state.PackageAndPaymentArray}
                        renderItem={({ item, index }) =>
                            <View style={styles.cardShadowView}>
                                <View style={{
                                    flexDirection: 'row',
                                    justifyContent: 'space-between',
                                }}>
                                    <Text style={{
                                        color: Colors.textColor,
                                        fontSize: Font.fontSize4,
                                        fontFamily: Font.montserrat_Bold
                                    }}>
                                        {item.package}
                                    </Text>
                                    <Text style={{
                                        color: Colors.textColor,
                                        fontSize: Font.fontSize4,
                                        fontFamily: Font.montserrat_Bold
                                    }}>
                                        {item.price}
                                    </Text>
                                </View>
                                <View style={{ flexDirection: 'row', paddingTop: mobileW * 3 / 100 }}>
                                    <Image resizeMode={'contain'} source={localImage.clockIcon} style={{
                                        width: mobileW * 5 / 100, height: mobileW * 5 / 100
                                    }} />
                                    <Text style={{
                                        paddingLeft: mobileW * 2.5 / 100,
                                        fontFamily: Font.montserrat_Regular,
                                        fontSize: mobileW * 3.5 / 100,
                                        color: Colors.textColor
                                    }}>Package Expiry : {item.days} Days</Text>
                                </View>
                                <View style={{ flexDirection: 'row', paddingTop: mobileW * 3 / 100 }}>
                                    <Image resizeMode={'contain'} source={localImage.pageIcon} style={{
                                        width: mobileW * 5 / 100, height: mobileW * 5 / 100
                                    }} />
                                    <Text style={{
                                        paddingLeft: mobileW * 2.5 / 100,
                                        fontFamily: Font.montserrat_Regular,
                                        fontSize: mobileW * 3.5 / 100,
                                        color: Colors.textColor
                                    }}>
                                        Total : {item.count}
                                    </Text>
                                </View>
                            </View>
                        }
                        keyExtractor={(item, index) => index.toString()}
                    >
                    </FlatList>
                </View>
            </View>
        );
    }
}


const styles = StyleSheet.create({
    screenBody: {
        marginTop: mobileW * 5 / 100,
        width: mobileW * 90 / 100,
        marginBottom: mobileW * 18 / 100,
        alignSelf: 'center',
    },
    cardShadowView: {
        padding: mobileW * 3 / 100,
        width: mobileW * 90 / 100,
        marginBottom: 1,
        marginTop: mobileW * 4 / 100,
        alignSelf: 'center',
        backgroundColor: Colors.whiteColor,
        shadowColor: '#000',
        shadowOffset: {
            width: 2,
            height: 2,
        },
        shadowOpacity: 0.5,
        shadowRadius: 0.5,
        elevation: 2,
    },
});

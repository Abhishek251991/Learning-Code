import React, { Component } from 'react';
import { FlatList } from 'react-native';
import { Keyboard, Image, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View, } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mobileH, localStorage, Colors, Font, localImage } from '../../../Provider/utilslib/Utils';


const DATA = [
    {
        value: '1000',
    },
    {
        value: '3000',
    },
    {
        value: '5000',
    },
    {
        value: '7000',
    },
    {
        value: '9000',
    },
    {
        value: '6000',
    },
    {
        value: '11000',
    },
    {
        value: '13000',
    },
    {
        value: '15000',
    },
    {
        value: '170000',
    },
    {
        value: '19000',
    },
    {
        value: '12000',
    },
];

export default class SelectionListScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dataArr: DATA,
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Offered Salary</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={{ width: '78%' }}>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <View>
                            <FlatList
                                style={{ marginTop: mobileW * 4 / 100, }}
                                data={this.state.dataArr}
                                showsVerticalScrollIndicator={false}
                                renderItem={({ item, index }) => {
                                    return (
                                        <View style={{
                                            width: mobileW * 85 / 100, alignSelf: 'center', borderBottomWidth: 1,
                                            borderBottomColor: Colors.greyColor
                                        }}>
                                            <Text style={{
                                                paddingVertical: mobileW * 4 / 100,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColor
                                            }}>{item.value}</Text>
                                        </View>
                                    );
                                }}
                            />
                        </View>
                    </KeyboardAwareScrollView>
                </ScrollView>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
});
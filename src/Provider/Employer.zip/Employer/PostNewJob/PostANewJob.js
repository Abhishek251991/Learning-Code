import React, { Component } from 'react';
import { Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import OtherInformationScreen from './OtherInformation';
import ApplyJobQuestionsScreen from './ApplyJobQuestions';
import AddressLocationScreen from './AddressLocation';
import DescriptionScreen from './Description';
import FileAttachementScreen from './FileAttachement';
import Footer from '../../../Provider/Footer';
import HideWithKeyboard from 'react-native-hide-with-keyboard';
import ConfirmationScreen from './Confirmation';
import PackagePaymentScreen from './PackagePayment';


const HorizontalBar = ({ }) => {
    return (
        <View style={{ paddingVertical: mobileW * 5 / 100, }}>
            <View style={{
                width: mobileW * 15 / 100,
                borderBottomColor: Colors.darkGreenColor,
                borderBottomWidth: 1.5,
            }} />
        </View>
    );
}

const AddJobPost = [
    {
        option: 'Description',
        status: true
    },
    {
        option: 'Other Information',
        status: false
    },
    {
        option: 'Apply Job Questions',
        status: false
    },
    {
        option: 'File Attachement',
        status: false
    },
    {
        option: 'Address/Location',
        status: false
    }
];


export default class PostANewJobScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            addJobArr: AddJobPost,
            option1: true,
            option2: false,
            option3: false,
            usertype: localStorage.getItemString('userType'),
            isDescription: true,
            isOtherInformation: false,
            iApplyJobQuestion: false,
            isFileAttachement: false,
            isAddressLocation: false,
        }
    }

    openScreenOnOptionClick = (index) => {
        switch (index) {
            case 'one':
                this.setState({ option1: true, option2: false, option3: false });
                break;
            case 'two':
                this.setState({ option1: false, option2: true, option3: false });
                break;
            case 'three':
                this.setState({ option1: false, option2: false, option3: true });
                break;
        }
    }
    changeOption = (index) => {
        let value = index.toString();
        switch (value) {
            case '0':
                this.setState({
                    isDescription: true,
                    isOtherInformation: false,
                    iApplyJobQuestion: false,
                    isFileAttachement: false,
                    isAddressLocation: false,
                });
                break;
            case '1':
                this.setState({
                    isDescription: false,
                    isOtherInformation: true,
                    iApplyJobQuestion: false,
                    isFileAttachement: false,
                    isAddressLocation: false,
                });
                break;
            case '2':
                this.setState({
                    isDescription: false,
                    isOtherInformation: false,
                    iApplyJobQuestion: true,
                    isFileAttachement: false,
                    isAddressLocation: false,
                });
                break;
            case '3':
                this.setState({
                    isDescription: false,
                    isOtherInformation: false,
                    iApplyJobQuestion: false,
                    isFileAttachement: true,
                    isAddressLocation: false,
                });
                break;
            case '4':
                this.setState({
                    isDescription: false,
                    isOtherInformation: false,
                    iApplyJobQuestion: false,
                    isFileAttachement: false,
                    isAddressLocation: true,
                });
                break;
        }
        let data = this.state.addJobArr;
        for (let i = 0; i < data.length; i++)
            data[i].status = false;
        data[index].status = true;
        this.setState({ addJobArr: data });
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive'
                    keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={styles.appBarStyle}>
                            <TouchableOpacity style={styles.leadingContainerStyle} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={styles.leadingIcon}>
                                </Image>
                            </TouchableOpacity>
                            <View style={styles.centerContainerStyle}>
                                <Text style={styles.centerTitleText}>Post A New Job</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={styles.actionContainerStyle}>
                                <Image borderRadius={25} source={localImage.saveImage}
                                    style={styles.actionButtons}>
                                </Image>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <View style={styles.screenBody}>
                            <View style={{ width: mobileW * 70 / 100, alignSelf: 'center', marginTop: mobileW * 4 / 100 }}>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <TouchableOpacity style={{ backgroundColor: 'red' }} activeOpacity={.7} onPress={() => {
                                        this.openScreenOnOptionClick('one')
                                    }}>
                                        <View
                                            style={[styles.optionBoxStyle,
                                            { backgroundColor: this.state.option1 ? Colors.darkGreenColor : Colors.extraLightGreenColor, }]}>
                                            <Text style={{
                                                alignSelf: 'center',
                                                fontFamily: Font.montserrat_Medium,
                                                fontSize: Font.fontSize4,
                                                color: this.state.option1 ? Colors.whiteColor : Colors.darkGreenColor,
                                            }}>1</Text>
                                        </View>
                                    </TouchableOpacity>
                                    <HorizontalBar />
                                    <TouchableOpacity activeOpacity={.7} onPress={() => { this.openScreenOnOptionClick('two') }}>
                                        <View
                                            style={[styles.optionBoxStyle,
                                            { backgroundColor: this.state.option2 ? Colors.darkGreenColor : Colors.extraLightGreenColor, }]}>
                                            <Text style={{
                                                alignSelf: 'center',
                                                fontFamily: Font.montserrat_Medium,
                                                fontSize: Font.fontSize4,
                                                color: this.state.option2 ? Colors.whiteColor : Colors.darkGreenColor,
                                            }}>2</Text>
                                        </View>
                                    </TouchableOpacity>
                                    <HorizontalBar />
                                    <TouchableOpacity activeOpacity={.7} onPress={() => { this.openScreenOnOptionClick('three') }}>
                                        <View
                                            style={[styles.optionBoxStyle,
                                            { backgroundColor: this.state.option3 ? Colors.darkGreenColor : Colors.extraLightGreenColor, }]}>
                                            <Text style={{
                                                alignSelf: 'center',
                                                fontFamily: Font.montserrat_Medium,
                                                fontSize: Font.fontSize4,
                                                color: this.state.option3 ? Colors.whiteColor : Colors.darkGreenColor,
                                            }}>3</Text>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                                <View style={{ width: mobileW * 78 / 100, alignSelf: 'center' }}>

                                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: mobileW * 4 / 100 }}>

                                        <Text style={styles.optionTextStyle}>
                                            Job Detail
                                        </Text>
                                        <Text style={styles.optionTextStyle}>
                                            Package & Payments
                                        </Text>
                                        <Text style={styles.optionTextStyle}>
                                            Confirmation
                                        </Text>
                                    </View>
                                </View>
                            </View>
                        </View>

                        {
                            this.state.option1 == true &&
                            <View style={{ width: mobileW * 100 / 100, alignSelf: 'center' }}>
                                <FlatList
                                    style={{
                                        width: mobileW * 95 / 100,
                                        alignSelf: 'center',
                                        marginTop: mobileW * 5.5 / 100
                                    }}
                                    horizontal={true}
                                    data={this.state.addJobArr}
                                    showsHorizontalScrollIndicator={false}
                                    renderItem={({ item, index }) => {
                                        return (
                                            <TouchableOpacity onPress={() => {
                                                this.changeOption(index);
                                            }} activeOpacity={.7}>
                                                <View style={{ paddingHorizontal: 10, flexDirection: 'row' }}>
                                                    <Text style={{
                                                        paddingVertical: mobileW * 1 / 100,
                                                        fontFamily: item.status ? Font.montserrat_Bold : Font.montserrat_Medium,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        color: item.status ? Colors.darkGreenColor : Colors.greyColor
                                                    }}>
                                                        {item.option}
                                                    </Text>
                                                    {
                                                        index < 4 &&
                                                        <FontAwesome name='caret-right' size={30} color={Colors.darkGreenColor} style={{ paddingLeft: mobileW * 4 / 100 }} />
                                                    }
                                                </View>
                                            </TouchableOpacity>
                                        );
                                    }}
                                    keyExtractor={(item, index) => index.toString()}
                                ></FlatList>
                                <View style={{ width: mobileW * 90 / 100, alignSelf: 'center' }}>
                                    {
                                        this.state.isDescription == true &&
                                        <DescriptionScreen />
                                    }
                                    {
                                        this.state.isOtherInformation == true &&
                                        <OtherInformationScreen />
                                    }
                                    {
                                        this.state.iApplyJobQuestion == true &&
                                        <ApplyJobQuestionsScreen />
                                    }
                                    {
                                        this.state.isFileAttachement == true &&
                                        <FileAttachementScreen />
                                    }
                                    {
                                        this.state.isAddressLocation == true &&
                                        <AddressLocationScreen />
                                    }
                                </View>
                            </View>
                        }
                        {
                            this.state.option2 == true &&
                            <PackagePaymentScreen />
                        }
                        {
                            this.state.option3 == true &&
                            <ConfirmationScreen />
                        }

                    </KeyboardAwareScrollView>
                    <View style={{ justifyContent: 'flex-end' }}>
                        <HideWithKeyboard>
                            <Footer
                                activepage='Employer' // active screen initially
                                usertype={1} // types of user set
                                footerpage={[
                                    { name: 'Employer', label: 'Main', countshow: false, image: require('../../../icons/sector_blue.png'), activeimage: require('../../../icons/home_active_icon.png') },
                                    { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../../icons/bell_icon.png'), activeimage: require('../../../icons/bell_active_icon.png') },
                                    { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../../icons/list_icon.png'), activeimage: require('../../../icons/mylist_active_icon.png') },
                                    { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../../icons/account_icon.png'), activeimage: require('../../../icons/acount_active_icon.png') },
                                ]} // number of menus in bottom navigation bar
                                navigation={this.props.navigation} // send navigation object
                                imagestyle1={{
                                    width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                                    backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                                }}
                            />
                        </HideWithKeyboard>
                    </View>
                </ScrollView>
            </View>
        );
    }
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    appBarStyle: {
        flexDirection: 'row',
        width: '100%',
        paddingHorizontal: 10,
        alignItems: 'center',
        backgroundColor: Colors.whiteColor,
        height: mobileH * 8 / 100,
    },
    leadingContainerStyle: {
        width: '15%',
    },
    leadingIcon: {
        marginLeft: mobileW * 3 / 100,
        width: mobileW * 7 / 100,
        height: mobileW * 7 / 100,
        resizeMode: 'contain'
    },
    centerContainerStyle: {
        width: '70%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    centerTitleText: {
        width: '100%',
        fontSize: Font.fontSize5,
        color: Colors.textColor,
        fontFamily: Font.montserrat_Bold,
        textAlign: 'center'
    },
    actionContainerStyle: {
        width: '15%'
    },
    actionButtons: {
        alignSelf: 'center',
        width: mobileW * 7.5 / 100,
        height: mobileW * 7.5 / 100,
        resizeMode: 'contain'
    },
    screenBody: {
        width: mobileW * 90 / 100,
        alignSelf: 'center',
    },
    optionBoxStyle: {
        paddingVertical: mobileW * 2.5 / 100,
        width: mobileW * 10 / 100,
    },
    optionTextStyle: {
        color: Colors.textColor, fontSize: Font.fontSize3half, fontFamily: Font.montserrat_Medium
    }
});
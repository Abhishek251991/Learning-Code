import React, { Component } from 'react';
import { TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, Modal, Switch } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
import Footer from '../../../Provider/Footer';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Keyboard } from 'react-native';

const JobPostHeading = ({ title, color }) => (
    <Text style={{
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Bold,
        color: color
    }}>{title}</Text>
);

const AddButton = ({ title, color, backgroundColor, onPress, paddingVerticalComponent, paddingVerticalText }) => (
    <TouchableOpacity
        activeOpacity={.7}
        onPress={onPress}
        style={{
            alignSelf: 'center',
            marginTop: mobileW * 10 / 100,
            paddingVertical: mobileW * paddingVerticalComponent / 100,
            width: mobileW * 84 / 100,
            backgroundColor: backgroundColor
        }}>
        <Text style={{
            alignSelf: 'center',
            paddingVertical: mobileW * paddingVerticalText / 100,
            color: color,
            fontSize: Font.fontSize4,
            fontFamily: Font.montserrat_Medium
        }}>
            {title}
        </Text>
    </TouchableOpacity>
);
export default class ApplyJobQuestionsScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            multiSelectOption: true,
            mandatory: false,
            jobApply: true,
            textAreaMandatory: false,
            correctAnswer: false,
            checkbox: true,
        }
    }

    checkboxTermsAndCondition = () => {
        if (this.state.checkbox) {
            this.setState({ checkbox: false })
        } else {
            this.setState({ checkbox: true })
        }
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <View style={styles.screenBody}>

                    <JobPostHeading title="Apply Job Questions" color={Colors.textColor} />
                    <View style={{
                        width: mobileW * 90 / 100,
                        backgroundColor: Colors.whiteColor,
                        shadowColor: '#000',
                        marginTop: mobileW * 2 / 100,
                        shadowOffset: {
                            width: 0,
                            height: 2,
                        },
                        shadowOpacity: 5,
                        shadowRadius: 5,
                        elevation: 1,
                        paddingVertical: mobileW * 2 / 100
                    }}>
                        <View style={{
                            flexDirection: 'row', justifyContent: 'space-between',
                            width: mobileW * 84 / 100, alignSelf: 'center'
                        }}>
                            <View style={{ flexDirection: 'row', }}>
                                <Image source={localImage.downArrowIcon} style={{
                                    width: mobileW * 7 / 100,
                                    height: mobileW * 7 / 100
                                }} />
                                <View style={{ paddingLeft: mobileW * 4 / 100 }}>
                                    <JobPostHeading title="Dropdown" color={Colors.textColor} />
                                </View>
                            </View>
                            <Image source={localImage.deleteImage} style={{
                                width: mobileW * 6 / 100,
                                height: mobileW * 6 / 100
                            }} />
                        </View>

                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: mobileW * 2 / 100, paddingHorizontal: mobileW * 1 / 100 }}>
                            <View style={{ flexDirection: 'row' }}>
                                <Switch
                                    style={{ transform: [{ scaleX: 1.2 }, { scaleY: 1.2 }] }}
                                    thumbColor={{ true: Colors.darkGreenColor, false: Colors.greyColor }}
                                    value={this.state.multiSelectOption}
                                    trackColor={{ true: Colors.lightGreenColor, false: Colors.greyColor }}
                                    onValueChange={(multiSelectOption) => this.setState({ multiSelectOption })} />
                                <Text style={{
                                    paddingLeft: mobileW * 1 / 100,
                                    color: Colors.textColor,
                                    paddingVertical: mobileW * 1 / 100,
                                    fontSize: mobileW * 3.5 / 100,
                                    fontFamily: Font.montserrat_Regular
                                }}>Multi Select Answers</Text>
                            </View>
                            <View style={{ flexDirection: 'row' }}>
                                <Switch
                                    style={{ transform: [{ scaleX: 1.2 }, { scaleY: 1.2 }] }}
                                    thumbColor={{ true: Colors.darkGreenColor, false: Colors.greyColor }}
                                    value={this.state.mandatory}
                                    trackColor={{ true: Colors.lightGreenColor, false: Colors.greyColor }}
                                    onValueChange={(mandatory) => this.setState({ mandatory })} />
                                <Text style={{
                                    paddingHorizontal: mobileW * 2 / 100,
                                    paddingLeft: mobileW * 1 / 100,
                                    paddingVertical: mobileW * 1 / 100,
                                    color: Colors.textColor,
                                    fontSize: mobileW * 3.5 / 100,
                                    fontFamily: Font.montserrat_Regular
                                }}>Mandatory</Text>
                            </View>
                        </View>
                        <Text style={{
                            marginTop: mobileW * 2 / 100,
                            paddingHorizontal: mobileW * 2 / 100,
                            fontSize: mobileW * 3.5 / 100,
                            fontFamily: Font.montserrat_Bold,
                            color: Colors.textColor
                        }}>Question Title</Text>

                        <View style={{ flexDirection: 'row', marginTop: mobileW * 2 / 100, }}>
                            <Switch
                                style={{ transform: [{ scaleX: 1.2 }, { scaleY: 1.2 }] }}
                                thumbColor={{ true: Colors.darkGreenColor, false: Colors.greyColor }}
                                value={this.state.jobApply}
                                trackColor={{ true: Colors.lightGreenColor, false: Colors.greyColor }}
                                onValueChange={(jobApply) => this.setState({ jobApply })} />
                            <Text style={{
                                paddingLeft: mobileW * 2 / 100,
                                paddingVertical: mobileW * 1.5 / 100,
                                color: Colors.textColor,
                                fontSize: mobileW * 3.5 / 100,
                                fontFamily: Font.montserrat_Regular
                            }}>Require correct answers job apply</Text>
                        </View>

                        <View style={styles.containerStyle}>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Option Text'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 84 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingLeft: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular
                                }}
                            ></TextInput>
                        </View>

                        <View style={[styles.containerStyle, { flexDirection: 'row', alignItems: 'center' }]}>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Question Text'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={{
                                    color: Colors.textColor,
                                    marginLeft: mobileW * 3 / 100,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 55 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingLeft: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular
                                }}
                            ></TextInput>
                            <View style={{ width: mobileW * 25 / 100, }}>
                                <View style={{ flexDirection: 'row', paddingLeft: mobileW * 2 / 100, justifyContent: 'space-between', marginTop: mobileW * 2 / 100, }}>
                                    <Switch
                                        style={{ transform: [{ scaleX: 1.2 }, { scaleY: 1.2 }] }}
                                        thumbColor={{ true: Colors.darkGreenColor, false: Colors.greyColor }}
                                        value={this.state.correctAnswer}
                                        trackColor={{ true: Colors.lightGreenColor, false: Colors.greyColor }}
                                        onValueChange={(correctAnswer) => this.setState({ correctAnswer })} />
                                    <Text
                                        numberOfLines={2}
                                        style={{
                                            paddingLeft: mobileW * 2 / 100,
                                            paddingVertical: mobileW * 1.5 / 100,
                                            color: Colors.textColor,
                                            fontSize: mobileW * 3.5 / 100,
                                            fontFamily: Font.montserrat_Regular
                                        }}>Correct  Answer</Text>
                                </View>
                            </View>
                        </View>
                        <View style={{ paddingBottom: mobileW * 3 / 100 }}>
                            <AddButton
                                title="Add Option"
                                color={Colors.whiteColor}
                                backgroundColor={Colors.darkGreenColor}
                                onPress={() => { }}
                                paddingVerticalComponent={1.5}
                                paddingVerticalText={0.5}
                            />
                        </View>
                    </View>

                    <View style={{
                        width: mobileW * 90 / 100,
                        backgroundColor: Colors.whiteColor,
                        shadowColor: '#000',
                        marginTop: mobileW * 2 / 100,
                        shadowOffset: {
                            width: 0,
                            height: 2,
                        },
                        shadowOpacity: 5,
                        shadowRadius: 5,
                        elevation: 1,
                        paddingVertical: mobileW * 2 / 100,
                        marginTop: mobileW * 7 / 100
                    }}>
                        <View style={{
                            flexDirection: 'row', justifyContent: 'space-between',
                            width: mobileW * 84 / 100, alignSelf: 'center'
                        }}>
                            <View style={{ flexDirection: 'row', }}>
                                {/* <Image source={localImage.downArrowIcon} style={{
                                    width: mobileW * 7 / 100,
                                    height: mobileW * 7 / 100
                                }} /> */}
                                <View style={{}}>
                                    <JobPostHeading title="Textarea" color={Colors.textColor} />
                                </View>
                            </View>
                            <Image source={localImage.deleteImage} style={{
                                width: mobileW * 6 / 100,
                                height: mobileW * 6 / 100
                            }} />
                        </View>

                        <View style={{
                            flexDirection: 'row',
                            width: mobileW * 84 / 100, alignSelf: 'center'
                        }}>
                            <Switch
                                style={{ transform: [{ scaleX: 1.2 }, { scaleY: 1.2 }] }}
                                thumbColor={{ true: Colors.darkGreenColor, false: Colors.greyColor }}
                                value={this.state.textAreaMandatory}
                                trackColor={{ true: Colors.lightGreenColor, false: Colors.greyColor }}
                                onValueChange={(textAreaMandatory) => this.setState({ textAreaMandatory })} />
                            <Text style={{
                                paddingHorizontal: mobileW * 2 / 100,
                                paddingLeft: mobileW * 1 / 100,
                                paddingVertical: mobileW * 1 / 100,
                                color: Colors.textColor,
                                fontSize: mobileW * 3.5 / 100,
                                fontFamily: Font.montserrat_Regular
                            }}>Mandatory</Text>
                        </View>


                        <Text style={{
                            width: mobileW * 84 / 100,
                            alignSelf: 'center',
                            marginTop: mobileW * 4 / 100,
                            fontSize: mobileW * 3.5 / 100,
                            fontFamily: Font.montserrat_Bold,
                            color: Colors.textColor
                        }}>Question Title</Text>

                        <TextInput
                            keyboardType='default'
                            placeholder={'Question Text'}
                            placeholderTextColor={Colors.textColor}
                            selectionColor={Colors.textColor}
                            maxLength={50}
                            onChangeText={(input) => this.setState({ jobTitle: input })}
                            onSubmitEditing={() => { Keyboard.dismiss() }}
                            style={{
                                marginTop: mobileW * 5 / 100,
                                color: Colors.textColor,
                                alignSelf: 'center',
                                borderColor: Colors.greyColor,
                                borderWidth: 0.7,
                                paddingBottom: mobileW * 3 / 100,
                                width: mobileW * 84 / 100,
                                paddingVertical: mobileW * 3.5 / 100,
                                paddingLeft: 18,
                                fontSize: Font.fontSize4,
                                fontFamily: Font.montserrat_Regular
                            }}
                        ></TextInput>
                    </View>


                    <View style={{ flexDirection: 'row', marginTop: mobileW * 8 / 100, justifyContent: 'space-between' }}>
                        <View style={{
                            flexDirection: 'row',
                            width: mobileW * 44 / 100,
                            borderColor: Colors.darkGreenColor,
                            borderWidth: mobileW * 0.5 / 100
                        }}>
                            <View style={{
                                width: mobileW * 14 / 100,
                                justifyContent: 'center',
                                height: mobileW * 12 / 100,
                                backgroundColor: Colors.silverLightColor
                            }}>
                                <Image
                                    resizeMode={'cover'}
                                    source={localImage.downArrowIcon} style={{
                                        width: mobileW * 14 / 100,
                                        height: mobileW * 12 / 100
                                    }} />
                            </View>
                            <Text style={{
                                paddingVertical: mobileW * 3 / 100,
                                paddingLeft: mobileW * 2 / 100,
                                color: Colors.textColor,
                                fontFamily: Font.montserrat_Regular,
                                fontSize: Font.fontSize4
                            }}>Dropdown</Text>
                        </View>
                        <View style={{
                            flexDirection: 'row',
                            width: mobileW * 44 / 100,
                            borderColor: Colors.silverLightColor, borderWidth: mobileW * 0.5 / 100
                        }}>
                            <View style={{
                                width: mobileW * 14 / 100,
                                justifyContent: 'center',
                                height: mobileW * 12 / 100, backgroundColor: Colors.silverLightColor
                            }}>
                                <TouchableOpacity
                                    onPress={() => this.checkboxTermsAndCondition()}
                                    style={{
                                        alignSelf: 'center',
                                        flexDirection: 'row', width: mobileW * 10 / 100,
                                        justifyContent: 'space-between',
                                    }}>
                                    {this.state.checkbox ? <MaterialCommunityIcons name='check-box-outline'
                                        size={40}
                                        color={Colors.textColor} />
                                        : <MaterialCommunityIcons name='checkbox-blank-outline' size={40}
                                            color={Colors.textColor} />}
                                </TouchableOpacity>
                            </View>
                            <Text style={{
                                paddingVertical: mobileW * 3 / 100,
                                paddingLeft: mobileW * 2 / 100,
                                color: Colors.textColor,
                                fontFamily: Font.montserrat_Regular,
                                fontSize: Font.fontSize4
                            }}>Checkboxs</Text>
                        </View>
                    </View>

                    <View style={{ flexDirection: 'row', marginTop: mobileW * 6 / 100, justifyContent: 'space-between' }}>
                        <View style={{
                            flexDirection: 'row',
                            width: mobileW * 44 / 100,
                            borderColor: Colors.silverLightColor, borderWidth: mobileW * 0.5 / 100
                        }}>
                            <View style={{
                                width: mobileW * 14 / 100,
                                justifyContent: 'center',
                                height: mobileW * 12 / 100, backgroundColor: Colors.silverLightColor
                            }}>
                                {/* <TouchableOpacity
                                    onPress={() => this.checkboxTermsAndCondition()}
                                    style={{
                                        alignSelf: 'center',
                                        flexDirection: 'row', width: mobileW * 10 / 100,
                                        justifyContent: 'space-between',
                                    }}>
                                    {this.state.checkbox ? <MaterialCommunityIcons name='check-box-outline'
                                        size={40}
                                        color={Colors.textColor} />
                                        : <MaterialCommunityIcons name='checkbox-blank-outline' size={40}
                                            color={Colors.textColor} />}
                                </TouchableOpacity> */}
                            </View>
                            <Text style={{
                                paddingVertical: mobileW * 3 / 100,
                                paddingLeft: mobileW * 2 / 100,
                                color: Colors.textColor,
                                fontFamily: Font.montserrat_Regular,
                                fontSize: Font.fontSize4
                            }}>Number</Text>
                        </View>
                        <View style={{
                            flexDirection: 'row',
                            width: mobileW * 44 / 100,
                            borderColor: Colors.silverLightColor, borderWidth: mobileW * 0.5 / 100
                        }}>
                            <View style={{
                                width: mobileW * 14 / 100,
                                justifyContent: 'center',
                                height: mobileW * 12 / 100, backgroundColor: Colors.silverLightColor
                            }}>
                                {/* <TouchableOpacity
                                    onPress={() => this.checkboxTermsAndCondition()}
                                    style={{
                                        alignSelf: 'center',
                                        flexDirection: 'row', width: mobileW * 10 / 100,
                                        justifyContent: 'space-between',
                                    }}>
                                    {this.state.checkbox ? <MaterialCommunityIcons name='check-box-outline'
                                        size={40}
                                        color={Colors.textColor} />
                                        : <MaterialCommunityIcons name='checkbox-blank-outline' size={40}
                                            color={Colors.textColor} />}
                                </TouchableOpacity> */}
                            </View>
                            <Text style={{
                                paddingVertical: mobileW * 3 / 100,
                                paddingLeft: mobileW * 2 / 100,
                                color: Colors.textColor,
                                fontFamily: Font.montserrat_Regular,
                                fontSize: Font.fontSize4
                            }}>Text</Text>
                        </View>
                    </View>

                    <View style={{ flexDirection: 'row', marginTop: mobileW * 6 / 100, justifyContent: 'space-between' }}>
                        <View style={{
                            flexDirection: 'row',
                            width: mobileW * 44 / 100,
                            borderColor: Colors.silverLightColor, borderWidth: mobileW * 0.5 / 100
                        }}>
                            <View style={{
                                width: mobileW * 14 / 100,
                                justifyContent: 'center',
                                height: mobileW * 12 / 100, backgroundColor: Colors.silverLightColor
                            }}>
                                {/* <TouchableOpacity
                                    onPress={() => this.checkboxTermsAndCondition()}
                                    style={{
                                        alignSelf: 'center',
                                        flexDirection: 'row', width: mobileW * 10 / 100,
                                        justifyContent: 'space-between',
                                    }}>
                                    {this.state.checkbox ? <MaterialCommunityIcons name='check-box-outline'
                                        size={40}
                                        color={Colors.textColor} />
                                        : <MaterialCommunityIcons name='checkbox-blank-outline' size={40}
                                            color={Colors.textColor} />}
                                </TouchableOpacity> */}
                            </View>
                            <Text style={{
                                paddingVertical: mobileW * 3 / 100,
                                paddingLeft: mobileW * 2 / 100,
                                color: Colors.textColor,
                                fontFamily: Font.montserrat_Regular,
                                fontSize: Font.fontSize4
                            }}>Textarea</Text>
                        </View>
                        <View style={{
                            flexDirection: 'row',
                            width: mobileW * 44 / 100,
                            borderColor: Colors.silverLightColor, borderWidth: mobileW * 0.5 / 100
                        }}>
                            <View style={{
                                width: mobileW * 14 / 100,
                                justifyContent: 'center',
                                height: mobileW * 12 / 100, backgroundColor: Colors.silverLightColor
                            }}>
                                {/* <TouchableOpacity
                                    onPress={() => this.checkboxTermsAndCondition()}
                                    style={{
                                        alignSelf: 'center',
                                        flexDirection: 'row', width: mobileW * 10 / 100,
                                        justifyContent: 'space-between',
                                    }}>
                                    {this.state.checkbox ? <MaterialCommunityIcons name='check-box-outline'
                                        size={40}
                                        color={Colors.textColor} />
                                        : <MaterialCommunityIcons name='checkbox-blank-outline' size={40}
                                            color={Colors.textColor} />}
                                </TouchableOpacity> */}
                            </View>
                            <Text style={{
                                paddingVertical: mobileW * 3 / 100,
                                paddingLeft: mobileW * 2 / 100,
                                color: Colors.textColor,
                                fontFamily: Font.montserrat_Regular,
                                fontSize: Font.fontSize4
                            }}>Upload File</Text>
                        </View>
                    </View>

                    <AddButton
                        title="ADD NEW QUESTION"
                        color={Colors.whiteColor}
                        backgroundColor={Colors.darkGreenColor}
                        onPress={() => { }}
                        paddingVerticalComponent={3.5}
                        paddingVerticalText={1}
                    />
                    <AddButton
                        title="CONTINUE"
                        color={Colors.whiteColor}
                        backgroundColor={Colors.darkGreenColor}
                        onPress={() => { }}
                        paddingVerticalComponent={3.5}
                        paddingVerticalText={1}
                    />
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    screenBody: {
        marginTop: mobileW * 5 / 100,
        width: mobileW * 90 / 100,
        marginBottom: mobileW * 18 / 100,
        alignSelf: 'center',
    },
    textFieldLabel: {
        marginBottom: mobileW * 2 / 100,
        color: Colors.greyColor,
        fontSize: Font.fontSize3half,
        fontFamily: Font.montserrat_Regular
    },
    eyeButton: {
        width: mobileW * 15 / 100,
        height: mobileW * 8 / 100,
        alignItems: 'center',
        justifyContent: 'center',
        alignSelf: 'center'
    },
    showHideText: {
        color: Colors.textColor,
        fontSize: Font.fontSize3
    },
    inputStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        paddingVertical: mobileW * 3.5 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    inputHalfStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 44 / 100,
        paddingVertical: mobileW * 3 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    inputMultilineStyle: {
        textAlignVertical: 'top',
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        height: mobileW * 35 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    containerStyle: {
        width: '100%',
        alignSelf: 'center',
        marginTop: mobileW * 3 / 100,
        marginBottom: mobileW * 1 / 100,
    },
    labelStyle: {
        width: mobileW * 82 / 100, alignSelf: 'center'
    },
});
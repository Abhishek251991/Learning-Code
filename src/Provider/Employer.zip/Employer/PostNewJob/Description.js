import React, { Component } from 'react';
import { TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, Modal } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mobileH, msgProvider, msgText, config, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
import Footer from '../../../Provider/Footer';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Keyboard } from 'react-native';
import DateTimePickerModal from "react-native-modal-datetime-picker";

const JobPostHeading = ({ title, color }) => (
    <Text style={{
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Bold,
        color: color
    }}>{title}</Text>
);


const AddButton = ({ title, color, backgroundColor, onPress }) => (
    <TouchableOpacity
        activeOpacity={.7}
        onPress={onPress}
        style={{
            marginTop: mobileW * 8 / 100,
            paddingVertical: mobileW * 3.5 / 100,
            width: mobileW * 90 / 100,
            backgroundColor: backgroundColor
        }}>
        <Text style={{
            alignSelf: 'center',
            paddingVertical: mobileW * 0.8 / 100,
            color: color,
            fontSize: Font.fontSize4,
            fontFamily: Font.montserrat_Medium
        }}>
            {title}
        </Text>
    </TouchableOpacity>
);


const DATA = [
    {
        value: '1000',
    },
    {
        value: '3000',
    },
    {
        value: '5000',
    },
    {
        value: '7000',
    },
    {
        value: '9000',
    },
    {
        value: '6000',
    },
    {
        value: '11000',
    },
    {
        value: '13000',
    },
    {
        value: '15000',
    },
    {
        value: '170000',
    },
    {
        value: '19000',
    },
    {
        value: '12000',
    },
];

const JobSectorData = [
    {
        value: 'Art',
    },
    {
        value: 'Architecture',
    },
    {
        value: 'Automotive',
    },
    {
        value: 'Communication',
    },
    {
        value: 'Construction',
    },
    {
        value: 'Education',
    },
    {
        value: 'Enginerring',
    },
    {
        value: 'Facilities',
    },
    {
        value: 'Health Care',
    },
    {
        value: 'Meintence',
    }
];

const JobTypeData = [
    {
        value: 'Freelance',
    },
    {
        value: 'Full time',
    },
    {
        value: 'Part time',
    },
    {
        value: 'Temporary',
    }
];

const JobApplyTypeData = [
    {
        value: 'Internal',
    },
    {
        value: 'External URL',
    },
    {
        value: 'By Email',
    },
];

const JobSalaryData = [
    {
        value: 'Monthly',
    },
    {
        value: 'Weekly',
    },
    {
        value: 'Hourly',
    },
    {
        value: 'Negotiable',
    },
];

const JobRequiredSkillData = [
    {
        value: 'Finnance',
    },
    {
        value: 'Banking',
    },
    {
        value: 'Hospital',
    },
    {
        value: 'School',
    },
];

export default class DescriptionScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            jobTitle: '',
            jobDescription: '',
            jobSectorArray: JobSectorData,
            jobTypeArray: JobTypeData,
            JobApplyTypeArray: JobApplyTypeData,
            jobSalaryArray: JobSalaryData,
            jobRequiredSkill: JobRequiredSkillData,
            selectionListTitle: '',
            dataArray: [],
            isVisible: false,
            usertype: localStorage.getItemString('userType'),
            currentSelectedDropdown: '',
            selectedSector: 'NA',
            selectedJobType: 'NA',
            selectedJobApplyType: 'NA',
            selectedSalary: 'NA',
            selectedRequiredSkill: [],
            isDatePickerVisibleApplicationDeadline: false,
            applicationDeadline: 'NA',

            isDatePickerVisibleFoundedState: false,
            foundedDate: 'NA'

        }
    }

    setdateFoundedDate = (res1) => {
        console.log('res1', res1.getTime())
        var new_time = res1.getTime()
        let date = res1.getDate()
        let newmonthth = ''
        let newdate = ''
        let month = res1.getMonth() + 1
        if (month < 10) {
            newmonthth = '0' + month
        }
        else {
            newmonthth = month
        }
        if (date < 10) {
            newdate = '0' + date
        }
        else {
            newdate = date
        }

        let year = res1.getFullYear()
        let date1 = newmonthth + '-' + newdate + '-' + year
        let date9 = year + '-' + newmonthth + '-' + newdate

        this.setState({ foundedDate: date1, isDatePickerVisibleFoundedState: false, new_time: date9 })
    }

    setDateApplicationDeadline = (res1) => {
        console.log('res1', res1.getTime())
        var new_time = res1.getTime()
        let date = res1.getDate()
        let newmonthth = ''
        let newdate = ''
        let month = res1.getMonth() + 1
        if (month < 10) {
            newmonthth = '0' + month
        }
        else {
            newmonthth = month
        }
        if (date < 10) {
            newdate = '0' + date
        }
        else {
            newdate = date
        }

        let year = res1.getFullYear()
        let date1 = newmonthth + '-' + newdate + '-' + year
        let date9 = year + '-' + newmonthth + '-' + newdate

        this.setState({ applicationDeadline: date1, isDatePickerVisibleApplicationDeadline: false, new_time: date9 })
    }

    openListModal = (value) => {
        this.setState({ currentSelectedDropdown: value })
        switch (value) {
            case 'jobsector':
                this.setState({ dataArray: this.state.jobSectorArray })
                this.setState({ selectionListTitle: 'Select Sector' })
                break;
            case 'jobtype':
                this.setState({ dataArray: this.state.jobTypeArray })
                this.setState({ selectionListTitle: 'Select Type' })
                break;
            case 'jobapplyType':
                this.setState({ dataArray: this.state.JobApplyTypeArray })
                this.setState({ selectionListTitle: 'Select Job Apply Type' })
                break;
            case 'jobSalary':
                this.setState({ dataArray: this.state.jobSalaryArray })
                this.setState({ selectionListTitle: 'Salary' })
                break;
            case 'requiredskills':
                this.setState({ dataArray: this.state.jobRequiredSkill })
                this.setState({ selectionListTitle: 'Select Required Skils' })
                break;
        }
    }

    selectedValue = (value) => {
        console.log(this.state.currentSelectedDropdown);
        console.log(value);
        let requriedSkills = [];
        switch (this.state.currentSelectedDropdown.toLocaleLowerCase()) {
            case 'jobsector':
                this.setState({ selectedSector: value })
                break;
            case 'jobtype':
                this.setState({ selectedJobType: value })
                break;
            case 'jobapplytype':
                this.setState({ selectedJobApplyType: value })
                break;
            case 'jobsalary':
                this.setState({ selectedSalary: value })
                break;
            case 'requiredskills':
                let my_arr = this.state.selectedRequiredSkill;
                let data = { 'value': value }
                my_arr.push(data)
                this.setState({ selectedRequiredSkill: my_arr })
                console.log(this.state.selectedRequiredSkill)
                break;
        }
        this.setState({ isVisible: false });
    }

    render() {
        return (
            <View style={commonStyle.container}>

                <Modal
                    animationType={'slide'}
                    transparent={true}
                    backgroundColor={'red'}
                    visible={this.state.isVisible}
                    onRequestClose={() => { console.log("Modal Close") }}>
                    <View style={{
                        position: 'absolute',
                        bottom: 0,
                        marginTop: mobileW * 20 / 100,
                        height: '99.6%',
                        width: mobileW * 100 / 100,
                        backgroundColor: Colors.whiteColor,
                        shadowColor: '#000',
                        shadowOffset: {
                            width: 0,
                            height: 2,
                        },
                        shadowOpacity: 5,
                        shadowRadius: 5,
                        elevation: 1,
                    }}>
                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.setState({ isVisible: false }) }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>{this.state.selectionListTitle}</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={{ width: '78%' }}>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <FlatList
                            style={{ marginTop: mobileW * 2 / 100, }}
                            data={this.state.dataArray}
                            showsVerticalScrollIndicator={false}
                            renderItem={({ item, index }) => {
                                return (
                                    <TouchableOpacity activeOpacity={.7} onPress={() => { this.selectedValue(item.value) }}>
                                        <View style={{
                                            width: mobileW * 85 / 100,
                                            alignSelf: 'center',
                                            borderBottomWidth: 1,
                                            borderBottomColor: Colors.greyColor
                                        }}>
                                            <Text style={{
                                                paddingLeft: mobileW * 2.5 / 100,
                                                paddingVertical: mobileW * 4 / 100,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColor
                                            }}>{item.value}</Text>
                                        </View>
                                    </TouchableOpacity>
                                );
                            }}
                            keyExtractor={(item, index) => index.toString()}
                        />
                    </View>
                </Modal>
                {/* <ScrollView> */}
                <View style={styles.screenBody}>
                    <JobPostHeading title={'Basic Information'} color={Colors.textColor} />
                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Job Title
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Job Title'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Job Description
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                value={this.state.discription}
                                placeholder={'Job Description'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                multiline={true}
                                onChangeText={(input) => this.setState({ jobDescription: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputMultilineStyle}
                            ></TextInput>
                        </View>
                    </View>


                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Application Deadline
                            </Text>
                        </View>
                        <TouchableOpacity onPress={() => { this.setState({ isDatePickerVisibleApplicationDeadline: true }) }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <TouchableOpacity onPress={() => { this.setState({ isDatePickerVisibletwo: true }) }}>
                                        <View style={{ justifyContent: 'center' }}>
                                            <Text style={{
                                                color: Colors.textColor,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular
                                            }}>
                                                {this.state.applicationDeadline != 'NA' ? this.state.applicationDeadline : 'DD/MM/YYY'}
                                            </Text>
                                        </View>
                                    </TouchableOpacity>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <Image source={localImage.calenderImage}
                                            style={{ width: mobileW * 5.5 / 100, height: mobileW * 5.5 / 100 }} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Job Sector
                            </Text>
                        </View>

                        <TouchableOpacity onPress={() => {
                            this.openListModal('jobsector');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedSector != "NA" ? this.state.selectedSector : "Select Sector"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Job Type
                            </Text>
                        </View>

                        <TouchableOpacity onPress={() => {
                            this.openListModal('jobtype');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedJobType != "NA" ? this.state.selectedJobType : "Select Type"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>


                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Reqired Skills
                            </Text>
                        </View>
                        <TouchableOpacity onPress={() => {
                            this.openListModal('requiredskills');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    {this.state.selectedRequiredSkill.length > 0 &&
                                        <FlatList
                                            data={this.state.selectedRequiredSkill}
                                            horizontal={true}
                                            showsHorizontalScrollIndicator={false}
                                            renderItem={({ item, index }) => {
                                                return (
                                                    <View style={{ justifyContent: 'center' }}>
                                                        <Text style={{
                                                            color: Colors.whiteColor,
                                                            marginLeft: mobileW * 1 / 100,
                                                            fontSize: Font.fontSize4,
                                                            fontFamily: Font.montserrat_Regular,
                                                            backgroundColor: Colors.textColor,
                                                            paddingHorizontal: mobileW * 3 / 100, paddingVertical: mobileW * 0.5 / 100
                                                        }}>{item.value}
                                                            <Text>  X</Text>
                                                        </Text>
                                                    </View>
                                                );
                                            }}
                                            keyExtractor={(item, index) => index.toString()}
                                        />
                                    }
                                    {this.state.selectedRequiredSkill.length == 0 &&
                                        <View style={{ flexDirection: 'row', width: mobileW * 81.2 / 100, justifyContent: 'space-between' }}>
                                            <View style={{ justifyContent: 'center' }}>
                                                <Text style={{
                                                    color: Colors.textColor,
                                                    fontSize: Font.fontSize4,
                                                    fontFamily: Font.montserrat_Regular
                                                }}>
                                                    Select Reqired Skills
                                                </Text>
                                            </View>
                                            <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                                <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                            </View>
                                        </View>
                                    }
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>


                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Job Apply Type
                            </Text>
                        </View>

                        <TouchableOpacity onPress={() => {
                            this.openListModal('jobapplyType');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedJobApplyType != "NA" ? this.state.selectedJobApplyType : "Select Job Apply Type"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>


                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Founded Date
                            </Text>
                        </View>
                        <TouchableOpacity onPress={() => { this.setState({ isDatePickerVisibleFoundedState: true }) }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.foundedDate != 'NA' ? this.state.foundedDate : 'DD/MM/YYY'}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <Image source={localImage.calenderImage}
                                            style={{ width: mobileW * 5.5 / 100, height: mobileW * 5.5 / 100 }} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Salary
                            </Text>
                        </View>

                        <TouchableOpacity onPress={() => {
                            this.openListModal('jobSalary');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedSalary != "NA" ? this.state.selectedSalary : "Monthly"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={[styles.containerStyle, { flexDirection: 'row', justifyContent: 'space-between' }]}>

                        <View style={{
                            borderColor: Colors.borderColorCode,
                            flexDirection: 'row',
                            borderWidth: 0.7,
                        }}>
                            <TextInput
                                style={{
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingLeft: 18,
                                    width: mobileW * 38 / 100,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular
                                }}
                                keyboardType='default'
                                placeholder={'Min'}
                                placeholderTextColor={Colors.textColor}
                                onChangeText={(input) => this.setState({ password: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                            ></TextInput>
                            <Text style={{
                                fontSize: Font.fontSize4half,
                                textAlignVertical: 'center', marginRight: mobileW * 3 / 100
                            }}>$</Text>
                        </View>
                        <View style={{
                            borderColor: Colors.borderColorCode,
                            flexDirection: 'row',
                            borderWidth: 0.7,
                        }}>
                            <TextInput
                                style={{
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingLeft: 18,
                                    width: mobileW * 38 / 100,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular
                                }}
                                keyboardType='default'
                                placeholder={'Max'}
                                placeholderTextColor={Colors.textColor}
                                onChangeText={(input) => this.setState({ password: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                            ></TextInput>
                            <Text style={{
                                fontSize: Font.fontSize4half,
                                textAlignVertical: 'center', marginRight: mobileW * 3 / 100
                            }}>$</Text>
                        </View>
                    </View>

                    {/* Salary currency and Salary position  */}
                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <View style={{ flexDirection: 'row', }}>
                                <Text style={[styles.textFieldLabel, { width: mobileW * 46.5 / 100, }]}>

                                    Salary currency
                                </Text>
                                <Text style={styles.textFieldLabel}>
                                    Salary position
                                </Text>
                            </View>
                        </View>
                        <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <View style={{
                                        color: Colors.textColor,
                                        alignSelf: 'center',
                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                        borderWidth: 0.7,
                                        width: mobileW * 44 / 100,
                                        paddingVertical: mobileW * 3.5 / 100,
                                        paddingHorizontal: 18,
                                        fontSize: Font.fontSize4,
                                        fontFamily: Font.montserrat_Regular,
                                        flexDirection: 'row',
                                        justifyContent: 'space-between'
                                    }}>
                                        <View style={{ justifyContent: 'center' }}>
                                            <Text style={{
                                                color: Colors.textColor,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular
                                            }}>
                                                Default
                                            </Text>
                                        </View>
                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                        </View>
                                    </View>
                                    <View style={{
                                        color: Colors.textColor,
                                        alignSelf: 'center',
                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                        borderWidth: 0.7,
                                        width: mobileW * 44 / 100,
                                        paddingVertical: mobileW * 3.5 / 100,
                                        paddingHorizontal: 18,
                                        fontSize: Font.fontSize4,
                                        fontFamily: Font.montserrat_Regular,
                                        flexDirection: 'row',
                                        justifyContent: 'space-between'
                                    }}>
                                        <View style={{ justifyContent: 'center' }}>
                                            <Text style={{
                                                color: Colors.textColor,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular
                                            }}>
                                                Left
                                            </Text>
                                        </View>
                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                        </View>
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    {/* Salary currency and Salary position  */}
                    {/* thousand seprator and number of decimals  */}
                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <View style={{ flexDirection: 'row', }}>
                                <Text style={[styles.textFieldLabel, { width: mobileW * 46.5 / 100, }]}>

                                    Thousand seprator
                                </Text>
                                <Text style={styles.textFieldLabel}>
                                    Number of Decimals
                                </Text>
                            </View>
                        </View>
                        <TouchableOpacity onPress={() => { }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                    <View style={{
                                        color: Colors.textColor,
                                        alignSelf: 'center',
                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                        borderWidth: 0.7,
                                        width: mobileW * 44 / 100,
                                        paddingVertical: mobileW * 3.5 / 100,
                                        paddingHorizontal: 18,
                                        fontSize: Font.fontSize4,
                                        fontFamily: Font.montserrat_Regular,
                                        flexDirection: 'row',
                                        justifyContent: 'space-between'
                                    }}>
                                        <View style={{ justifyContent: 'center' }}>
                                            <Text style={{
                                                color: Colors.textColor,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular
                                            }}>
                                                ,
                                            </Text>
                                        </View>
                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                        </View>
                                    </View>
                                    <View style={{
                                        color: Colors.textColor,
                                        alignSelf: 'center',
                                        borderColor: this.state.isOpenPostDateVisiable == true ? Colors.darkGreenColor : Colors.greyColor,
                                        borderWidth: 0.7,
                                        width: mobileW * 44 / 100,
                                        paddingVertical: mobileW * 3.5 / 100,
                                        paddingHorizontal: 18,
                                        fontSize: Font.fontSize4,
                                        fontFamily: Font.montserrat_Regular,
                                        flexDirection: 'row',
                                        justifyContent: 'space-between'
                                    }}>
                                        <View style={{ justifyContent: 'center' }}>
                                            <Text style={{
                                                color: Colors.textColor,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular
                                            }}>
                                                2
                                            </Text>
                                        </View>
                                        <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                            <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                        </View>
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>
                    {/* thousand seprator and number of decimals  */}

                    <AddButton
                        title="CONTINUE"
                        color={Colors.whiteColor}
                        backgroundColor={Colors.darkGreenColor}
                        onPress={() => { this.descriptionAPICall() }}
                    />

                </View>
                <DateTimePickerModal
                    isVisible={this.state.isDatePickerVisibleApplicationDeadline}
                    //  mode="date"
                    //  minimumDate={new Date()}
                    mode="date"
                    is24Hour={true}
                    display="default"
                    onConfirm={(date) => { this.setDateApplicationDeadline(date), this.setState({ isDatePickerVisibleApplicationDeadline: false }) }}
                    onCancel={() => { this.setState({ isDatePickerVisibleApplicationDeadline: false }) }}
                />
                <DateTimePickerModal
                    isVisible={this.state.isDatePickerVisibleFoundedState}
                    //  mode="date"
                    //  minimumDate={new Date()}
                    mode="date"
                    is24Hour={true}
                    display="default"
                    onConfirm={(date) => { this.setdateFoundedDate(date), this.setState({ isDatePickerVisibleFoundedState: false }) }}
                    onCancel={() => { this.setState({ isDatePickerVisibleFoundedState: false }) }}
                />
            </View>
        );
    }
    descriptionAPICall() {
        //     emptyJobTitle = ['Please enter job title'];
        // emptyJobDescription = ['Please enter job description'];
        // emptySelectDateApplicationaeadline = ['Please select application deadline date'];
        // emptySelectJobType = ['Please select job type'];
        // emptySelectJobSector = ['Please select job sector'];
        // emptySelectJobRequiredSkills = ['Please select reqiured skills'];
        // emptySelectJobApplyType = ['Please select apply type'];
        // emptySelectFoundedDate = ['Please select founded date'];
        // emptySelectJobSalary = ['Please select salary'];
        let jobTitle = this.state.jobTitle.trim();
        if (jobTitle.length <= 0) {
            msgProvider.toast(msgText.emptyJobTitle[config.language], 'center')
            return false;
        }
        let jobDescription = this.state.jobDescription.trim();
        if (jobDescription.length <= 0) {
            msgProvider.toast(msgText.emptyJobDescription[config.language], 'center')
            return false;
        }
        let applicationDeadline = this.state.applicationDeadline.trim();
        if (applicationDeadline.length <= 0) {
            msgProvider.toast(msgText.emptySelectDateApplicationaeadline[config.language], 'center')
            return false;
        }
        let selectedSector = this.state.selectedSector.trim();
        if (selectedSector.length <= 0) {
            msgProvider.toast(msgText.emptyEmailAddress[config.language], 'center')
            return false;
        }
        let selectedJobTypeselectedSector = this.state.selectedJobType.trim();
        if (selectedJobType.length <= 0) {
            msgProvider.toast(msgText.emptyEmailAddress[config.language], 'center')
            return false;
        }
        let selectedRequiredSkill = this.state.selectedRequiredSkill.trim();
        if (selectedRequiredSkill.length <= 0) {
            msgProvider.toast(msgText.emptyEmailAddress[config.language], 'center')
            return false;
        }
        let selectedJobApplyType = this.state.selectedJobApplyType.trim();
        if (selectedJobApplyType.length <= 0) {
            msgProvider.toast(msgText.emptyEmailAddress[config.language], 'center')
            return false;
        }
        let foundedDate = this.state.foundedDate.trim();
        if (foundedDate.length <= 0) {
            msgProvider.toast(msgText.emptyEmailAddress[config.language], 'center')
            return false;
        }
        let selectedSalary = this.state.selectedSalary.trim();
        if (selectedSalary.length <= 0) {
            msgProvider.toast(msgText.emptyEmailAddress[config.language], 'center')
            return false;
        }
    }
}

const styles = StyleSheet.create({
    screenBody: {
        marginTop: mobileW * 5 / 100,
        width: mobileW * 90 / 100,
        marginBottom: mobileW * 18 / 100,
        alignSelf: 'center',
    },
    textFieldLabel: {
        marginBottom: mobileW * 2 / 100,
        color: Colors.greyColor,
        fontSize: Font.fontSize3half,
        fontFamily: Font.montserrat_Regular
    },
    eyeButton: {
        width: mobileW * 15 / 100,
        height: mobileW * 8 / 100,
        alignItems: 'center',
        justifyContent: 'center',
        alignSelf: 'center'
    },
    showHideText: {
        color: Colors.textColor,
        fontSize: Font.fontSize3
    },
    inputStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        paddingVertical: mobileW * 3.5 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    inputHalfStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 44 / 100,
        paddingVertical: mobileW * 3 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    inputMultilineStyle: {
        textAlignVertical: 'top',
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        height: mobileW * 35 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    containerStyle: {
        width: '100%',
        marginTop: mobileW * 3 / 100,
        marginBottom: mobileW * 1 / 100,
    },
    labelStyle: {
        width: mobileW * 82 / 100, alignSelf: 'center'
    },
});

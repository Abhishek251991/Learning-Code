import React, { Component } from 'react';
import { TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, Modal } from 'react-native';
import { mobileW, commonStyle, Cameragallery, msgProvider, msgText, config, mediaprovider, mobileH, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
import Entypo from 'react-native-vector-icons/Entypo';
import { ImageBackground } from 'react-native';

const JobPostHeading = ({ title, color }) => (
    <Text style={{
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Bold,
        color: color
    }}>{title}</Text>
);


const AddButton = ({ title, color, backgroundColor, onPress }) => (
    <TouchableOpacity
        activeOpacity={.7}
        onPress={onPress}
        style={{
            marginTop: mobileW * 9 / 100,
            paddingVertical: mobileW * 3.5 / 100,
            width: mobileW * 90 / 100,
            backgroundColor: backgroundColor
        }}>
        <Text style={{
            alignSelf: 'center',
            paddingVertical: mobileW * 0.8 / 100,
            color: color,
            fontSize: Font.fontSize4,
            fontFamily: Font.montserrat_Medium
        }}>
            {title}
        </Text>
    </TouchableOpacity>
);

export default class FileAttachementScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            profileImageFirst: 'NA',
            cameraOnFirst: false,
            mediaModalFirst: false,

            profileImageSecond: 'NA',
            cameraOnSecond: false,
            mediaModalSecond: false,

            profileImageThird: 'NA',
            cameraOnThird: false,
            mediaModalThird: false,
        }
    }

    _openCamera = (value) => {
        mediaprovider.launchCamera().then((obj) => {
            console.log(obj.path);
            switch (value) {
                case 'first':
                    this.setState({ profileImageFirst: obj.path, mediaModalFirst: false, cameraOnFirst: true })
                    break;
                case 'second':
                    this.setState({ profileImageSecond: obj.path, mediaModalSecond: false, cameraOnSecond: true })
                    break;
                case 'third':
                    this.setState({ profileImageThird: obj.path, mediaModalThird: false, cameraOnThird: true, })
                    break;
            }
        })
    }
    _openGellery = (value) => {
        mediaprovider.launchGellery().then((obj) => {
            console.log(obj.path);
            switch (value) {
                case 'first':
                    this.setState({ profileImageFirst: obj.path, mediaModalFirst: false, cameraOnFirst: true, })
                    break;
                case 'second':
                    this.setState({ profileImageSecond: obj.path, mediaModalSecond: false, cameraOnSecond: true, })
                    break;
                case 'third':
                    this.setState({ profileImageThird: obj.path, mediaModalThird: false, cameraOnThird: true, })
                    break;
            }
        })
    }

    render() {
        return (
            <View style={commonStyle.container}>
                <View style={styles.screenBody}>
                    <JobPostHeading title="File Attachment" color={Colors.textColor} />
                    <View style={{ marginTop: mobileW * 2 / 100 }}>
                        <JobPostHeading title="UPLOAD FILES" color={Colors.greyColor} />
                    </View>

                    <Cameragallery mediamodal={this.state.mediaModalFirst} Camerapopen={() => { this._openCamera('first') }}
                        Galleryopen={() => { this._openGellery('first') }} Canclemedia={() => { this.setState({ mediaModalFirst: false }) }}
                    />
                    <Cameragallery mediamodal={this.state.mediaModalSecond} Camerapopen={() => { this._openCamera('second') }}
                        Galleryopen={() => { this._openGellery('second') }} Canclemedia={() => { this.setState({ mediaModalSecond: false }) }}
                    />
                    <Cameragallery mediamodal={this.state.mediaModalThird} Camerapopen={() => { this._openCamera('third') }}
                        Galleryopen={() => { this._openGellery('third') }} Canclemedia={() => { this.setState({ mediaModalThird: false }) }}
                    />

                    <View style={{ flexDirection: 'row', marginTop: mobileW * 6 / 100, justifyContent: 'space-between' }}>
                        {
                            this.state.cameraOnFirst == true ?
                                <TouchableOpacity style={styles.imageCardStyle} onPress={() => { this.setState({ mediaModalFirst: true }) }} activeOpacity={.7}>
                                    <ImageBackground
                                        style={{ height: mobileW * 28 / 100, width: mobileW * 29 / 100 }}
                                        source={{ uri: this.state.profileImageFirst }}
                                        borderRadius={mobileW * 3 / 100}
                                        resizeMode={'cover'}
                                    >
                                        <TouchableOpacity onPress={() => {
                                            this.setState({ profileImageFirst: 'NA', cameraOnFirst: false })
                                        }} activeOpacity={.7}>
                                            <Entypo name='circle-with-cross' style={styles.crossRedStyle} size={28} color={Colors.lightRedColor} />
                                        </TouchableOpacity>
                                    </ImageBackground>
                                </TouchableOpacity> :
                                <TouchableOpacity onPress={() => { this.setState({ mediaModalFirst: true }) }} activeOpacity={.7}>
                                    <View style={styles.imageCardStyle}>
                                        <Entypo name='plus' size={40} color={Colors.greyColor} />
                                    </View>
                                </TouchableOpacity>
                        }
                        {
                            this.state.cameraOnSecond == true ?
                                <TouchableOpacity style={styles.imageCardStyle} onPress={() => { this.setState({ mediaModalSecond: true }) }} activeOpacity={.7}>
                                    <ImageBackground
                                        style={{ height: mobileW * 28 / 100, width: mobileW * 29 / 100 }}
                                        source={{ uri: this.state.profileImageSecond }}
                                        borderRadius={mobileW * 3 / 100}
                                        resizeMode={'cover'}
                                    >
                                        <TouchableOpacity onPress={() => {
                                            this.setState({ profileImageSecond: 'NA', cameraOnSecond: false })
                                        }} activeOpacity={.7}>
                                            <Entypo name='circle-with-cross' style={styles.crossRedStyle}
                                                size={30} color={Colors.lightRedColor} />
                                        </TouchableOpacity>
                                    </ImageBackground>
                                </TouchableOpacity> :
                                <TouchableOpacity onPress={() => { this.setState({ mediaModalSecond: true }) }} activeOpacity={.7}>
                                    <View style={styles.imageCardStyle}>
                                        <Entypo name='plus' size={40} color={Colors.greyColor} />
                                    </View>
                                </TouchableOpacity>
                        }
                        {
                            this.state.cameraOnThird == true ?
                                <TouchableOpacity style={styles.imageCardStyle} onPress={() => { this.setState({ mediaModalThird: true }) }} activeOpacity={.7}>
                                    <ImageBackground
                                        style={{ height: mobileW * 28 / 100, width: mobileW * 29 / 100 }}
                                        source={{ uri: this.state.profileImageThird }}
                                        borderRadius={mobileW * 3 / 100}
                                        resizeMode={'cover'}
                                    >
                                        <TouchableOpacity onPress={() => {
                                            this.setState({ profileImageThird: 'NA', cameraOnThird: false })
                                        }} activeOpacity={.7}>
                                            <Entypo name='circle-with-cross' style={styles.crossRedStyle} size={30} color={Colors.lightRedColor} />
                                        </TouchableOpacity>
                                    </ImageBackground>
                                </TouchableOpacity> :
                                <TouchableOpacity onPress={() => { this.setState({ mediaModalThird: true }) }} activeOpacity={.7}>
                                    <View style={styles.imageCardStyle}>
                                        <Entypo name='plus' size={40} color={Colors.greyColor} />
                                    </View>
                                </TouchableOpacity>
                        }
                    </View>
                    <AddButton
                        title='CONTINUE'
                        color={Colors.whiteColor}
                        backgroundColor={Colors.darkGreenColor}
                        onPress={() => { this.fileAttachmentCallApi() }} />
                </View>
            </View>
        )
    }
    fileAttachmentCallApi() {
        let selectedImageFirst = this.state.cameraOnFirst;

        if (selectedImageFirst != true) {
            msgProvider.toast(msgText.selectAtLeastOneImage[config.language], 'center')
            return false;
        }
    }
}

const styles = StyleSheet.create({
    screenBody: {
        marginTop: mobileW * 5 / 100,
        width: mobileW * 90 / 100,
        marginBottom: mobileW * 18 / 100,
        alignSelf: 'center',
    },
    imageCardStyle: {
        height: mobileW * 28 / 100,
        width: mobileW * 29 / 100,
        borderRadius: mobileW * 3 / 100,
        backgroundColor: Colors.whiteColor,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.5,
        shadowRadius: 0.5,
        elevation: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    textFieldLabel: {
        marginBottom: mobileW * 2 / 100,
        color: Colors.greyColor,
        fontSize: Font.fontSize3half,
        fontFamily: Font.montserrat_Regular
    },
    eyeButton: {
        width: mobileW * 15 / 100,
        height: mobileW * 8 / 100,
        alignItems: 'center',
        justifyContent: 'center',
        alignSelf: 'center'
    },
    showHideText: {
        color: Colors.textColor,
        fontSize: Font.fontSize3
    },
    crossRedStyle: {
        borderRadius: mobileW * 4 / 100,
        backgroundColor: 'white',
        color: Colors.redColor,
        alignSelf: 'flex-end'
    },
    inputStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        paddingVertical: mobileW * 3.5 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    inputHalfStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 44 / 100,
        paddingVertical: mobileW * 3 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    inputMultilineStyle: {
        textAlignVertical: 'top',
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        height: mobileW * 35 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
    containerStyle: {
        width: '100%',
        marginTop: mobileW * 3 / 100,
        marginBottom: mobileW * 1 / 100,
    },
    labelStyle: {
        width: mobileW * 82 / 100, alignSelf: 'center'
    },
});

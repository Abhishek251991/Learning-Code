import React, { Component } from 'react';
import { TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, Modal } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
import Footer from '../../../Provider/Footer';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Keyboard } from 'react-native';

const JobPostHeading = ({ title, color }) => (
    <Text style={{
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Bold,
        color: color
    }}>{title}</Text>
);

const DropDownListLabel = ({ lable }) => (
    <View style={styles.labelStyle}>
        <Text style={styles.textFieldLabel}>
            {lable}
        </Text>
    </View>
);


const AddButton = ({ title, color, backgroundColor, onPress }) => (
    <TouchableOpacity
        activeOpacity={.7}
        onPress={onPress}
        style={{
            marginTop: mobileW * 8 / 100,
            paddingVertical: mobileW * 3.5 / 100,
            width: mobileW * 90 / 100,
            backgroundColor: backgroundColor
        }}>
        <Text style={{
            alignSelf: 'center',
            paddingVertical: mobileW * 0.8 / 100,
            color: color,
            fontSize: Font.fontSize4,
            fontFamily: Font.montserrat_Medium
        }}>
            {title}
        </Text>
    </TouchableOpacity>

);


const OfferedSalaryArray = [
    {
        value: '1000',
    },
    {
        value: '3000',
    },
    {
        value: '5000',
    },
    {
        value: '7000',
    },
    {
        value: '9000',
    },
    {
        value: '6000',
    },
    {
        value: '11000',
    },
    {
        value: '13000',
    },
    {
        value: '15000',
    },
    {
        value: '170000',
    },
    {
        value: '19000',
    },
    {
        value: '12000',
    },
];

const CareerLevel = [
    {
        value: 'Manager',
    },
    {
        value: 'Officer',
    },
    {
        value: 'Student',
    },
    {
        value: 'Executive',
    },
    {
        value: 'Others',
    },
];


const Experience = [
    {
        value: 'Fresher',
    },
    {
        value: 'Less Then 1 Year',
    },
    {
        value: '2 Year',
    },
    {
        value: '3 Year',
    },
    {
        value: '4 Year',
    },
    {
        value: '5 Year',
    },
    {
        value: '6 Year',
    },
    {
        value: '7 Year',
    },
    {
        value: '8 Year+',
    },
];


const Gender = [
    {
        value: 'Male',
    },
    {
        value: 'Female',
    },
];

const Industry = [
    {
        value: 'Development',
    },
    {
        value: 'Management',
    },
    {
        value: 'Finnance',
    },
    {
        value: 'Html Development',
    },
    {
        value: 'Seo',
    },
    {
        value: 'Banking',
    },
    {
        value: 'Graphic Designing',
    },
    {
        value: 'Php Development',
    },
];


const Quatifications = [
    {
        value: 'Certificate',
    },
    {
        value: 'Diploma',
    },
    {
        value: 'Associate',
    },
    {
        value: 'Degree Bachlelor',
    },
    {
        value: "Master's Degree",
    },
    {
        value: 'Medical',
    },
];


export default class OtherInformationScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isVisible: false,

            offeredSalaryArray: OfferedSalaryArray,
            selectedOfferedSalary: 'NA',

            careerLevel: CareerLevel,
            selectedCarrerLevel: 'NA',

            experienceArray: Experience,
            selectedExperince: 'NA',

            genderArray: Gender,
            selectedGender: 'NA',

            industryArray: Industry,
            selectedIndustry: 'NA',

            quatificationsArray: Quatifications,
            selectedQualifications: 'NA',

            selectionListTitle: '',
            currentSelectedDropdown: '',
            dataArray: [],
        }
    }
    openListModal = (value) => {
        this.setState({ currentSelectedDropdown: value })
        switch (value) {
            case 'offeredsalary':
                this.setState({ dataArray: this.state.offeredSalaryArray })
                this.setState({ selectionListTitle: 'Offered Salary' })
                break;
            case 'careerlevel':
                this.setState({ dataArray: this.state.careerLevel })
                this.setState({ selectionListTitle: 'Career Level' })
                break;
            case 'experince':
                this.setState({ dataArray: this.state.experienceArray })
                this.setState({ selectionListTitle: 'Experince' })
                break;
            case 'gender':
                this.setState({ dataArray: this.state.genderArray })
                this.setState({ selectionListTitle: 'Gender' })
                break;
            case 'industry':
                this.setState({ dataArray: this.state.industryArray })
                this.setState({ selectionListTitle: 'Industry' })
                break;
            case 'qualififcations':
                this.setState({ dataArray: this.state.quatificationsArray })
                this.setState({ selectionListTitle: 'Qualifications' })
                break;
        }
    }
    selectedValue = (value) => {
        console.log(this.state.currentSelectedDropdown);
        console.log(value);
        let requriedSkills = [];
        switch (this.state.currentSelectedDropdown.toLocaleLowerCase()) {
            case 'offeredsalary':
                this.setState({ selectedOfferedSalary: value })
                break;
            case 'careerlevel':
                this.setState({ selectedCarrerLevel: value })
                break;
            case 'experince':
                this.setState({ selectedExperince: value })
                break;
            case 'gender':
                this.setState({ selectedGender: value })
                break;
            case 'industry':
                this.setState({ selectedIndustry: value })
                break;
            case 'qualififcations':
                this.setState({ selectedQualifications: value })
                break;
        }
        this.setState({ isVisible: false });
    }
    render() {
        return (
            <View style={commonStyle.container}>
                <Modal
                    animationType={'slide'}
                    transparent={true}
                    backgroundColor={'red'}
                    visible={this.state.isVisible}
                    onRequestClose={() => { console.log("Modal Close") }}>
                    <View style={{
                        position: 'absolute',
                        bottom: 0,
                        marginTop: mobileW * 20 / 100,
                        height: '99.6%',
                        width: mobileW * 100 / 100,
                        backgroundColor: Colors.whiteColor,
                        shadowColor: '#000',
                        shadowOffset: {
                            width: 0,
                            height: 2,
                        },
                        shadowOpacity: 5,
                        shadowRadius: 5,
                        elevation: 1,
                    }}>
                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.setState({ isVisible: false }) }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>{this.state.selectionListTitle}</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={{ width: '78%' }}>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <FlatList
                            style={{ marginTop: mobileW * 2 / 100, }}
                            data={this.state.dataArray}
                            showsVerticalScrollIndicator={false}
                            renderItem={({ item, index }) => {
                                return (
                                    <TouchableOpacity activeOpacity={.7} onPress={() => { this.selectedValue(item.value) }}>
                                        <View style={{
                                            width: mobileW * 85 / 100,
                                            alignSelf: 'center',
                                            borderBottomWidth: 1,
                                            borderBottomColor: Colors.greyColor
                                        }}>
                                            <Text style={{
                                                paddingLeft: mobileW * 2.5 / 100,
                                                paddingVertical: mobileW * 4 / 100,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColor
                                            }}>{item.value}</Text>
                                        </View>
                                    </TouchableOpacity>
                                );
                            }}
                            keyExtractor={(item, index) => index.toString()}
                        />
                    </View>
                </Modal>
                <View style={styles.screenBody}>
                    <JobPostHeading title={'Other Information'} color={Colors.textColor} />

                    <View style={styles.containerStyle}>
                        <DropDownListLabel lable="Offered Salary" />
                        <TouchableOpacity onPress={() => {
                            this.openListModal('offeredsalary');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedOfferedSalary != "NA" ? this.state.selectedOfferedSalary : "Offered Salary"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <DropDownListLabel lable="Career Level" />
                        <TouchableOpacity onPress={() => {
                            this.openListModal('careerlevel');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedCarrerLevel != "NA" ? this.state.selectedCarrerLevel : "Career Level"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>


                    <View style={styles.containerStyle}>
                        <DropDownListLabel lable="Experince" />
                        <TouchableOpacity onPress={() => {
                            this.openListModal('experince');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedExperince != "NA" ? this.state.selectedExperince : "Experince"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <DropDownListLabel lable="Gender" />
                        <TouchableOpacity onPress={() => {
                            this.openListModal('gender');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedGender != "NA" ? this.state.selectedGender : "Gender"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <DropDownListLabel lable="Industry" />
                        <TouchableOpacity onPress={() => {
                            this.openListModal('industry');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedIndustry != "NA" ? this.state.selectedIndustry : "Industry"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <DropDownListLabel lable="Qualifications" />
                        <TouchableOpacity onPress={() => {
                            this.openListModal('qualififcations');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedQualifications != "NA" ? this.state.selectedQualifications : "Qualifications"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>


                    <AddButton
                        title="CONTINUE"
                        color={Colors.whiteColor}
                        backgroundColor={Colors.darkGreenColor}
                        onPress={() => { }}
                    />
                </View>
            </View>


        )
    }
}

const styles = StyleSheet.create({
    screenBody: {
        marginTop: mobileW * 5 / 100,
        width: mobileW * 90 / 100,
        marginBottom: mobileW * 18 / 100,
        alignSelf: 'center',
    },
    labelStyle: {
        width: mobileW * 82 / 100, alignSelf: 'center'
    },
    textFieldLabel: {
        marginBottom: mobileW * 2 / 100,
        color: Colors.greyColor,
        fontSize: Font.fontSize3half,
        fontFamily: Font.montserrat_Regular
    },
    containerStyle: {
        width: '100%',
        marginTop: mobileW * 3 / 100,
        marginBottom: mobileW * 1 / 100,
    },
});
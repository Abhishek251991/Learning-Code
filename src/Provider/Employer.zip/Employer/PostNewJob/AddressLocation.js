import React, { Component } from 'react';
import { TextInput, Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View, Modal } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../../Provider/utilslib/Utils';
import Footer from '../../../Provider/Footer';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { Keyboard } from 'react-native';

const JobPostHeading = ({ title, color }) => (
    <Text style={{
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Bold,
        color: color
    }}>{title}</Text>
);

const AddButton = ({ title, color, backgroundColor, onPress }) => (
    <TouchableOpacity
        activeOpacity={.7}
        onPress={onPress}
        style={{
            marginTop: mobileW * 6 / 100,
            paddingVertical: mobileW * 2.6 / 100,
            width: mobileW * 32 / 100,
            backgroundColor: backgroundColor
        }}>
        <Text style={{
            alignSelf: 'center',
            paddingVertical: mobileW * 0.8 / 100,
            color: color,
            fontSize: Font.fontSize4,
            fontFamily: Font.montserrat_Medium
        }}>
            {title}
        </Text>
    </TouchableOpacity>
);


const DropDownListLabel = ({ lable }) => (
    <View style={styles.labelStyle}>
        <Text style={styles.textFieldLabel}>
            {lable}
        </Text>
    </View>
);


const CountryData = [
    {
        value: 'Afganishtan',
    },
    {
        value: 'Albania',
    },
    {
        value: 'Algeria',
    },
    {
        value: 'Andorra',
    },
    {
        value: 'Austria',
    },
    {
        value: 'Bangladesh',
    },
    {
        value: 'Barbados',
    },
    {
        value: 'Brazil',
    },
    {
        value: 'Greece',
    },
];


const StateData = [
    {
        value: 'Kabul',
    },
    {
        value: 'Kandhar',
    },
    {
        value: 'Kapisa',
    },
    {
        value: 'Kunar',
    },
    {
        value: "Samangan",
    },
    {
        value: 'Uruzagan',
    },
    {
        value: 'Parwan',
    },
    {
        value: 'Takhar',
    },
];


const cityData = [
    {
        value: 'Herat',
    },
    {
        value: 'Jalalabad',
    },
    {
        value: 'Khandahar',
    },
    {
        value: 'Puli Khumri',
    },
    {
        value: "Charikar",
    },
    {
        value: 'Lashkargah',
    },
    {
        value: 'Sheberghan',
    },
    {
        value: 'Ghazni',
    },
    {
        value: 'Miharlam',
    },
];
export default class AddressLocationScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isVisible: false,

            countryArray: CountryData,
            selectedCountry: 'NA',

            stateArray: StateData,
            selectedState: 'NA',

            cityArray: cityData,
            selectedCity: 'NA',

            selectionListTitle: '',
            currentSelectedDropdown: '',
            dataArray: [],
            checkbox: true
        }
    }
    checkboxTermsAndCondition = () => {
        if (this.state.checkbox) {
            this.setState({ checkbox: false })
        } else {
            this.setState({ checkbox: true })
        }
    }
    openListModal = (value) => {
        this.setState({ currentSelectedDropdown: value })
        switch (value) {
            case 'country':
                this.setState({ dataArray: this.state.countryArray })
                this.setState({ selectionListTitle: 'Select Country' })
                break;
            case 'state':
                this.setState({ dataArray: this.state.stateArray })
                this.setState({ selectionListTitle: 'Select State' })
                break;
            case 'city':
                this.setState({ dataArray: this.state.cityArray })
                this.setState({ selectionListTitle: 'Select City' })
                break;
        }
    }
    selectedValue = (value) => {
        console.log(this.state.currentSelectedDropdown);
        console.log(value);
        let requriedSkills = [];
        switch (this.state.currentSelectedDropdown.toLocaleLowerCase()) {
            case 'country':
                this.setState({ selectedCountry: value })
                break;
            case 'state':
                this.setState({ selectedState: value })
                break;
            case 'city':
                this.setState({ selectedCity: value })
                break;
        }
        this.setState({ isVisible: false });
    }

    render() {
        return (
            <View style={commonStyle.container}>
                <Modal
                    animationType={'slide'}
                    transparent={true}
                    backgroundColor={'red'}
                    visible={this.state.isVisible}
                    onRequestClose={() => { console.log("Modal Close") }}>
                    <View style={{
                        position: 'absolute',
                        bottom: 0,
                        marginTop: mobileW * 20 / 100,
                        height: '99.6%',
                        width: mobileW * 100 / 100,
                        backgroundColor: Colors.whiteColor,
                        shadowColor: '#000',
                        shadowOffset: {
                            width: 0,
                            height: 2,
                        },
                        shadowOpacity: 5,
                        shadowRadius: 5,
                        elevation: 1,
                    }}>
                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.setState({ isVisible: false }) }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>{this.state.selectionListTitle}</Text>
                            </View>
                            <TouchableOpacity onPress={() => { }} style={{ width: '78%' }}>
                            </TouchableOpacity>
                        </View>
                        {/* App Bar End  */}
                        <View style={{
                            width: mobileW * 90 / 100,
                            alignSelf: 'center',
                            backgroundColor: Colors.whiteColor,
                            shadowColor: '#000',
                            shadowOffset: {
                                width: 0,
                                height: 2,
                            },
                            shadowOpacity: 5,
                            shadowRadius: 5,
                            elevation: 1,
                        }}>
                            <View style={{ flexDirection: 'row' }}>
                                <View style={{ width: mobileW * 15 / 100 }}>
                                    <Image source={localImage.searchIcon} style={{
                                        height: mobileW * 11.5 / 100,
                                        width: mobileW * 10 / 100
                                    }}
                                        resizeMode={'cover'}
                                    />
                                </View>
                                <View style={{ width: mobileW * 75 / 100 }}>
                                    <TextInput />
                                </View>
                            </View>
                        </View>
                        <FlatList
                            style={{ marginTop: mobileW * 2 / 100, }}
                            data={this.state.dataArray}
                            showsVerticalScrollIndicator={false}
                            renderItem={({ item, index }) => {
                                return (
                                    <TouchableOpacity activeOpacity={.7} onPress={() => { this.selectedValue(item.value) }}>
                                        <View style={{
                                            width: mobileW * 85 / 100,
                                            alignSelf: 'center',
                                            borderBottomWidth: 1,
                                            borderBottomColor: Colors.greyColor
                                        }}>
                                            <Text style={{
                                                paddingLeft: mobileW * 2.5 / 100,
                                                paddingVertical: mobileW * 4 / 100,
                                                fontSize: Font.fontSize4,
                                                fontFamily: Font.montserrat_Regular,
                                                color: Colors.textColor
                                            }}>{item.value}</Text>
                                        </View>
                                    </TouchableOpacity>
                                );
                            }}
                            keyExtractor={(item, index) => index.toString()}
                        />
                    </View>
                </Modal>
                <View style={styles.screenBody}>
                    <JobPostHeading title={'Address / Location'} color={Colors.textColor} />

                    <View style={styles.containerStyle}>
                        <DropDownListLabel lable="Country" />
                        <TouchableOpacity onPress={() => {
                            this.openListModal('country');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedCountry != "NA" ? this.state.selectedCountry : "Select Country"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <DropDownListLabel lable="State" />
                        <TouchableOpacity onPress={() => {
                            this.openListModal('state');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedState != "NA" ? this.state.selectedState : "Select State"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <DropDownListLabel lable="City" />
                        <TouchableOpacity onPress={() => {
                            this.openListModal('city');
                            this.setState({ isVisible: !this.state.isVisible })
                        }} activeOpacity={.7}>
                            <View style={{ width: '100%', marginBottom: mobileW * 1 / 100, }}>
                                <View style={{
                                    color: Colors.textColor,
                                    alignSelf: 'center',
                                    borderColor: Colors.greyColor,
                                    borderWidth: 0.7,
                                    width: mobileW * 90 / 100,
                                    paddingVertical: mobileW * 3.5 / 100,
                                    paddingHorizontal: 18,
                                    fontSize: Font.fontSize4,
                                    fontFamily: Font.montserrat_Regular,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between'
                                }}>
                                    <View style={{ justifyContent: 'center' }}>
                                        <Text style={{
                                            color: Colors.textColor,
                                            fontSize: Font.fontSize4,
                                            fontFamily: Font.montserrat_Regular
                                        }}>
                                            {this.state.selectedCity != "NA" ? this.state.selectedCity : "Select City"}
                                        </Text>
                                    </View>
                                    <View style={{ justifyContent: 'center', alignSelf: 'center' }}>
                                        <MaterialCommunityIcons name='menu-down' size={30} color={Colors.textColor} />
                                    </View>
                                </View>
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Full Address
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Address'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>
                    <View style={styles.containerStyle}>
                        <View style={styles.labelStyle}>
                            <Text style={styles.textFieldLabel}>
                                Postal Code
                            </Text>
                        </View>
                        <View>
                            <TextInput
                                keyboardType='default'
                                placeholder={'Postal Code'}
                                placeholderTextColor={Colors.textColor}
                                selectionColor={Colors.textColor}
                                maxLength={50}
                                onChangeText={(input) => this.setState({ jobTitle: input })}
                                onSubmitEditing={() => { Keyboard.dismiss() }}
                                style={styles.inputStyle}
                            ></TextInput>
                        </View>
                    </View>

                    <View>
                        <Image resizeMode={'cover'} source={localImage.googleIcon} style={{ marginTop: mobileW * 7 / 100, width: mobileW * 90 / 100, height: mobileW * 40 / 100 }} />
                    </View>

                    <View style={{ width: '100%', marginBottom: mobileW * 5 / 100, marginTop: mobileW * 4 / 100 }}>
                        <View style={{ flexDirection: 'row', }}>

                            <View style={{ justifyContent: 'center', alignItems: 'center', }}>

                                <TouchableOpacity
                                    onPress={() => this.checkboxTermsAndCondition()}
                                    style={{
                                        flexDirection: 'row', width: mobileW * 10 / 100,
                                        justifyContent: 'space-between',
                                    }}>
                                    {this.state.checkbox ?
                                        <MaterialCommunityIcons name='check-box-outline' size={35} color={Colors.darkGreenColor} />
                                        : <MaterialCommunityIcons name='checkbox-blank-outline' size={30} color={Colors.darkGreenColor} />}
                                </TouchableOpacity>
                            </View>
                            <View style={{ width: mobileW * 70 / 100, }}>
                                <Text style={{
                                    width: mobileW * 80 / 100,
                                    fontSize: mobileW * 3.5 / 100,
                                    fontFamily: Font.montserrat_Regular,
                                    color: Colors.textColor
                                }}>
                                    By clicking checkbox , you agree to our  Terms and Conditions and Privacy Policy
                                </Text>
                            </View>
                        </View>
                    </View>
                    <AddButton
                        title="Post Job"
                        color={Colors.whiteColor}
                        backgroundColor={Colors.darkGreenColor}
                        onPress={() => { }}
                    />
                </View>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    screenBody: {
        marginTop: mobileW * 5 / 100,
        width: mobileW * 90 / 100,
        marginBottom: mobileW * 18 / 100,
        alignSelf: 'center',
    },
    labelStyle: {
        width: mobileW * 82 / 100, alignSelf: 'center'
    },
    textFieldLabel: {
        marginBottom: mobileW * 2 / 100,
        color: Colors.greyColor,
        fontSize: Font.fontSize3half,
        fontFamily: Font.montserrat_Regular
    },
    containerStyle: {
        width: '100%',
        marginTop: mobileW * 3 / 100,
        marginBottom: mobileW * 1 / 100,
    },
    textFieldLabel: {
        marginBottom: mobileW * 2 / 100,
        color: Colors.greyColor,
        fontSize: Font.fontSize3half,
        fontFamily: Font.montserrat_Regular
    },
    inputStyle: {
        color: Colors.textColor,
        alignSelf: 'center',
        borderColor: Colors.greyColor,
        borderWidth: 0.7,
        width: mobileW * 90 / 100,
        paddingVertical: mobileW * 3.5 / 100,
        paddingLeft: 18,
        fontSize: Font.fontSize4,
        fontFamily: Font.montserrat_Regular
    },
});
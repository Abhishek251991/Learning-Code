import React, { Component } from 'react'
import { Image, SafeAreaView, FlatList, ScrollView, StatusBar, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { mobileW, commonStyle, mobileH, localStorage, localImage, Colors, Font } from '../../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Agenda, Calendar, } from 'react-native-calendars';
import Footer from '../../Provider/Footer';
import EmployerFooter from './EmployerFooter';
const data = [
    {
        'date': 'October 14,2023',
        'post': 'Employer',
        'title': 'New Meet'
    },
];

export default class MeetingScreen extends Component {
    render() {
        return (
            <View style={commonStyle.container}>
                <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardDismissMode='interactive' keyboardShouldPersistTaps='handled' showsVerticalScrollIndicator={false}>
                    <KeyboardAwareScrollView>
                        <SafeAreaView style={{ flex: 0, backgroundColor: Colors.viewsafecolor }} />
                        <StatusBar hidden={false} StatusBarStyle='light-content' backgroundColor={Colors.statusbarcolor} translucent={false} networkActivityIndicatorVisible={true} />

                        {/* App Bar Start  */}
                        <View style={{
                            flexDirection: 'row', width: '100%', paddingHorizontal: 10,
                            alignItems: 'center', height: mobileH * 8 / 100
                        }}>
                            <TouchableOpacity style={{ width: '10%' }} onPress={() => { this.props.navigation.goBack() }}>
                                <Image source={localImage.backArrowImage}
                                    style={{ marginLeft: mobileW * 3 / 100, width: mobileW * 7 / 100, height: mobileW * 7 / 100, resizeMode: 'contain' }}>
                                </Image>
                            </TouchableOpacity>
                            <View style={{ width: '78%', alignSelf: 'center' }}>
                                <Text style={{
                                    width: '100%', fontSize: Font.fontSize5, color: Colors.textColor,
                                    fontFamily: Font.montserrat_Bold, textAlign: 'center'
                                }}>Meetings</Text>
                            </View>
                        </View>


                        <Calendar

                            onDayPress={(day) => { console.log('day pressed') }}
                            markedDates={{
                                '2021-10-13': {
                                    selected: true, marked: true, selectedColor: '#dbffe4',
                                    customStyles: {
                                        container: {
                                            backgroundColor: Colors.statusbar_color
                                        },
                                        text: {
                                            color: '#000',
                                            fontWeight: 'bold'
                                        }

                                    }
                                },
                                '2021-10-29': {
                                    customStyles: {
                                        container: {
                                            backgroundColor: 'white',
                                            elevation: 2
                                        },
                                        text: {
                                            color: '#000'
                                        }
                                    }
                                }
                            }}


                            theme={{
                                arrowColor: 'black',
                                textDayFontWeight: '300',
                                textMonthFontWeight: 'bold',
                                textDayHeaderFontWeight: '300',
                                textDayFontSize: 16,
                                textMonthFontSize: 18,
                                textDayHeaderFontSize: 16
                            }}

                        />
                        <View style={{ flexDirection: 'row', width: mobileW * 90 / 100, alignSelf: 'center', justifyContent: 'space-between', marginTop: mobileW * 3 / 100, marginBottom: mobileW * 3 / 100 }}>
                            <Text style={{ fontFamily: Font.montserrat_Medium, fontSize: mobileW * 4 / 100 }}>Meetings</Text>
                            <TouchableOpacity onPress={() => { this.props.navigation.navigate('AddMeeting') }}>
                                <View style={{ backgroundColor: '#60bb78', width: mobileW * 18 / 100, height: mobileH * 3.5 / 100, justifyContent: 'center' }}>
                                    <Text style={{ fontFamily: Font.montserrat_Medium, fontSize: mobileW * 3.5 / 100, color: '#fff', textAlign: 'center' }} >Add</Text>
                                </View>
                            </TouchableOpacity>
                        </View>
                        <FlatList
                            data={data}
                            contentContainerStyle={{ paddingBottom: 30 }}
                            renderItem={({ item, index }) => {
                                return (

                                    <TouchableOpacity onPress={() => { this.props.navigation.navigate('Wcr_daily_two') }}>
                                        <View style={styles.mainboxView} >

                                            <View style={styles.boxView}>
                                                {/* <View style={{alignSelf:'center',justifyContent:'center',width:mobileW*14/100}}>
                                    <Image style={{alignItems:'center', height:windowHeight*9/100,resizeMode:'contain',width:mobileW*14/100,alignSelf:'center',borderRadius:150/2}} source={item.image}/>
                                    </View> */}
                                                <View style={{ width: '75%' }}>
                                                    <Text style={{ fontSize: mobileW * 3 / 100, paddingLeft: '5%', fontFamily: Font.montserrat_Bold, color: '#abb1be' }} >{item.date}</Text>
                                                    <Text style={{ fontSize: mobileW * 4 / 100, fontFamily: Font.montserrat_Bold, paddingVertical: '2%', paddingLeft: '5%', color: '#000' }} >{item.title}</Text>
                                                    <Text style={{ fontSize: mobileW * 3 / 100, fontFamily: Font.montserrat_Bold, paddingVertical: '0.5%', paddingLeft: '5%', color: '#60bb78' }} >{item.post}</Text>
                                                </View>
                                                <View style={{ width: '25%', flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center' }}>
                                                    <TouchableOpacity onPress={() => { this.props.navigation.navigate('EditMeeting') }} activeOpacity={.7}>
                                                        <Image source={localImage.editImage}
                                                            style={{ alignSelf: 'center', width: mobileW * 6 / 100, height: mobileW * 6 / 100, resizeMode: 'contain' }}>
                                                        </Image>
                                                    </TouchableOpacity>
                                                    <TouchableOpacity>
                                                        <Image source={localImage.deleteImage}
                                                            style={{ alignSelf: 'center', width: mobileW * 6 / 100, height: mobileW * 6 / 100, resizeMode: 'contain' }}>
                                                        </Image>
                                                    </TouchableOpacity>
                                                </View>
                                            </View>
                                        </View>
                                    </TouchableOpacity>
                                )
                            }}

                        ></FlatList>


                    </KeyboardAwareScrollView>
                </ScrollView>
                <EmployerFooter
                    activepage='Employer' // active screen initially
                    usertype={1} // types of user set
                    footerpage={[
                        { name: 'Employer', label: 'Main', countshow: false, image: require('../../icons/sector_blue.png'), activeimage: require('../../icons/home_active_icon.png') },
                        { name: 'Notification', label: 'Notificaiton', countshow: false, image: require('../../icons/bell_icon.png'), activeimage: require('../../icons/bell_active_icon.png') },
                        { name: 'EmployerMyList', label: 'My List', countshow: false, image: require('../../icons/list_icon.png'), activeimage: require('../../icons/mylist_active_icon.png') },
                        { name: 'EmployerComponyProfileScreen', label: 'Account', countshow: false, image: require('../../icons/account_icon.png'), activeimage: require('../../icons/acount_active_icon.png') },
                    ]} // number of menus in bottom navigation bar
                    navigation={this.props.navigation} // send navigation object
                    imagestyle1={{
                        width: mobileW * 6.5 / 100, height: mobileH * 8 / 100,
                        backgroundColor: Colors.whiteColor, countcolor: 'white', countbackground: 'black'
                    }}
                />
            </View>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.whiteColor
    },
    boxView: {
        backgroundColor: Colors.white_color,

        width: '100%',
        borderRadius: mobileW * 0.5 / 100,
        flexDirection: 'row',
        padding: '1.5%',
        borderWidth: 1,
        borderColor: '#d3d6dd'


    },
    mainboxView: {
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        paddingLeft: '5%',
        paddingRight: '5%',




    },
});